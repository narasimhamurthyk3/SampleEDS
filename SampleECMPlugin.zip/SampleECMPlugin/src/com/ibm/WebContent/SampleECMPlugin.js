require(["dojo/_base/declare",
         "dojo/_base/lang",
         "dojo/aspect", 
         "ecm/model/Request",
         "ecm/widget/dialog/AddContentItemDialog"], 
         function(declare, lang, aspect, Request, AddContentItemDialog) {
    /**
     * Use this function to add any global JavaScript methods your plug-in requires.
     */

    lang.setObject("addDocumentET",
            function(repository, items, callback, teamspace, resultSet, parameterMap) {

    //	alert("HELLO ADDDOCUMENT ET");		
		console.log("INSIDE ADD_DOCUMENT_ET....");
                // Parameters passed to the service as HttpServletRequest
		
		debugger;
		var objectStore = repository.objectStore;
		
		var etClassName="AA";
		var etName="AA";
		
	//	var parentFolderid="{A031017A-0000-CC12-85EB-6CB645FE737E}";
		var parentFolder=repository.rootItem;
		var parentFolderid=repository.rootItem.id;
	    // First we'll retrieve all the templates
		
/*		repository.retrieveEntryTemplates(lang.hitch(this, 
				
				function (entryTemplates, document_ET_count, folder_ET_count) {
			
			  console.log("found et...");
			
		}));*/
		var entryTemplate = null;
	    repository.retrieveEntryTemplates(
	            function (entryTemplates, document_ET_count, folder_ET_count) {
	                
	                // Then we'll search for the one that we want
	                for (var i = 0; i < entryTemplates.length; i++) {
	                    if (entryTemplates[i] && entryTemplates[i].name == etName) {	                    	
                           // entryTemplates[i].addClassName == etClassName
	                    console.log(entryTemplates[i].addClassName);	
	                    	entryTemplate = entryTemplates[i];
	                    	//console.log(entryTemplate.addClassName);
	                    	console.log("EntryTemplateName:"+entryTemplate.name);
	                        //console.log("found et...");
	                       // break;
	                    }
	                }
	                // No Entry Template = abort.
	                if (!entryTemplate) {
	                    alert("The Entry Template " +
	                            "\"" + etClassName + "\" " +
	                            "was not found. Please contact the administrators");
	                    return;
	                }

	                // Now we got the Entry Template, time to retrieve its content
	                // First, we design a "waiter" object.
	                // We assume here the PluginService returns the values in
	                // the "properties" entry of the object response

	       


	            }, "Document", null, null, objectStore);
	    
	    var addContentItemDialog  = new AddContentItemDialog();
	    var addContentItemPropertiesPane =
            addContentItemDialog.addContentItemPropertiesPane;
        // Box containing general stuff
        var addContentItemGeneralPane =
            addContentItemDialog.addContentItemGeneralPane;
	    addContentItemDialog.show(
	            repository,
	            null,  // parent folder 
	            true,          // document being added
	            false,         // not virtual 
	            null,          // no callback function 
	            null,          // no teamspace 
	            true,          // Use an Entry Template 
	            entryTemplate, // Entry template 
	            true           // don't allow choosing directory
	                           // from another repository
	    );
	    
	    console.log("entryTemplate:"+entryTemplate)
        // Waiting for complete rendering before filling the properties and general fields
        aspect.after(addContentItemPropertiesPane,
                     "onCompleteRendering",
                     function() {
                         // Setting the destination and lock it
                         var folderSelector = addContentItemGeneralPane.folderSelector;
                         folderSelector.setRoot(parentFolder, objectStore);
                         folderSelector .setDisabled(true);

                         // Property filling - Work :-)
                         addContentItemDialog.setTitle("New document from another");
                         addContentItemDialog.setIntroText("This form allow you to create a document from another one.");
                         addContentItemPropertiesPane.setPropertyValue("DocumentTitle", "Prefilled title");                            
                         // Property filling - Doesn't work :-(
                         

                     }, true);
	    

           
            });
});