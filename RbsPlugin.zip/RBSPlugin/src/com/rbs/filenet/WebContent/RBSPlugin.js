require(["dojo/_base/declare",
         "dojo/_base/lang",
         "ecm/widget/dialog/MessageDialog",
         "ecm/widget/dialog/ConfirmationDialog"
         ], 
         function(declare, lang,MessageDialog,ConfirmationDialog) {		
	/**
	 * Use this function to add any global JavaScript methods your plug-in requires.
	 */
	lang.setObject("demoAction1", function(repository, items, callback, teamspace, resultSet, parameterMap) {
		/*
		 * Add custom code for your action here. For example, your action might launch a dialog or call a plug-in service.
		 */
		debugger;

		var docname=items[0].name;


		var messageDialog = new MessageDialog();


		messageDialog.description.innerHTML =docname;
		messageDialog.show();






	});
	lang.setObject("demoAction2", function(repository, items, callback, teamspace, resultSet, parameterMap) {
		/*
		 * Add custom code for your action here. For example, your action might launch a dialog or call a plug-in service.
		 */




	});
});
