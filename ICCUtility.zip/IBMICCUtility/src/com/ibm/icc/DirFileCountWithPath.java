package com.ibm.icc;

import java.io.IOException;
import java.nio.file.DirectoryStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
public class DirFileCountWithPath {
  public static void main(String args[]) {
     List<String> fileNames = new ArrayList<>();
    try {
      DirectoryStream<Path> directoryStream = Files.newDirectoryStream(Paths.get("D:\\ICC\\01-01-JAN-2021\\AAAAAAAA"));
      for (Path path : directoryStream) {
    	  
    	  
        fileNames.add(path.toString());
      }
    } catch (IOException ex) {
    }
    System.out.println("File Count:"+fileNames.size());
  }
}
