package com.ibm.icc;
import java.io.*;
import java.util.ArrayList;
public class IBMICCUtility {

	public static void main(String[] args) throws Exception  {
		String iccFolderPath="D:\\ICC\\01-01-JAN-2021";
		String sharedPath="\\\\vimala\\D\\ICC\\01-01-JAN-2021";
		
		ArrayList<ICCFolderStatistics> iccFolder = new ArrayList<>();
		int totalNumberOfFiles=0;
		int tolaNumberOfXMLFiles=0;
		Boolean finalmatchStatus=true;
		IBMICCUtility icc=new IBMICCUtility();
		File fileDirectory=new File(sharedPath);
		File[] s= fileDirectory.listFiles(); 
		for(int i=0;i<s.length;i++){        	
			if(s[i].isDirectory()){

				//System.out.println(s[i].getAbsoluteFile());
				File[] iccSourceFoldes=s[i].listFiles();
				for(int j=0;j<iccSourceFoldes.length;j++){ 
					if(iccSourceFoldes[j].isDirectory()){
						if(iccSourceFoldes[j].getName().equalsIgnoreCase("Source")){
							ICCFolderStatistics iccSubFolder=new ICCFolderStatistics();
							iccSubFolder=icc.countFilesInFolder(iccSourceFoldes[j]);
							iccFolder.add(iccSubFolder);
						}
					}
				}


			}
		}

		for (ICCFolderStatistics iccSubFolder : iccFolder){

			System.out.println("FOLDER:"+iccSubFolder.getFolderName()+",COUNT:"+iccSubFolder.getTotalNumberOfFilesCount()+",XML:"+iccSubFolder.getTotalXMLFilesCount()+",MATCHED:"+iccSubFolder.getXmlFilesCountMatchStatus().toString().toUpperCase()+",REMARKS:"+iccSubFolder.getRemarks());
			totalNumberOfFiles=totalNumberOfFiles+iccSubFolder.getTotalNumberOfFilesCount();
			tolaNumberOfXMLFiles=tolaNumberOfXMLFiles+iccSubFolder.getTotalXMLFilesCount();
			if(!iccSubFolder.getXmlFilesCountMatchStatus()){
				finalmatchStatus=false;
			}
		}
		System.out.println("TOTAL FILES:"+totalNumberOfFiles+",TOTAL XML:"+tolaNumberOfXMLFiles+",MATCHED:"+finalmatchStatus.toString().toUpperCase());
	}
	public ICCFolderStatistics countFilesInFolder(File f){ 
		ICCFolderStatistics iccSubFolder=new ICCFolderStatistics();
		int totalNumberOfFiles=0;    	
		int numberOfXMLFiles=0;

		File[] s= f.listFiles();     
		for(int i=0;i<s.length;i++){
			/*
            if(s[i].isDirectory())
            	numberOfSubDirectories+=listaj(s[i]);
            else if(s[i].getName().endsWith(".XML")){
            	numberOfXMLFiles++;
            }*/            
			if(s[i].isFile()){
				totalNumberOfFiles++;
				if(s[i].getName().endsWith(".XML")){
					numberOfXMLFiles++;
				}
			}

		}        

		Boolean matchedStatus=checkIsXMLFilesAndContentFilesAreMatched(totalNumberOfFiles,numberOfXMLFiles);
		if(!matchedStatus){

			if(totalNumberOfFiles>numberOfXMLFiles*2){
				iccSubFolder.setRemarks("MISMATCH IN CONTENT FILES");
			}else{
				iccSubFolder.setRemarks("MISMATCH IN XML FILES");
			}

		}
		// System.out.println("FOLDER:"+f.getName().toUpperCase()+",COUNT:"+totalNumberOfFiles+",XML:"+numberOfXMLFiles+",MATCHED:"+matchedStatus);
		iccSubFolder.setFolderName(f.getAbsolutePath());
		iccSubFolder.setTotalNumberOfFilesCount(totalNumberOfFiles);
		iccSubFolder.setTotalXMLFilesCount(numberOfXMLFiles);
		iccSubFolder.setXmlFilesCountMatchStatus(matchedStatus);        
		return iccSubFolder;
	}

	private static boolean checkIsXMLFilesAndContentFilesAreMatched(int totalNumberOfFiles,int numberOfXMLFiles){
		Boolean xmlFilesAreMatched=false;    	
		if(totalNumberOfFiles==numberOfXMLFiles*2){
			//System.out.println("XML Files Count is Matched...");
			xmlFilesAreMatched=true;
		}

		return xmlFilesAreMatched;
	}
}