package com.ibm.icc;

public class ICCFolderStatistics {

	int totalNumberOfFilesCount=0;
	int totalXMLFilesCount=0;
	String folderName;
	Boolean xmlFilesCountMatchStatus=false;
	String remarks;

	
	public ICCFolderStatistics() {
		super();
		this.remarks = "NA";
	}

	public ICCFolderStatistics(int totalNumberOfFilesCount, int totalXMLFilesCount, String folderName,
			Boolean xmlFilesCountMatchStatus, String remarks) {
		super();
		this.totalNumberOfFilesCount = totalNumberOfFilesCount;
		this.totalXMLFilesCount = totalXMLFilesCount;
		this.folderName = folderName;
		this.xmlFilesCountMatchStatus = xmlFilesCountMatchStatus;
		this.remarks = remarks;
	}

	public String getRemarks() {
		return remarks;
	}
	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}
	public int getTotalNumberOfFilesCount() {
		return totalNumberOfFilesCount;
	}
	public void setTotalNumberOfFilesCount(int totalNumberOfFilesCount) {
		this.totalNumberOfFilesCount = totalNumberOfFilesCount;
	}
	public int getTotalXMLFilesCount() {
		return totalXMLFilesCount;
	}
	public void setTotalXMLFilesCount(int totalXMLFilesCount) {
		this.totalXMLFilesCount = totalXMLFilesCount;
	}
	public String getFolderName() {
		return folderName;
	}
	public void setFolderName(String folderName) {
		this.folderName = folderName;
	}
	public Boolean getXmlFilesCountMatchStatus() {
		return xmlFilesCountMatchStatus;
	}
	public void setXmlFilesCountMatchStatus(Boolean xmlFilesCountMatchStatus) {
		this.xmlFilesCountMatchStatus = xmlFilesCountMatchStatus;
	}
}
