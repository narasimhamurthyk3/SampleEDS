package com.ibm.rbs.service;

import java.io.PrintWriter;
import java.util.Iterator;

import javax.servlet.ServletRequest;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.filenet.api.collection.GroupSet;
import com.filenet.api.collection.UserSet;
import com.filenet.api.constants.PrincipalSearchAttribute;
import com.filenet.api.constants.PrincipalSearchSortType;
import com.filenet.api.constants.PrincipalSearchType;
import com.filenet.api.core.Connection;
import com.filenet.api.core.Domain;
import com.filenet.api.core.Factory;
import com.filenet.api.core.ObjectStore;
import com.ibm.ecm.extension.PluginLogger;
import com.ibm.ecm.extension.PluginResponseUtil;
import com.ibm.ecm.extension.PluginService;
import com.ibm.ecm.extension.PluginServiceCallbacks;
import com.ibm.ecm.json.JSONResponse;
import com.ibm.json.java.JSONArray;

/**
 * Provides an abstract class that is extended to create a class implementing
 * each service provided by the plug-in. Services are actions, similar to
 * servlets or Struts actions, that perform operations on the IBM Content
 * Navigator server. A service can access content server application programming
 * interfaces (APIs) and Java EE APIs.
 * <p>
 * Services are invoked from the JavaScript functions that are defined for the
 * plug-in by using the <code>ecm.model.Request.invokePluginService</code>
 * function.
 * </p>
 * Follow best practices for servlets when implementing an IBM Content Navigator
 * plug-in service. In particular, always assume multi-threaded use and do not
 * keep unshared information in instance variables.
 */
public class GetUserHasSoftDeletePermission extends PluginService {

	public PluginLogger logger = null;

	public ObjectStore objectStore = null;

	public JSONArray jsonArray = null;

	public String[] users = null;

	/**
	 * Returns the unique identifier for this service.
	 * <p>
	 * <strong>Important:</strong> This identifier is used in URLs so it must
	 * contain only alphanumeric characters.
	 * </p>
	 * 
	 * @return A <code>String</code> that is used to identify the service.
	 */
	public String getId() {
		return "GetUserHasSoftDeletePermission";
	}

	/**
	 * Returns the name of the IBM Content Navigator service that this service
	 * overrides. If this service does not override an IBM Content Navigator
	 * service, this method returns <code>null</code>.
	 * 
	 * @returns The name of the service.
	 */
	public String getOverriddenService() {
		return null;
	}

	/**
	 * Performs the action of this service.
	 * 
	 * @param callbacks
	 *            An instance of the <code>PluginServiceCallbacks</code> class
	 *            that contains several functions that can be used by the
	 *            service. These functions provide access to the plug-in
	 *            configuration and content server APIs.
	 * @param request
	 *            The <code>HttpServletRequest</code> object that provides the
	 *            request. The service can access the invocation parameters from
	 *            the request.
	 * @param response
	 *            The <code>HttpServletResponse</code> object that is generated
	 *            by the service. The service can get the output stream and
	 *            write the response. The response must be in JSON format.
	 * @throws Exception
	 *             For exceptions that occur when the service is running. If the
	 *             logging level is high enough to log errors, information about
	 *             the exception is logged by IBM Content Navigator.
	 */
	public void execute(PluginServiceCallbacks callbacks,
			HttpServletRequest request, HttpServletResponse response)
					throws Exception {
		System.out.println("Inside GETUSERHASSOFTDELETEPERMISSION");
		logger = new PluginLogger(getId());
		logger.logEntry(this, getId(), (ServletRequest)request);
		JSONResponse responseJSON = new JSONResponse();		
		try {
			//String repositoryID = request.getParameter("repositoryId");
			//System.out.println("repoID::"+repositoryID);
			//String osName = request.getParameter("osName");
			//System.out.println("osname"+osName);
			String userID = request.getParameter("userId");
			String repositoryId = request.getParameter("repositoryId");

			Connection connection = callbacks.getP8Connection(repositoryId);

			objectStore = callbacks.getP8ObjectStore(repositoryId);
			//Connection conn = callbacks.getP8Connection(repositoryID);
			//Domain domain = callbacks.getP8Domain(repositoryID);
			//ObjectStore objectStore = callbacks.getP8ObjectStore(repositoryID);
			//JSONResponse responseJSON = new JSONResponse();
			com.filenet.api.core.EntireNetwork entireNetwork= Factory.EntireNetwork.fetchInstance(connection, null);
			com.filenet.api.security.Realm realm= entireNetwork.get_MyRealm();String realmName= realm.get_Name();
			System.out.println(realmName+ " is retrieved");		
			UserSet users = realm.findUsers(userID, PrincipalSearchType.EXACT,PrincipalSearchAttribute.SHORT_NAME,PrincipalSearchSortType.NONE,Integer.valueOf("50"), null);
			com.filenet.api.security.User user;
			Iterator it = users.iterator();
			while (it.hasNext())
			{
				user = (com.filenet.api.security.User)it.next();
				System.out.println("distinguishedname =" +user.get_DistinguishedName());
				System.out.println("shortname =" + user.get_ShortName());
				System.out.println("name=" + user.get_Name());
				System.out.println("displayname =" + user.get_DisplayName());
				GroupSet userGroups = user.get_MemberOfGroups();                       
				Iterator groupsIt = userGroups.iterator();			 				
				com.filenet.api.security.Group group;

				while (groupsIt.hasNext())
				{
					group=(com.filenet.api.security.Group)groupsIt.next();
					if(group.get_DisplayName().equalsIgnoreCase("P8Admins")){						
						System.out.println("name=" + group.get_Name());
						System.out.println("Distinguishedname = " + group.get_DistinguishedName());
						System.out.println("shortname =" + group.get_ShortName());
						System.out.println(group.get_Id());
						System.out.println(group.get_DisplayName());						
						responseJSON.put("Status", "SUCCESS");

						logger.logInfo(this, getId(), "User "+userID +" has permission");
						break;
					}				
				} 
			}
			//PluginResponseUtil.writeJSONResponse(request, response, responseJSON, callbacks, "GetUserHasSoftDeletePermission");

		}
		catch (Exception exception) {			
			exception.printStackTrace();
			System.out.println("Exception:"+ exception.getMessage());
			logger.logError(this, getId(), "Error in  ICN Get User Has SoftDeleet Permission Service " + exception.getMessage());
			responseJSON.put("Status", "FAILURE");

		}finally {
			System.out.println("COMMITING JSON RESPONSE");
			logger.logExit(this, getId(), (ServletRequest)request);
			PluginResponseUtil.writeJSONResponse(request, response, responseJSON, callbacks, "GetUserHasSoftDeletePermission");
			//responseWriter.print(jsonResponse);
		} 


	}
}
