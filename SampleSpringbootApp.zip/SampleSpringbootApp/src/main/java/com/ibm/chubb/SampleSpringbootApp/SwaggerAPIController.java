package com.ibm.chubb.SampleSpringbootApp;


import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class SwaggerAPIController {
    private Logger logger = LoggerFactory.getLogger(SwaggerAPIController.class);

    @RequestMapping(value = "/products", method = RequestMethod.GET)
    public List<String> getProducts() {
        List<String> productsList = new ArrayList<>();
        productsList.add("Honey");
        productsList.add("Almond");
        return productsList;
    }
    @RequestMapping(value = "/products", method = RequestMethod.POST)
    public String createProduct() {
        return "Product is saved successfully";
    }

    private String openTag = "<h2 align = center> <font color=green>";
    private String closeTag = "</font></h2>";
   // @GetMapping("/hello")
    @RequestMapping(value = "/hello", method = RequestMethod.GET)
    public String helloPCFWorld(){

        return openTag + "!!Hello PCF....V8" + closeTag;
    }


    @GetMapping("/ipAddress")
    public String getIpAddress() throws UnknownHostException {
        logger.info("Got hit on /ipAddress");
        String host = InetAddress.getLocalHost().getHostAddress();
        return openTag + "I am running on machine - "  + host + closeTag;
    }

    @GetMapping("/")
    public String getWelcomeMessage() {
        logger.info("Got hit on /");
        return openTag + "Welcome To SpringBoot Sample Application........... "   + closeTag;
    }

}