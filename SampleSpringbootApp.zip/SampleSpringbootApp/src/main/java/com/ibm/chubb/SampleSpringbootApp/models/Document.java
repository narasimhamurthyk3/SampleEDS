package com.ibm.chubb.SampleSpringbootApp.models;

import org.springframework.context.annotation.Bean;
import org.springframework.stereotype.Component;

@Component
class Document {
    String documentname;
    String mimetype;

    public String getDocumentname() {
        return documentname;
    }

    public void setDocumentname(String documentname) {
        this.documentname = documentname;
    }

    public String getMimetype() {
        return mimetype;
    }

    public void setMimetype(String mimetype) {
        this.mimetype = mimetype;
    }
}


