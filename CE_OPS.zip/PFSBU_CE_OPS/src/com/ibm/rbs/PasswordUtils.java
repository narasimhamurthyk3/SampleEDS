package com.ibm.rbs;

import java.io.IOException;
import java.security.GeneralSecurityException;
import java.util.Scanner;

import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.PBEKeySpec;
import javax.crypto.spec.PBEParameterSpec;

import filenet.vw.base.logging.Logger;
import sun.misc.BASE64Decoder;
import sun.misc.BASE64Encoder;
public class PasswordUtils {

	private static Logger logger = Logger
			.getLogger(PasswordUtils.class);
	private static final char[] PASSWORD = "ccaroma_rbs".toCharArray();

	private static final byte[] SALT = { (byte) 0xdf, (byte) 0x44, (byte) 0x15,
		(byte) 0x15, (byte) 0xde, (byte) 0x22, (byte) 0x12, (byte) 0x10 };

	public static String encrypt(String property)
			throws GeneralSecurityException {
		SecretKeyFactory keyFactory = SecretKeyFactory
				.getInstance("PBEWithMD5AndDES");
		SecretKey key = keyFactory.generateSecret(new PBEKeySpec(PASSWORD));

		Cipher pbeCipher = Cipher.getInstance("PBEWithMD5AndDES");
		pbeCipher
		.init(Cipher.ENCRYPT_MODE, key, new PBEParameterSpec(SALT, 100));
		return base64Encode(pbeCipher.doFinal(property.getBytes()));
	}

	private static String base64Encode(byte[] bytes) {
		// NB: This class is internal, and you probably should use another impl
		return new BASE64Encoder().encode(bytes);
	}

	public static String decrypt(String property)
			throws GeneralSecurityException, IOException {

		SecretKeyFactory keyFactory = SecretKeyFactory
				.getInstance("PBEWithMD5AndDES");
		SecretKey key = keyFactory.generateSecret(new PBEKeySpec(PASSWORD));
		Cipher pbeCipher = Cipher.getInstance("PBEWithMD5AndDES");
		pbeCipher
		.init(Cipher.DECRYPT_MODE, key, new PBEParameterSpec(SALT, 100));
		return new String(pbeCipher.doFinal(base64Decode(property)));
	}

	private static byte[] base64Decode(String property) throws IOException {
		// NB: This class is internal, and you probably should use another impl
		return new BASE64Decoder().decodeBuffer(property);
	}

	public static void main1(String[] args) throws IOException{
		String password="filenetp@ssw0rd123";
		String encryptedPwd="";
		String decryptedPwd="";
		try {
			encryptedPwd=PasswordUtils.encrypt(password);
			decryptedPwd=PasswordUtils.decrypt(encryptedPwd);
		} catch (GeneralSecurityException e) {

			e.printStackTrace();
		}
		System.out.println("password: "+password);
		System.out.println("Encrypted password: "+encryptedPwd);
		System.out.println("Decrypted password: "+decryptedPwd);
	}

	public static void main(String[] args) {
		try {
			
			logger.info("REQUEST PASSWORD ENCRYPTION"); //$NON-NLS-1$
			Scanner scanner = new Scanner(System.in);
			System.out.print("ENTER THE STRING PASSWORD	:: ");
			String pwd = scanner.next();			
			if (pwd != null) {
				System.out.print("ENCRYPTED STRING :: " + PasswordUtils.encrypt(pwd));
			}
			scanner.close();
		} catch (Exception e) {
			logger.error("EXCEPTION OCCURED WHILE DOING PASSWORD ENCRYPTION :: ", e);
			
		}
	}

}
