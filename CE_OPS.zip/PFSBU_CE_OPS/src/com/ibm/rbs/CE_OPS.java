package com.ibm.rbs;


import java.io.IOException;
import java.security.GeneralSecurityException;
import java.util.Iterator;

import javax.security.auth.Subject;

import com.filenet.api.collection.AccessPermissionList;
import com.filenet.api.collection.FolderSet;
import com.filenet.api.collection.ObjectStoreSet;
import com.filenet.api.constants.AccessLevel;
import com.filenet.api.constants.AccessRight;
import com.filenet.api.constants.AccessType;
import com.filenet.api.constants.RefreshMode;
import com.filenet.api.core.Connection;
import com.filenet.api.core.Document;
import com.filenet.api.core.Domain;
import com.filenet.api.core.Factory;
import com.filenet.api.core.Folder;
import com.filenet.api.core.ObjectStore;
import com.filenet.api.property.Properties;
import com.filenet.api.security.AccessPermission;
import com.filenet.api.util.UserContext;





import filenet.vw.base.logging.Logger;


public class CE_OPS {



	public CE_OPS()
	{


	}
	private static Logger logger = Logger
			.getLogger(CE_OPS.class);


	public void applyFolderSecurity(String FolderName,String Location,String TeamName) throws GeneralSecurityException, IOException

	{

		String uri = Messages.getString("CE_OPS.13"); //Content Engine Url

		String username = Messages.getString("CE_OPS.14"); //UserName 
		//String password = Messages.getString("CE_OPS.15"); //password
		String password = PasswordUtils.decrypt( Messages.getString("CE_OPS.15"));
		// Make connection.
		Connection conn = Factory.Connection.getConnection(uri);
		Subject subject = UserContext.createSubject(conn, username, password, null);
		UserContext.get().pushSubject(subject);

		try
		{
			// Get default domain.

			Domain domain = Factory.Domain.fetchInstance(conn, null, null);

			// Get object stores for domain.

			ObjectStoreSet osSet = domain.get_ObjectStores();
			ObjectStore store=null;
			Iterator osIter = osSet.iterator();

			while (osIter.hasNext() == true) 
			{
				store = (ObjectStore) osIter.next();

			}


			String ProposalFolderRepository =null;



			//For Preappraisal Folder


			ProposalFolderRepository=Messages.getString("CE_OPS.16") + FolderName +Messages.getString("CE_OPS.17") + Messages.getString("CE_OPS.18"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$



			Folder  folder=Factory.Folder.fetchInstance(store,ProposalFolderRepository, null);



			setFolderSecurity(folder, TeamName, Location);


			//For Appraisal Folder

			ProposalFolderRepository=Messages.getString("CE_OPS.16") + FolderName +Messages.getString("CE_OPS.17") + Messages.getString("CE_OPS.19"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$



			folder=Factory.Folder.fetchInstance(store,ProposalFolderRepository, null);


			setFolderSecurity(folder, TeamName, Location);


			//For Sanction Folder

			ProposalFolderRepository=Messages.getString("CE_OPS.16") + FolderName +Messages.getString("CE_OPS.17") + Messages.getString("CE_OPS.20"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$



			folder=Factory.Folder.fetchInstance(store,ProposalFolderRepository, null);
			setFolderSecurity(folder, TeamName, Location);



			//For Post Sanction Folder
			ProposalFolderRepository= Messages.getString("CE_OPS.16") + FolderName +Messages.getString("CE_OPS.17") + Messages.getString("CE_OPS.21"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
			folder=Factory.Folder.fetchInstance(store,ProposalFolderRepository, null);
			setFolderSecurity(folder, TeamName, Location);

		}
		catch(Exception e)
		{
			throw new RuntimeException(e);

		}
		finally
		{
			UserContext.get().popSubject();
		}



	}

	public void updateDocumentProperties(String ceDocumentId) throws GeneralSecurityException, IOException

	{
		//ceDocumentId="{14BA6C1C-F9C7-4977-81EB-4C9ABBFC501B}";

		String uri = Messages.getString("CE_OPS.13"); //content Engine URL

		String username = Messages.getString("CE_OPS.14"); //User Name
		//String password = Messages.getString("CE_OPS.15"); //password
		String password = PasswordUtils.decrypt( Messages.getString("CE_OPS.15"));
		// Make connection.

		Connection conn = Factory.Connection.getConnection(uri);
		Subject subject = UserContext.createSubject(conn, username, password, null);
		UserContext.get().pushSubject(subject);

		String folderName= null;
		String DGM="";

		try
		{
			// Get default domain.
			Domain domain = Factory.Domain.fetchInstance(conn, null, null);


			// Get object stores for domain.
			ObjectStoreSet osSet = domain.get_ObjectStores();
			ObjectStore store=null;
			Iterator osIter = osSet.iterator();
			Folder folder = null;


			while (osIter.hasNext() == true) 
			{
				store = (ObjectStore) osIter.next();



			}



			Document document=Factory.Document.fetchInstance(store,ceDocumentId, null);

			String documentClass=document.getClassName();

			logger.info("documentClass= " + documentClass); //$NON-NLS-1$

			FolderSet folderset=document.get_FoldersFiledIn();

			Iterator osIter1 =folderset.iterator();

			while(osIter1.hasNext())
			{

				folder = (Folder) osIter1.next();

				folderName=folder.get_FolderName();

			}

			logger.info(folderName);


			logger.info(folder.get_PathName());



			Properties properties=folder.getProperties();


			//logger.info( "projectID= " +  projectID);
			String projectID=properties.getStringValue(Messages.getString("CE_OPS.22")); //$NON-NLS-1$


			// logger.info( "projectName= " +  projectName);
			String projectName=properties.getStringValue(Messages.getString("CE_OPS.23")); //$NON-NLS-1$


			// logger.info( "location= " +  location);
			String location=properties.getStringValue(Messages.getString("CE_OPS.24")); //$NON-NLS-1$


			//  logger.info( "borrowerName= " +  borrowerName);
			String borrowerName=properties.getStringValue(Messages.getString("CE_OPS.25")); //$NON-NLS-1$


			// logger.info( "sector= " +  sector);
			String sector=properties.getStringValue(Messages.getString("CE_OPS.26")); //$NON-NLS-1$



			// logger.info( "category= " +  category);
			String category=properties.getStringValue(Messages.getString("CE_OPS.27")); //$NON-NLS-1$


			// logger.info( "team= " +  team);
			String team=properties.getStringValue(Messages.getString("CE_OPS.28")); //$NON-NLS-1$


			// logger.info( "dgm= " +  dgm);
			String dgm=properties.getStringValue(Messages.getString("CE_OPS.29")); //$NON-NLS-1$


			// logger.info( "businessGroup= " +  businessGroup);
			String businessGroup=properties.getStringValue(Messages.getString("CE_OPS.30")); //$NON-NLS-1$




			logger.info(projectID);
			logger.info(projectName);
			logger.info(folderName);

			logger.info(team);

			logger.info(location);

			if(documentClass!=null)
			{
				if(!(documentClass.equalsIgnoreCase(Messages.getString("CE_OPS.2")))) //$NON-NLS-1$
				{
					properties=document.getProperties();

					//ProjectID
					properties.putValue(Messages.getString("CE_OPS.22"), projectID); //$NON-NLS-1$
					//ProjectName
					properties.putValue(Messages.getString("CE_OPS.23"), projectName);  //$NON-NLS-1$

					//BorrowerName
					properties.putValue(Messages.getString("CE_OPS.25"), borrowerName);  //$NON-NLS-1$

					//Category
					properties.putValue(Messages.getString("CE_OPS.27"), category);  //$NON-NLS-1$

					//Sector
					properties.putValue(Messages.getString("CE_OPS.26"), sector);  //$NON-NLS-1$

					//BusinessGroup
					properties.putValue(Messages.getString("CE_OPS.30"), businessGroup);  //$NON-NLS-1$


				}
			}

			AccessPermission permission = Factory.AccessPermission.createInstance();



			permission.set_GranteeName(team);

			permission.set_AccessType(AccessType.ALLOW);
			permission.set_InheritableDepth(new Integer(-1)); 


			permission.set_AccessMask(new Integer(AccessLevel.FULL_CONTROL_DOCUMENT_AS_INT));


			AccessPermissionList  permissions = document.get_Permissions();
			permissions.add(permission);

			document.save(RefreshMode.REFRESH);

			//Remove not required rights such as delete set security other than the owner who 
			//Uploaded or created or added it he/she has (User Id) has the rights
			//Also if he/she is the part of the team the user id rights will remain to that user and not to the rest of the team

			removeUnrequiredUserRights(permission,permissions,folder,team,document);





			//For DGM Security rights

			if(location.equalsIgnoreCase(Messages.getString("CE_OPS.3"))) //$NON-NLS-1$
			{
				DGM=Messages.getString("CE_Ohamesha kaPS.4"); //$NON-NLS-1$
			}
			//DGM_CHENNAI
			else if(location.equalsIgnoreCase(Messages.getString("CE_OPS.5"))) //$NON-NLS-1$
			{
				DGM=Messages.getString("CE_OPS.6"); //$NON-NLS-1$
			}
			//DGM_Delhi
			else if(location.equalsIgnoreCase(Messages.getString("CE_OPS.9"))) //$NON-NLS-1$
			{
				DGM=Messages.getString("CE_OPS.7"); //$NON-NLS-1$
			}
			permission.set_GranteeName(DGM);

			permission.set_AccessType(AccessType.ALLOW);
			permission.set_InheritableDepth(new Integer(-1)); // all children
			permission.set_AccessMask(new Integer(AccessLevel.FULL_CONTROL_DOCUMENT_AS_INT));

			permissions = document.get_Permissions();
			permissions.add(permission);
			document.save(RefreshMode.REFRESH);

			//Remove not required rights such as delete set security other than the owner who 
			//up-loaded or created or added it he/she has (User Id) has the rights
			//Also if he/she is the part of the team the user id rights will remain to that user and not to the rest of the team
			removeUnrequiredRights(permission,permissions,folder,DGM,document);




			//For GM  

			permission.set_GranteeName(Messages.getString("CE_OPS.31")); 

			permission.set_AccessType(AccessType.ALLOW);
			permission.set_InheritableDepth(new Integer(-1)); // all children


			permission.set_AccessMask(new Integer(AccessLevel.FULL_CONTROL_DOCUMENT_AS_INT));

			permissions = document.get_Permissions();
			permissions.add(permission);

			document.save(RefreshMode.REFRESH);

			//Remove Un required rigths such as delete set security other than the owner who 
			//uploded or created or added it he/she has (User Id) has the rigths
			//Also if he/she is the part of the team the user id rights will remain to that user and not to the rest of the team
			removeUnrequiredRights(permission,permissions,folder,Messages.getString("CE_OPS.31"),document);






			//For CGM  

			permission.set_GranteeName(Messages.getString("CE_OPS.10"));

			permission.set_AccessType(AccessType.ALLOW);
			permission.set_InheritableDepth(new Integer(-1)); // all children


			permission.set_AccessMask(new Integer(AccessLevel.FULL_CONTROL_DOCUMENT_AS_INT));

			permissions = document.get_Permissions();
			permissions.add(permission);

			document.save(RefreshMode.REFRESH);

			//Remove Un required rigths such as delete set security other than the owner who 
			//uploded or created or added it he/she has (User Id) has the rigths
			//Also if he/she is the part of the team the user id rights will remain to that user and not to the rest of the team
			removeUnrequiredRights(permission,permissions,folder,Messages.getString("CE_OPS.10"),document);



			//DMD

			permission.set_GranteeName(Messages.getString("CE_OPS.11")); 

			permission.set_AccessType(AccessType.ALLOW);
			permission.set_InheritableDepth(new Integer(-1)); // all children


			permission.set_AccessMask(new Integer(AccessLevel.FULL_CONTROL_DOCUMENT_AS_INT));


			permissions = document.get_Permissions();
			permissions.add(permission);

			document.save(RefreshMode.REFRESH);

			//Remove Un required rigths such as delete set security other than the owner who 
			//uploded or created or added it he/she has (User Id) has the rigths
			//Also if he/she is the part of the team the user id rights will remain to that user and not to the rest of the team
			removeUnrequiredRights(permission,permissions,folder,Messages.getString("CE_OPS.11"),document);





		}
		catch(Exception e)
		{
			throw new RuntimeException(e);

		}
		finally
		{
			UserContext.get().popSubject();
		}


	}

	private void setFolderSecurity(Folder folder,String team,String location)
	{
		try
		{

			String DGM=""; 

			AccessPermission permission = Factory.AccessPermission.createInstance();



			permission.set_GranteeName(team);

			permission.set_AccessType(AccessType.ALLOW);
			permission.set_InheritableDepth(new Integer(-1)); // all children


			permission.set_AccessMask(new Integer(AccessLevel.WRITE_DOCUMENT_AS_INT));




			AccessPermissionList  permissions = folder.get_Permissions();
			permissions.add(permission);

			folder.save(RefreshMode.REFRESH);

			//DGM
			//DGM_Mumabi
			if(location.equalsIgnoreCase(Messages.getString("CE_OPS.3"))) //$NON-NLS-1$
			{
				DGM=Messages.getString("CE_OPS.4"); //$NON-NLS-1$
			}
			//DGM_CHENNAI
			else if(location.equalsIgnoreCase(Messages.getString("CE_OPS.5"))) //$NON-NLS-1$
			{
				DGM=Messages.getString("CE_OPS.6"); //$NON-NLS-1$
			}
			//DGM_Delhi
			else if(location.equalsIgnoreCase(Messages.getString("CE_OPS.9"))) //$NON-NLS-1$
			{
				DGM=Messages.getString("CE_OPS.7"); //$NON-NLS-1$
			}
			permission.set_GranteeName(DGM);

			permission.set_AccessType(AccessType.ALLOW);
			permission.set_InheritableDepth(new Integer(-1)); // all children


			permission.set_AccessMask(new Integer(AccessLevel.WRITE_DOCUMENT_AS_INT));

			permissions = folder.get_Permissions();
			permissions.add(permission);

			folder.save(RefreshMode.REFRESH);


			//CGM
			permission.set_GranteeName(Messages.getString("CE_OPS.10")); 

			permission.set_AccessType(AccessType.ALLOW);
			permission.set_InheritableDepth(new Integer(-1));


			permission.set_AccessMask(new Integer(AccessLevel.WRITE_DOCUMENT_AS_INT));

			permissions = folder.get_Permissions();
			permissions.add(permission);

			folder.save(RefreshMode.REFRESH);


			//GM

			permission.set_GranteeName(Messages.getString("CE_OPS.31")); 

			permission.set_AccessType(AccessType.ALLOW);
			permission.set_InheritableDepth(new Integer(-1)); // all children


			permission.set_AccessMask(new Integer(AccessLevel.WRITE_DOCUMENT_AS_INT));


			permissions = folder.get_Permissions();
			permissions.add(permission);

			folder.save(RefreshMode.REFRESH);



			//DMD

			permission.set_GranteeName(Messages.getString("CE_OPS.11")); 

			permission.set_AccessType(AccessType.ALLOW);
			permission.set_InheritableDepth(new Integer(-1)); // all children


			permission.set_AccessMask(new Integer(AccessLevel.WRITE_DOCUMENT_AS_INT));


			permissions = folder.get_Permissions();
			permissions.add(permission);

			folder.save(RefreshMode.REFRESH);

		}
		catch(Exception e)
		{
			throw new RuntimeException(e);
		}

	}


	private void removeUnrequiredRights(AccessPermission permission,AccessPermissionList  permissions,Folder folder,String UserOrRole,Document document)
	{

		permission.set_GranteeName(UserOrRole);
		permission.set_AccessType(AccessType.DENY);
		permission.set_InheritableDepth(new Integer(-1)); // all children
		permission.set_AccessMask(new Integer(AccessRight.DELETE_AS_INT));
		permissions = document.get_Permissions();
		permissions.add(permission);
		document.save(RefreshMode.REFRESH);

		permission.set_GranteeName(UserOrRole);
		permission.set_AccessType(AccessType.DENY);
		permission.set_InheritableDepth(new Integer(-1)); // all children
		permission.set_AccessMask(new Integer(AccessRight.WRITE_ACL_AS_INT));
		permissions = document.get_Permissions();
		permissions.add(permission);
		document.save(RefreshMode.REFRESH);

	}
	private void removeUnrequiredUserRights(AccessPermission permission,AccessPermissionList  permissions,Folder folder,String UserOrRole,Document document)
	{

		/*permission.set_GranteeName(UserOrRole);
	       permission.set_AccessType(AccessType.DENY);
        permission.set_InheritableDepth(new Integer(-1)); // all children
        permission.set_AccessMask(new Integer(AccessRight.DELETE_AS_INT));
        permissions = document.get_Permissions();
        permissions.add(permission);
        document.save(RefreshMode.REFRESH);*/

		permission.set_GranteeName(UserOrRole);
		permission.set_AccessType(AccessType.DENY);
		permission.set_InheritableDepth(new Integer(-1)); // all children
		permission.set_AccessMask(new Integer(AccessRight.WRITE_ACL_AS_INT));
		permissions = document.get_Permissions();
		permissions.add(permission);
		document.save(RefreshMode.REFRESH);

	}


	public static void main(String []args) throws GeneralSecurityException, IOException
	{
		CE_OPS ce=new CE_OPS();
		ce.updateDocumentProperties("{BE54650E-7387-457E-AD7F-4E564435F214}"); 

		/*	try
		{
		String userName = "Administrator";
		String password = "P@ssw0rd";

		System.setProperty("java.naming.factory.initial", "com.ibm.websphere.naming.WsnInitialContextFactory");
		System.setProperty( "java.naming.provider.url","http://cepfsbu:9081/wsi/FNCEWS40MTOM" );
		System.setProperty("java.security.auth.login.config", "C:/jaas.conf.WSI" );
		//System.setProperty("wasp.location","C:\\Program Files\\FileNet\\CEClient\\wsi");
		String connectionPoint = "PEConnectionPoint";
		// Create a Process Engine Session Object
		VWSession myPESession = new VWSession();
		// Set Bootstrap Content Engine URI



		String username = "Administrator"; //UserName 
		password = "P@ssw0rd"; //password

	    // Make connection.
	    Connection conn = Factory.Connection.getConnection("http://cepfsbu:9081/wsi/FNCEWS40MTOM");
	    Subject subject = UserContext.createSubject(conn, username, password, null);
	    UserContext.get().pushSubject(subject);
		myPESession.setBootstrapCEURI("iiop://10.4.239.39:2810/FileNet/Engine");
		// Log onto the Process Engine Server
		logger.info("test1");
		try
		{
		myPESession.logon(userName, password, connectionPoint);
		}
		catch(Exception e)
		{
			logger.info("Inside Exception Block");
			logger.info(e.getLocalizedMessage());
		}
		logger.info("test2");
		logger.info(myPESession.isRegionInitialized());
		String rosterName= "DefaultRoster";
		VWRoster roster = myPESession.getRoster(rosterName);
		logger.info("Workflow Count: " + roster.fetchCount());
		}
		catch(Exception e)
		{
			logger.info("e.getMessage=" + e.getMessage());
		}*/


	}

}
