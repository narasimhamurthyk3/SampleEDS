package com.db.service;

import org.omg.Messaging.SyncScopeHelper;
import java.sql.*;
public class SampleDBConnection {

        public static void main(String args[]){
                getDBRecords();
            //updateDBRecords();
        }

        public static void getDBRecords(){
            try{
                Class.forName("com.mysql.cj.jdbc.Driver");
                Connection con=DriverManager.getConnection(
                        "jdbc:mysql://192.168.99.100:3306/sample-db","root","root");
                Statement stmt=con.createStatement();
                ResultSet rs=stmt.executeQuery("select TEAMNAME,NAME from Users");

                while(rs.next())
                    //System.out.println(rs.getInt(1)+"  "+rs.getString(2)+"  "+rs.getString(3)+"  "+rs.getString(4));
             //   System.out.println(rs.getString(1));
                System.out.println(rs.getString("NAME"));
                con.close();
            }catch(Exception e){
                System.out.println(e);
            }

        }

    public static void updateDBRecords(){
        try{
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection con=DriverManager.getConnection(
                    "jdbc:mysql://192.168.99.100:3306/sample-db","root","root");
            Statement stmt=con.createStatement();
            String sql = "UPDATE Users " +
                    "SET name = 'NEWNAME' WHERE id in (1)";
            stmt.executeUpdate(sql);

        }catch(Exception e){
            System.out.println(e);
        }

    }



}
