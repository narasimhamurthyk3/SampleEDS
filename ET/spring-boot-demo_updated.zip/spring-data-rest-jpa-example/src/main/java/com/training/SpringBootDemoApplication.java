package com.training;

import com.training.model.User;
import com.training.repository.UserJpaRespository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.stereotype.Component;

@SpringBootApplication
		public class SpringBootDemoApplication {

			public static void main(String[] args) {
				SpringApplication.run(SpringBootDemoApplication.class, args);
			}
		}

	/*	@Component
		class DemoCommandLineRunner implements CommandLineRunner{
			@Autowired
			private UserJpaRespository userJpaRepo;

			@Override
			public void run(String... args) throws Exception {
				User user1 = new User();
				user1.setName("Jack");
				user1.setTeamName("TEAM01");
				user1.setSalary(1000);
				userJpaRepo.save(user1);

			}
		}*/