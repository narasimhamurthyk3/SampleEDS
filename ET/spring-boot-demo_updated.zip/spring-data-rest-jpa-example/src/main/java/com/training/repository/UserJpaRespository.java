package com.training.repository;

import com.training.model.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Component
public interface UserJpaRespository extends JpaRepository<User, Long>{

    List<User> findByName(String name);

    User findByNameAndSalary(String name, int salary);


    List<User> findByTeamName(String teamName);


    @Query("SELECT t FROM User t WHERE t.name=?")
    User findByQuery(String salary);


    User getById(Long id);

    @Transactional
    String removeUserById(Long Id);

    @Transactional
    void deleteAll();
}
