package com.cognizant.ecmservice.config;

import java.util.Collections;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import springfox.documentation.builders.PathSelectors;
import springfox.documentation.builders.RequestHandlerSelectors;
import springfox.documentation.service.ApiInfo;
import springfox.documentation.service.Contact;
import springfox.documentation.spi.DocumentationType;
import springfox.documentation.spring.web.plugins.Docket;
import springfox.documentation.swagger2.annotations.EnableSwagger2;

@Configuration
@EnableSwagger2
public class SwaggerConfig {

	  @Bean
	  public Docket swaggerConfiguration() {
		  
		  return new Docket(DocumentationType.SWAGGER_2)
				  .select()
				 // .paths(PathSelectors.ant("/sync/*"))
				  .apis(RequestHandlerSelectors.basePackage("com.cognizant.ecmservice.controllers"))
				  .build()
				  .apiInfo(apiDetails());
	  }
	  
	  
	  private ApiInfo apiDetails() {
		  return new ApiInfo(
				  "ECM SMART SERVICE APIS",
				  "KAFKA AND FILENET INTEGRATION IN SPRING BOOT",
				  "1.0",
				  "free",
				  new springfox.documentation.service.Contact("Cognizant Technology Solutions", "www.cognizant.com", "inquiry@cognizant.com"),
				  "©2020 Cognizant, all rights reserved",
				  "http://10.242.29.218:9082/ecmservice",
				 Collections.emptyList());
				  
		
	  }
	  
	  
}