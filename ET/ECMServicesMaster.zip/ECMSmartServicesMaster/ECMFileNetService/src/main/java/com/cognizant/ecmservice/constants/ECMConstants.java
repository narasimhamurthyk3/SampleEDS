package com.cognizant.ecmservice.constants;

public class ECMConstants {
	public static final String DESCRIPTION_SUCCESS_MESSAGE="Document operation completed successfully";
	public static final String DESCRIPTION_FAILURE_MESSAGE="Document operation failed Please check the logs for further Information";
	public static final String XML_VALIDATION_MESSAGE="Could not Parse";
	public static final String FOR="for";
	public static final String SPACE= " ";
	public static final String PROPERTY= "property";
	public static final String FOLDER_DESCRIPTION_SUCCESS_MESSAGE="Folder operation completed successfully";
	public static final String FOLDER_DESCRIPTION_FAILURE_MESSAGE="Folder operation failed";
	public static final String FOLDER_FAILURE_MESSAGE="Folder operation failed Please check the logs for further Information";
	public static String APPLICATION ="APPLICATION";
	public static String INFO_CONTRIBUTOR ="ECM FILENET SERVICE";
		
	//*********************DOCUMENT SERVICES*************************//
	public static final String CHECKOUT_DOCUMENT ="checkOutDocument";
	public static final String CANCEL_CHECKOUT_DOCUMENT = "cancelCheckoutDocument";
	public static final String GET_DOCUMENT_VERSIONLIST = "getDocumentVersionList";
	public static final String CHECKIN_DOCUMENT= "checkInDocument";
	public static final String SET_CONTENET_ELEMENT= "setContentElement";	
	public static final String GET_DOCUMENT_CONTENT ="getDocumentContent";
	public static final String CREATE_DOCUMENT = "createDocument";
	public static final String DELETE_DOCUMENT = "deleteDocument";
	public static final String GET_CONTENT_SIZE= "getContentSize";
	public static final String GET_DOCUMENT_PROPERTIES= "getDocumentProperties";
	public static final String CHANGE_DOCUMENT_CLASS ="changeDocumentClass";
	public static final String GET_CONTENET_ELEMENTS = "getContentElements";
	public static final String MOVE_CONTENT = "moveContent";	
	public static final String DELET_ANNOTATION= "deleteAnnotation";	
	public static final String GET_ANNOTATION= "getAnnotations";
	public static final String CREATE_ANNOTATION= "createAnnotation";
	public static final String UPDATE_DOCUMENT_PROPERTIES= "updateDocumentProperties";
		
	
	//**********************PROCESS ENGINE SERVICES *************************//
	public static final String GET_QUEUE_LIST ="getQueueList";
	public static final String GET_QUEUE_ELEMENT = "getQueueElement";
	public static final String GET_QUEUE_ELEMENT_COUNT = "getQueueElementCount";
	public static final String GET_STEP_ELEMENT= "getStepElement";
	public static final String SET_STEP_ELEMENET_PROPERTIES= "setStepElementProperties";
	public static final String GET_ROSTER_ELEMENT_COUNT ="getRosterElementCount";
	public static final String GET_ROSTER_ELEMENT = "getRosterElement";
	public static final String GET_STEP_ELEMENT_ATTACHMENT = "getStepElementAttachment";
	public static final String LOCK_WORKITEM= "lockWorkItem";
	public static final String UNLOCK_WORKITEM= "unlockWorkItem";
	public static final String ASSIGN_WORKITEM= "assignWorkItem";
	public static final String GET_RESPONSES= "getResponses";
	public static final String DISPATCH_WORKITEM= "dispatchWorkItem";
	public static final String TERMINATE_WORKITEM= "terminateWorkItem";
	public static final String DELETE_WORKITEM= "deleteWorkItem";
	public static final String LAUNCH_WORKITEM= "launchWorkItem";
	public static final String ADD_ATTACHMENT= "addAttachment";
	public static final String REMOVE_ATTACHMENT= "removeAttachment";
	public static final String GET_WORKITEM_STATUS= "getWorkItemStatus";
	


	//*********************CUSTOM OBJECT SERVICES*************************//
	public static final String GET_CUSTOMOBJECT ="getCustomObject";
	public static final String GET_CUSTOMOBJECT_PROPERTIES ="getCustomObjProperties";
	public static final String UPDATE_CUSTOMOBJECT_PROPERTIES ="updateCustomObjProperties";
	public static final String CREATE_CUSTOMOBJECT ="createCustomObject";

	
	//*********************FOLDER SERVICES*************************//

	
	public static final String GET_FOLDER_PATH ="getFolderPath";
	public static final String SET_FOLDER_NAME ="setFolderName";
	public static final String GET_CONTAINEES ="getContainees";
	public static final String GET_CONTAINED_DOCUMENTS ="getContainedDocuments";

	public static final String GET_FOLDER_PROPERTIES ="getFolderProperties";
	public static final String GET_SUB_FOLDERS ="getSubFolders";
	public static final String SET_PARENET ="setParent";
	public static final String UPDATE_FOLDER_PROPERTIES ="updateFolderProperties";
	public static final String CREATE_FOLDER ="createFolder";
	public static final String DELETE_FOLDER ="deleteFolder";
	
	public static final String GET_FOLDER_NAME ="getFolderName";
	public static final String GET_PARENT ="getParent";
	public static final String GET_PATH_NAME ="getPathName";
	public static final String FILE_DOCUMENT ="fileDocument";
	public static final String UNFILE_DOCUMENT ="unfileDocument";
	
	//*********************SEARCH SERVICES*************************//
	public static final String SEARCH_DOCUMENTS ="searchDocuments";
	
	
	//*********************CASE SERVICES*************************//
	public static final String CREATE_CASE ="createCase";
	public static final String CREATE_CASE_COMMENTS ="createCaseComments";
	public static final String GET_CASE_COMMENTS ="getCaseComments";
	public static final String GET_CASE_HISTORY ="getCaseHistory";
	public static final String GET_CASE_TASKS ="getCaseTasks";
	public static final String CREATE_TASK ="createTask";
	public static final String GET_CASE_STATUS ="getCaseStatus";
	public static final String GET_CASE_PROPERTIES ="getCaseProperties";
	public static final String SET_CASE_PROPERTIES ="setCaseProperties";
	public static final String DELETE_CASE ="deleteCase";
	public static final String GET_TASK_PROPERTIES ="getTaskPropeties";
	public static final String SET_TASK_PROPERTIES ="setTaskProperties";
	public static final String TERMINATE_TASK ="terminateTask";		
	public static final String UNFILE_CASE_DOCUMENT ="unfileCaseDocument";
	public static final String LINK_CASES ="linkCases";
	public static final String DELETE_CASE_DOCUMENT ="deleteCaseDocument";
	public static final String DELETE_TASK ="deleteTask";
	
	
	public static final String ASYNC="async";
	public static final String SYNC="sync";	
	public static final String DOCUMENT_SERVICE ="documentService";
	public static final String PE_SERVICE ="peService";
	public static final String FOLDER_SERVICE ="folderService";
	public static final String CO_SERVICE ="coService";
	public static final String CASE_SERVICE ="caseService";
	public static final String SEARCH_SERVICE ="searchService";
	public static final String STUDENT_SERVICE ="studentService";	
	public static final String ECM_SMART_SERVICE ="ECM_FILENET_SERVICE";	
	public static final String ECM_SMART_CONTROLLER ="CONTROLLER";
	
}
