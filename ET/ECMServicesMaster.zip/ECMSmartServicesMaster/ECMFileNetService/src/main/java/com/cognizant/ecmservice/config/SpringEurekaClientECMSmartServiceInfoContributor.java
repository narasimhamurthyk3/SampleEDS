package com.cognizant.ecmservice.config;

import org.springframework.boot.actuate.info.Info;
import org.springframework.boot.actuate.info.InfoContributor;
import org.springframework.stereotype.Component;
import com.cognizant.ecmservice.constants.ECMConstants;



@Component
public class SpringEurekaClientECMSmartServiceInfoContributor implements InfoContributor {

	@Override
	public void contribute(Info.Builder builder) {

		builder.withDetail(ECMConstants.APPLICATION, ECMConstants.INFO_CONTRIBUTOR);
	}



}
