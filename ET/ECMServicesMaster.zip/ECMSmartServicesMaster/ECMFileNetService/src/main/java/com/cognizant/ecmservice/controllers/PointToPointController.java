package com.cognizant.ecmservice.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RefreshScope
public class PointToPointController {
	
	
	@Value("${msg:Hello from Server-1}")
	private String msg;
	
	@Autowired
	Student studnetObj; 
	
		
	@PostMapping(value = "/studentService")
	public Student executestudentServiceRequest(@RequestBody  Student studentRequest) {
		System.out.println("Inside Controller::studentRequest");
		System.out.println("studentRequest::"+studentRequest.toString());			
		studnetObj.setName("FROM POINT TO POINT CONTROLLER:: "+studentRequest.getName().toUpperCase());
		return studnetObj;
	}
	
	
	@GetMapping(value = "/hello")
	public String getHello() {
		System.out.println("Inside Controller::getHello");
		return "Hello...........";
	}
	
	@GetMapping(value = "/hello1")
	public String getHello1() {
		System.out.println("Inside Controller::getHello");
		return msg;
	}

}
