package com.cognizant.ecmservice.controllers;

public class Student {


	String name;
	int Age;
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getAge() {
		return Age;
	}
	public void setAge(int age) {
		Age = age;
	}


}
