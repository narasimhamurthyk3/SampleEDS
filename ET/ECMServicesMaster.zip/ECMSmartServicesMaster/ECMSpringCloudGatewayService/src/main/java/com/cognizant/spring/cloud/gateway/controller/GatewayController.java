package com.cognizant.spring.cloud.gateway.controller;

import java.util.Date;

import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import reactor.core.publisher.Mono;

@RestController
public class GatewayController {    
    
    @PostMapping("/filenetservicefallback")
    public String filenetservicefallback() {
        return "ECM Gateway Service:: No Response From FileNet Service at this moment. Service will be back shortly - " + new Date();
    }
        
    @PostMapping("/kafkaservicefallback")
    public String kafkaservicefallback() {
        return "ECM Gateway Service:: No Response From Kafka Service at this moment. Service will be back shortly - " + new Date();
    }
    
    @PostMapping("/authservicefallback")
    public String authservicefallback() {
        return "ECM Gateway Service:: No Response From Authorization Service at this moment. Service will be back shortly - " + new Date();
    }
          
}
