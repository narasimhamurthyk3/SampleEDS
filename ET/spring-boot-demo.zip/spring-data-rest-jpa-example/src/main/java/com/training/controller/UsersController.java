package com.training.controller;

import com.training.model.User;
import com.training.repository.UserJpaRespository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/users")
public class UsersController {

	/** The JPA repository */
    @Autowired
    private UserJpaRespository userJpaRespository;


    @GetMapping(value = "/{name}")
    public User findByName(@PathVariable final String name){
        return userJpaRespository.findByName(name);
    }


    /**
	 * Used to fetch all the users from DB
	 * 
	 * @return list of {@link User}
	 */
    @GetMapping(value = "/all")
    public List<User> findAll() {
        return userJpaRespository.findAll();
    }

    /**
	 * Used to find and return a user by name
	 * 
	 * @param name refers to the name of the user
	 * @return {@link User} object
	 */

    @GetMapping(value = "/nameAndSalary")
    public User findByNameSalary(@RequestParam String name,
                           @RequestParam int salary){
        return userJpaRespository.findByNameAndSalary(name,salary);
    }

    @GetMapping(value = "/team/{teamName}")
    public List<User> findByTeamName(@PathVariable final String teamName){
        return userJpaRespository.findByTeamName(teamName);
    }
    @GetMapping(value = "/name/{testQuery}")
    public User findByQuery(@PathVariable final String testQuery){
        return userJpaRespository.findByQuery(testQuery);
    }
    /**
	 * Used to create a User in the DB
	 * 
	 * @param users refers to the User needs to be saved
	 * @return the {@link User} created
	 */
    @PostMapping(value = "/load")
    public User load(@RequestBody final User users) {
        userJpaRespository.save(users);
        return userJpaRespository.findByName(users.getName());
    }
    @PostMapping(value = "/update")
    public User updateUser(@RequestBody final User user) {
        User userToUpdate = userJpaRespository.getById(user.getId());
        userToUpdate.setName(user.getName());
        userJpaRespository.save(userToUpdate);
        return userJpaRespository.findByName(user.getName());
    }

    @DeleteMapping(value = "/delete")
    public String deleteUser(@RequestBody final User user) {
        User userToDelete = userJpaRespository.getById(user.getId());
        userJpaRespository.removeUserById(userToDelete.getId());
        return "Successfully deleted user:"+user.getName();
    }

    @DeleteMapping(value = "/deleteall")
    public String deleteAll() {
        userJpaRespository.deleteAll();
        return "Successfully deleted all users";
    }
}
