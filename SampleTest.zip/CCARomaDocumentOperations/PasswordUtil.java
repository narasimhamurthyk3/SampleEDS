package com.ecms.chubb.data.migration.adaptor.util;

import java.util.Properties;
import java.util.Scanner;
import org.apache.log4j.Logger;

import com.chubb.encryption.Encryption;

/**
 * 
 * @author kzpxxx
 * 
 */

public final class PasswordUtil implements AdaptorConstants, ExceptionConstants {

	private static PasswordUtil passwordUtil;
	/**
	 * Logger instance.
	 */
	private static final Logger LOGGER = Logger.getLogger(PasswordUtil.class);

	/**
	        * 
	         */
	protected PasswordUtil() {
	}

	/**
	        * 
	         */
	public static PasswordUtil getInstance() {
		if (passwordUtil == null) {
			passwordUtil = new PasswordUtil();
		}
		return passwordUtil;
	}

	/**
	 * 
	 * @param password
	 * @return
	 */
	public String encrypt(String plainText) {
		try {
			Properties aesProps = new Properties();
            aesProps.load(PasswordUtil.class.getClassLoader().getResourceAsStream(AES_PROP_FILE));
			return Encryption.getResult("E", aesProps.getProperty(AES_CIPHER) , plainText);
		} catch (Exception e) {
			LOGGER.error("EXCEPTION OCCURED WHILE DOING PASSWORD ENCRYPTION :: ", e);
		}
		return null;
	}

	/**
	 * 
	 * @param password
	 * @return
	 */
	public String decrypt(String encryptedText) {
		try {
			Properties aesProps = new Properties();
            aesProps.load(PasswordUtil.class.getClassLoader().getResourceAsStream(AES_PROP_FILE));
			return Encryption.getResult("D", aesProps.getProperty(AES_CIPHER) , encryptedText);
		} catch (Exception e) {
			LOGGER.error("EXCEPTION OCCURED WHILE DOING PASSWORD DECRYPTION :: ", e);
		}
		return null;
	}

	/**
	 * 
	 * @param args
	 */
	public static void main(String[] args) {
		try {
			LOGGER.info("REQUEST PASSWORD ENCRYPTION");
			Scanner scanner = new Scanner(System.in);
			System.out.print("ENTER THE STRING PASSWORD	:: ");
			String pwd = scanner.next();
			PasswordUtil passwordUtil = new PasswordUtil();
			if (pwd != null) {
				System.out.print("ENCRYPTED STRING :: " + passwordUtil.encrypt(pwd));
			}
			scanner.close();
		} catch (Exception e) {
			LOGGER.error("EXCEPTION OCCURED WHILE DOING PASSWORD ENCRYPTION :: ", e);
		}
	}

}
