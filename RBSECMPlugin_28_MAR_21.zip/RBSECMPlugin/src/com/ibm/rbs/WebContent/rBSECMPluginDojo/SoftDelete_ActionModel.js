define(["dojo/_base/declare", 
        "ecm/model/Action", 
        "ecm/widget/dialog/BaseDialog",
        "ecm/model/Desktop",
		"ecm/widget/dialog/MessageDialog",
		"dijit/ConfirmDialog",
		"ecm/widget/dialog/ConfirmationDialog"], 
		function(declare, Action, BaseDialog,Desktop,MessageDialog,ConfirmDialog,ConfirmationDialog) {
	return declare("rBSECMPluginDojo/SoftDelete_ActionModel", [Action], {
		
	
		
		isEnabled: function(repository, listType, items, teamspace, resultSet) {
			
			//debugger;
			
			var softDeleteDocStatus=items[0].attributes.DocumentStatus;
			if (softDeleteDocStatus == "Document Properties Review"){
				return false;
				
			}else{
				return true;
			}
			
		},

		isVisible: function(repository, listType, items) 
		{
			console.log("Inside isVisible")
			
			debugger;
			
			
					var isAuthorised = false;
					var serviceParams = new Object();					
					serviceParams.repositoryId= repository.id;
					serviceParams.osName = repository.objectStore.symbolicName;
					serviceParams.userId =repository.userId;
			
			
			
			
			var getUserHasSoftDeletePermission = ecm.model.Request.invokeSynchronousPluginService("RBSECMPlugin","GetUserHasSoftDeletePermission",serviceParams,
			{
				requestParams : serviceParams,
				requestCompleteCallback : function(response) 
				{
				}
			});
			
			
				
				if(getUserHasSoftDeletePermission.Status == "SUCCESS")
				{							
					return true;
				}
				else
				{							
					return false;
				}
			 	
			
			
			
			
	/*		if(getUserHasSoftDeletePermission.status=="SUCCESS")
			{
				return true;
			}else{
				return false;
			}
			*/
			
			
			
			
			/*
	var getUserhasSoftDeletePermission=ecm.model.Request.invokePluginService("RBSECMPlugin", "GetUserHasSoftDeletePermission",
				{
			requestParams: serviceParams,
			requestCompleteCallback: function(response) {	
				if(response){
					
					//resultSet.refresh();
					// success
					if(response.status=="SUCCESS"){

					console.log("user has permission")
						
					}else if(respose.status=="FAILURE"){
						
							console.log("user don't have permission")
					}

				}

			}
				});
			
			return true;*/
			
		
			
	/*		listType[0].template
			if(listType[0].template=="CCARomaInbound"){
				
				return true;
			}else {
				return false;
			}*/
		
		/*	
		 * Role based Authorization code. Which is repalced with Custom Object based security.
		 * 
		 * var isAuthorised = false;
			
			this.authorisedRole = this.propertiesValue.role;
			console.log(this.authorisedRole);
			
			console.log(this);
			
			this.currentUser = repository.userId;
			
			var roles = this.getActionContext("Role");
			console.log(roles[0]);
			
			this.currentRole = roles[0].auth_name;
			
			for ( var i = 0; i < this.authorisedRole.length; i++) {
				
				console.log(this.currentRole);
				console.log(this.authorisedRole[i]);
				
				if(this.currentRole == this.authorisedRole[i]){

					console.log("match Found...........");
					
					isAuthorised = true;
					
					console.log("breaking loop");
										
					break;
				}
			}
			
			console.log("isAuthorised");
			console.log(isAuthorised);
			console.log("isVisible end");
			
			return isAuthorised;
			
			*
			*  Role based Authorization code. Which is repalced with Custom Object based security.
			*/
		
	
					
		},
							
		performAction: function(repository, items, callback, teamspace, resultSet, parameterMap) 
		{
			this.logEntry("actionDeleteItem");
			var _this = this;
			var message;
			
			//debugger;
				if (this.confirmationDialog)
				this.confirmationDialog.destroy();
	
				var confirmationDialog = new ConfirmationDialog({				
				text: "Are you sure to soft delete document",
				buttonLabel: "Delete",
				cancelButtonDefault: true,
				deleteConfirmation: true,
				onExecute: function() {
					console.log("INSIDE EXEUTE")
					confirmationDialog.hide();
					debugger;
					//confirmDelete.hide();					
					var serviceParams = new Object();
					serviceParams.repositoryId= items[0].repository.id;
					serviceParams.osName = items[0].repository.objectStore.symbolicName;
					serviceParams.docid =items[0].docid;
					console.log("ID:"+items[0].docid)									
	ecm.model.Request.invokePluginService("RBSECMPlugin", "DocumentSoftDeleteService",
				{
			requestParams: serviceParams,
			requestCompleteCallback: function(response) {	
				if(response){
					
					resultSet.refresh();
					// success
					if(response.status=="SUCCESS"){

						var messageDialog = new MessageDialog();
						messageDialog.description.innerHTML ="Sucessfully Document Sent for SoftDelete";
						messageDialog.show();
					}else if(respose.status=="FAILURE"){
						var messageDialog = new MessageDialog();
						messageDialog.description.innerHTML ="Please contact system administator";
						messageDialog.show()
						
					}

				}

			}
				});
		
				}
			});
			confirmationDialog.show();
			//console.log("Exiting Soft Delete")
			//this.logExit("actionDeleteItem");
				
						//var messageDialog = new MessageDialog();
						//messageDialog.description.innerHTML ="Sucessfully Document Sent for SoftDelete";
						//messageDialog.show();
			
		}
	});
});