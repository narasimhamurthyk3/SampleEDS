require(["dojo/_base/declare",
	"dojo/_base/lang",
	"ecm/widget/dialog/MessageDialog",
	"dijit/ConfirmDialog",
	"ecm/widget/dialog/ConfirmationDialog",
	"ecm/model/Action"], 
	function(declare, lang,MessageDialog,ConfirmDialog,ConfirmationDialog,Action) {		
	/**
	 * Use this function to add any global JavaScript methods your plug-in requires.
	 */

	lang.setObject("softDelete", function(repository, items, callback, teamspace, resultSet, parameterMap) {
		/*
		 * Add custom code for your action here. For example, your action might launch a dialog or call a plug-in service.
		 */

		debugger;
		var serviceParams = new Object();
		serviceParams.repositoryId= items[0].repository.id;
		serviceParams.osName = repository.objectStore.symbolicName;
		serviceParams.docid =items[0].docid;
		ecm.model.Request.invokePluginService("RBSECMPlugin", "DocumentSoftDeleteService",
				{
			requestParams: serviceParams,
			requestCompleteCallback: function(response) {	
				if(response){
					// success
					if(response.successMessage=="YES"){

						var messageDialog = new MessageDialog();
						messageDialog.description.innerHTML ="Sucessfully Document Sent for SoftDelete";
						messageDialog.show();
					}else if(respose.successMessage=="SOFTDELETED"){

						var messageDialog = new MessageDialog();
						messageDialog.description.innerHTML ="Document already sent for soft delete";
						messageDialog.show();

					}else if(respose.successMessage=="NO"){
						var messageDialog = new MessageDialog();
						messageDialog.description.innerHTML ="Please contact system administator";
						messageDialog.show()
					}

				}

			}
				});



	});

	lang.setObject("confirmSoftDelete", function(repository, items, callback, teamspace, resultSet, parameterMap) {
		/*
		 * Add custom code for your action here. For example, your action might launch a dialog or call a plug-in service.
		 */
		//var faxPluginDialog = new FaxPluginDialog();
		//faxPluginDialog.show(repository, items);

		//var confirmationDialog=new ConfirmationDialog();

		//confirmationDialog.show();
		
		
		debugger;
/*		ecm.model.desktop.getActionsHandler(lang.hitch(this,function(actionhandler){
			
			if(actionhandler){
				debugger;
				actionhandler.actionDeleteItem(repository,items,function(){
					var messageDialog = new MessageDialog();
					messageDialog.showMessage("Document sucessfully deteleted...")									
				});
			}
		}));*/
		
		
		
		

		var confirmationDialog = new ConfirmationDialog({
			text: "Are you sure to delete document",
			buttonLabel: "Yes",
			title: "Document Soft Delete",
			deleteConfirmation: true,
			cancelButtonDefault: true,
			refocus: false,
			onExecute: function(repository,items,callback) {
				confirmationDialog.hide();
				//	self._itemEditPane._cancelOtherChanges();
				//self.onCancel();

				debugger;
				
				if (callback) {
					callback();
				}
				
				
				console.log("execute method")	
				var messageDialog = new MessageDialog();
				messageDialog.description.innerHTML ="Sucessfully Document Sent for SoftDelete";
				messageDialog.show()


				
				this.onCancel();
			}
		});

		confirmationDialog.show();
		/*	
	var confirmDialog = new ConfirmationDialog({
		text: this._itemEditPane._getCancelConfirmationMessage(),
		title: this.messages.close,
		buttonLabel: this.messages.yes,
		cancelButtonLabel: this.messages.no,
		cancelButtonDefault: true,
		onExecute: lang.hitch(this, function() {
			confirmDialog.hide();
			self._itemEditPane._cancelOtherChanges();
			self.onCancel();
		})
	});
	confirmDialog.show();*/






	});
});
