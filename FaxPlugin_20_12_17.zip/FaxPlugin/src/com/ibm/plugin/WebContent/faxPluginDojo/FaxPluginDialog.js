define([
"dojo/_base/declare",
"dijit/form/Button",
"dijit/_TemplatedMixin",
"dijit/_WidgetsInTemplateMixin",
"ecm/model/Desktop",
"ecm/MessagesMixin",
"ecm/widget/dialog/BaseDialog",
"ecm/widget/DatePicker",
"dojox/grid/EnhancedGrid",
"dojox/grid/enhanced/plugins/DnD",
"dojox/grid/enhanced/plugins/Menu",
"dojox/grid/enhanced/plugins/IndirectSelection",
"dojox/grid/enhanced/plugins/NestedSorting",
"dojo/data/ItemFileWriteStore",
"dojox/grid/cells/_base",
"dijit/Tooltip",
"dijit/Dialog",
"ecm/widget/dialog/MessageDialog",
"dojo/text!faxPluginDojo/templates/FaxPluginDialog.html"
],
function(declare, Button, _TemplatedMixin, _WidgetsInTemplateMixin, 
		Desktop,MessagesMixin,BaseDialog,DatePicker,
		EnhancedGrid,DnD,Menu,IndirectSelection,NestedSorting,ItemFileWriteStore,
		_base,Tooltip,Dialog,MessageDialog,template) {

	return declare("faxPluginDojo.FaxPluginDialog", [BaseDialog], {
		contentString: template,
		widgetsInTemplate: true,
		//disableCloseButton: true,
		_items: null,
		_repository: null,
		myGrid: null,
		
		postCreate: function() {
			console.log("test1");
			this.inherited(arguments);
			console.debug ("this.setSize");
			
			//this.setSize(650,400);
			this.setSize(650,270);
			this.setResizable(false);
			this.setMaximized(false);
			this.setTitle("OIDC Fax Service");
			console.debug ("this.setSize");
			//this.okButton = this.addButton("Ok", "_onClickOk", false, true);
			console.log("Postcreate completed",this);
			this.okButton = this.addButton("Send", "_onClickOk", false, true);
		
			console.debug("after ok button");
			//this._createGrid();
		},
		_onClickOk: function()
		{
			console.log("entered into OK button ");
			var FaxtoName = this.FaxtoName.get("value");
			console.log("FaxtoName::::", FaxtoName);
			var FaxFrom = this.FaxFrom.get("value");
			console.log("FaxFrom::::", FaxFrom);
			var FaxtoNumber = this.FaxToNumber.get("value");
			console.log("FaxtoNumber::::", FaxtoNumber);
			//var Contact = this.FromContact.get("value");
			//console.log("Contact::::", Contact);
			var FaxSubject = this.FaxSubject.get("value");
			console.log("FaxSubject::::", FaxSubject);
			var FaxNotes = this.FaxNotes.get("value");
			console.log("Faxnotes::::", FaxNotes);



			var serviceParams = new Object;
			serviceParams.FaxtoName= FaxtoName;
			serviceParams.FaxtoNumber= FaxtoNumber;
			serviceParams.repositoryId= this._repository.id;
			serviceParams.osName = this._items[0].objectStore.symbolicName;
			serviceParams.docid = this._items[0].id;
			serviceParams.FaxFrom=FaxFrom;
			serviceParams.FaxSubject=FaxSubject;
			serviceParams.FaxNotes=FaxNotes;


			ecm.model.Request.invokePluginService("FaxPlugin", "FaxPluginService",
					{
				requestParams: serviceParams,
				requestCompleteCallback: function(response) {	
					if(response){
						// success
						
						if(response.ErrorMessage!=null){
							
							var messageDialog = new MessageDialog();
							messageDialog.description.innerHTML =response.ErrorMessage;
							messageDialog.show();
							this.hide();
							
						}
						else
						if(response.success=="true"){

							var messageDialog = new MessageDialog();
							messageDialog.description.innerHTML ="Document sent";
							messageDialog.show();
							this.hide();
						}


					}

				}
					});

		},
		show: function(repository, items)
		{
			console.debug("Inside function Show",this);
			this._items=items;
			this._repository=repository;
			this.DocId.set('value',items[0].id);
			this.DocName.set('value',items[0].name);
			console.log("Name::::", items[0].name);
			console.log("UserID::::", items[0].userId);
			
			
			
			var userName = ecm.model.desktop.userDisplayName;
			var userId = ecm.model.desktop.userId;
		
			console.log("userName::::", userName);
			console.log("userId::::", userId);
			
			this.FaxFrom.set('value',userId+"@att.com");
			
			this.inherited("show", []);


		}

	});
});
