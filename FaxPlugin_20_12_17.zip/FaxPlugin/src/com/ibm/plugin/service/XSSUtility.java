package com.ibm.plugin.service;

import java.io.IOException;
import java.io.StringWriter;
import java.io.Writer;
import java.util.HashMap;
import java.util.regex.Pattern;

import org.apache.log4j.Category;
import org.owasp.esapi.ESAPI;

public class XSSUtility {
	static final Category log = Category.getInstance(XSSUtility.class);
	public static final HashMap m = new HashMap();
	static {

		m.put(34, "&quot;"); // < - double qoute
		m.put(60, "&lt;"); // < - less-than
		m.put(62, "&gt;"); // > - greater-than
		m.put(38, "&amp;"); // &
		m.put(39, "&apos;"); //
		m.put(37, "&#37;"); // percentage
		m.put(39, "&#39;"); // single quote
		m.put(59, "&#59;"); // semicolon
		m.put(40, "&#40;"); // left parenthesis
		m.put(41, "&#41;"); // right parenthesis
		m.put(123, "&#123;"); // right curly bracket
		m.put(125, "&#125;"); // left curly bracket
		m.put(10, ""); // line feed
		m.put(33, "&#33;"); // exclamation mark
	}

	public boolean contains(String str) throws Exception {

		boolean InvalidUserData = false;

		if (str != null && !str.trim().equals("")) {

			StringBuffer buffer = new StringBuffer();
			int len = str.length();
			for (int i = 0; i < len; i++) {
				char c = str.charAt(i);
				int ascii = (int) c;
				String entityName = (String) m.get(ascii);
				if (entityName == null) {
					if (c > 0x7F) {
						buffer.append("&#");
						buffer.append(Integer.toString(c, 10));
						buffer.append(';');
					} else {
						buffer.append(c);
					}
				} else {

					InvalidUserData = true;

				}
			}

		}

		return InvalidUserData;
	}

}
