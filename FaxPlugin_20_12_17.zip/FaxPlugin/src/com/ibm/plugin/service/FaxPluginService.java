package com.ibm.plugin.service;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.FileNameMap;
import java.net.URLConnection;
import java.util.Iterator;
import java.util.Random;
import java.util.StringTokenizer;

import javax.security.auth.Subject;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Category;
import org.apache.log4j.Logger;

import com.filenet.api.collection.ContentElementList;
import com.filenet.api.constants.RefreshMode;
import com.filenet.api.core.ContentTransfer;
import com.filenet.api.core.Document;
import com.filenet.api.core.Domain;
import com.filenet.api.core.Factory;
import com.filenet.api.core.ObjectStore;
import com.filenet.api.property.Properties;
import com.filenet.api.util.UserContext;
import com.ibm.ecm.extension.PluginResponseUtil;
import com.ibm.ecm.extension.PluginService;
import com.ibm.ecm.extension.PluginServiceCallbacks;
import com.ibm.ecm.json.JSONResponse;
import com.ibm.plugin.FaxPluginLog4j;
import com.sun.xml.internal.ws.util.StringUtils;

/**
 * Provides an abstract class that is extended to create a class implementing
 * each service provided by the plug-in. Services are actions, similar to
 * servlets or Struts actions, that perform operations on the IBM Content
 * Navigator server. A service can access content server application programming
 * interfaces (APIs) and Java EE APIs.
 * <p>
 * Services are invoked from the JavaScript functions that are defined for the
 * plug-in by using the <code>ecm.model.Request.invokePluginService</code>
 * function.
 * </p>
 * Follow best practices for servlets when implementing an IBM Content Navigator
 * plug-in service. In particular, always assume multi-threaded use and do not
 * keep unshared information in instance variables.
 */
public class FaxPluginService extends PluginService {
	
	//Logger logger = Logger.getLogger(this.getClass()); 
	private static final Logger logger = Logger.getLogger(FaxPluginService.class);

	/**
	 * Returns the unique identifier for this service.
	 * <p>
	 * <strong>Important:</strong> This identifier is used in URLs so it must
	 * contain only alphanumeric characters.
	 * </p>
	 * 
	 * @return A <code>String</code> that is used to identify the service.
	 */
	public String getId() {
		return "FaxPluginService";
	}

	/**
	 * Returns the name of the IBM Content Navigator service that this service
	 * overrides. If this service does not override an IBM Content Navigator
	 * service, this method returns <code>null</code>.
	 * 
	 * @returns The name of the service.
	 */
	public String getOverriddenService() {
		return null;
	}

	/**
	 * Performs the action of this service.
	 * 
	 * @param callbacks
	 *            An instance of the <code>PluginServiceCallbacks</code> class
	 *            that contains several functions that can be used by the
	 *            service. These functions provide access to the plug-in
	 *            configuration and content server APIs.
	 * @param request
	 *            The <code>HttpServletRequest</code> object that provides the
	 *            request. The service can access the invocation parameters from
	 *            the request.
	 * @param response
	 *            The <code>HttpServletResponse</code> object that is generated
	 *            by the service. The service can get the output stream and
	 *            write the response. The response must be in JSON format.
	 * @throws Exception
	 *             For exceptions that occur when the service is running. If the
	 *             logging level is high enough to log errors, information about
	 *             the exception is logged by IBM Content Navigator.
	 */
	public void execute(PluginServiceCallbacks callbacks,
			HttpServletRequest request, HttpServletResponse response)
					throws Exception {
	
		FaxPluginLog4j faxPluginLog4j=new FaxPluginLog4j();
		//System.out.println("**********************Start of FaxPluginService*************************");
		logger.info("**********************Start of FaxPluginService*************************");

		XSSUtility xssutility = new XSSUtility();

		String ErrorMessage = null;
		String repositoryID = null;
		String osName = null;
		String id = null;
		String faxtoName = null;
		String faxtoNumber = null;
		String faxfromName = null;
		String faxSubject = null;
		String faxNotes = null;

		if (request.getParameter("FaxtoNumber") != null)
			faxtoNumber = request.getParameter("FaxtoNumber");

		if (request.getParameter("repositoryId") != null)

			repositoryID = request.getParameter("repositoryId");

		if (request.getParameter("osName") != null)
			osName = request.getParameter("osName");

		if (request.getParameter("docid") != null)
			id = request.getParameter("docid");
		if (request.getParameter("FaxtoName") != null)
			faxtoName = request.getParameter("FaxtoName");
		if (request.getParameter("FaxFrom") != null)
			faxfromName = request.getParameter("FaxFrom");

		if (request.getParameter("FaxSubject") != null)
			faxSubject = request.getParameter("FaxSubject");

		if (request.getParameter("FaxNotes") != null)
			faxNotes = request.getParameter("FaxNotes");


		logger.info("faxtoName from request : " + faxtoName);
		logger.info("faxtoNumber from request : " + faxtoNumber);
		logger.info("faxfromName from request:::: " + faxfromName);
		logger.info("faxSubject from request : " + faxSubject);
		logger.info("faxNotes from request : " + faxNotes);

		if (faxfromName == null || faxfromName.trim().equals("")) {
			
			ErrorMessage = "Please enter 'Fax From'";
		}
		else if (xssutility.contains(faxtoName)) {
			
			ErrorMessage = "Value entered for 'Fax To Name' is invalid. Only alphanumeric and special characters are allowed except  \" < > & ' % ; ( ) { } ; !";
		}
		else if (faxSubject == null || faxSubject.trim().equals("")) {
			
			ErrorMessage = "Please Enter 'Fax Subject'";

		} 
		else if (xssutility.contains(faxSubject)) {

			ErrorMessage = "Value entered for 'Fax Subject' is invalid. Only alphanumeric and special characters are allowed except  \" < > & ' % ; ( ) { } ; !";

		}

		else if (faxNotes == null || faxNotes.trim().equals("")) {
			
			ErrorMessage = "Please enter 'Fax Notes'";

		}
		else if (xssutility.contains(faxNotes)) {

			ErrorMessage = "Value entered for 'Fax Notes' is invalid. Only alphanumeric and special characters are allowed except  \" < > & ' % ; ( ) { } ; !";

		}
		else if (faxtoNumber != null && !faxtoNumber.trim().equals("")) {

			try {
				faxtoNumber = faxtoNumber.trim();
				long Param1 = Long.parseLong(faxtoNumber);
			} catch (NumberFormatException e) {
				
				ErrorMessage = "'Fax To Number' entered is invalid";

			}
		} 



		else

		{
			ErrorMessage = null;
		}

		if (ErrorMessage == null) {

			if (faxtoName != null && !faxtoName.trim().equals("")) {



				faxtoName = faxtoName.replaceAll(" ", "%20");
			} 


			else {
				faxtoName = "No%20Name%20for%20Fax%20receiver";
			}

			if (faxtoNumber != null && !faxtoNumber.trim().equals("")) {

				try {
					long faxNumber_temp = Long.parseLong(faxtoNumber);
					faxtoNumber = String.valueOf(faxNumber_temp);

					faxtoNumber = "/FAX=" + faxtoNumber + "/Name=" + faxtoName
							+ "@rfax.att.com";

					// faxtoNumber = "/FAX=" + "8476985762" + "/Name=" +
					// faxtoName
					// + "@rfax.att.com";
				} catch (NumberFormatException e) {
					
					ErrorMessage = "'Fax To Number' entered is invalid";
				
					// Exception("The FAX number entered is not valid.");
				}

			} else {

				faxtoNumber = "/FAX=214-761-8211/Name=" + faxtoName
						+ "@rfax.att.com";
			}

			if (faxfromName == null || faxfromName.trim().equals("")) {
				faxfromName = "M15184@txmail.sbc.com";
			}

			StringTokenizer docIdTok = new StringTokenizer(id, ",");

			String classId = (docIdTok.hasMoreTokens() ? docIdTok.nextToken()
					: null);
			String objectStoreId = (docIdTok.hasMoreTokens() ? docIdTok
					.nextToken() : null);
			String docId = (docIdTok.hasMoreTokens() ? docIdTok.nextToken()
					: null);

			Subject subject = callbacks.getP8Subject(repositoryID);
			UserContext.get().pushSubject(subject);
			Domain domain = callbacks.getP8Domain(repositoryID, null);

			ObjectStore os = Factory.ObjectStore.fetchInstance(domain, osName,null);
			logger.info("Connected to content Engine");
			Document document = Factory.Document.fetchInstance(os, docId, null);

			SendFileToFax sft = new SendFileToFax();

			String fileName = document.get_Name();
			String mimeType = document.get_MimeType();
			logger.info("Document mimeType fetched from FileNet is :" + mimeType);
			String document_id = document.get_Id().toString();
			logger.info("Document ID fetched from FileNet is :" + document_id);
			logger.info("Document Name fetched from FileNet is :" + fileName);
			document_id = document_id.replace("{", "");
			document_id = document_id.replace("}", "");
			document_id = document_id + getGaussian();

			String documentExtension = findFileType(mimeType);

			if (!mimeType.equalsIgnoreCase(Messages.getString("CE.MIME.TIFF"))) {

				fileName = fileName + documentExtension;

			}

			ContentTransfer contentTransfer = (ContentTransfer) document
					.get_ContentElements().get(0);
			InputStream initialStream = contentTransfer.accessContentStream();
			String dir = "." + File.separator + document_id + File.separator;
			String path = dir + fileName;
			File targetFile = new File(path);
			targetFile.getParentFile().mkdirs();
			targetFile.createNewFile();

			// byte[] buffer = new byte[initialStream.available()];
			// initialStream.read(buffer);
			// OutputStream outStream = new FileOutputStream(targetFile);
			// outStream.write(buffer);

			OutputStream outStream = new FileOutputStream(targetFile);
			byte[] buffer = new byte[1024];
			int len;
			while ((len = initialStream.read(buffer)) != -1) {
				outStream.write(buffer, 0, len);
			}

			outStream.flush();
			initialStream.close();
			buffer = null;
			outStream.close();
			UserContext.get().popSubject(); // To Close CE Connection
			logger.info("Content Engine connection closed");
			sft.sendFax(faxtoNumber, faxfromName, faxSubject, faxNotes,
					targetFile);
			deleteDir(new File(dir));
			/*
			 * // Get content elements and iterate list. ContentElementList
			 * docContentList = document.get_ContentElements(); Iterator iter =
			 * docContentList.iterator(); while (iter.hasNext()) {
			 * ContentTransfer ct = (ContentTransfer) iter.next();
			 * 
			 * InputStream stream = ct.accessContentStream(); String readStr =
			 * ""; try { int docLen = 1024; byte[] buf = new byte[docLen]; int n
			 * = 1; while (n > 0) { n = stream.read(buf, 0, docLen); readStr =
			 * readStr + new String(buf); buf = new byte[docLen]; } //
			 * logger.info("Content:\n " + readStr); stream.close(); } catch
			 * (IOException ioe) { ioe.printStackTrace(); } }
			 */

			JSONResponse responseJSON = new JSONResponse();
			responseJSON.put("success", "true");
			responseJSON.put("ErrorMessage", ErrorMessage);
			logger.info("**********************End of FaxPluginService***************************");
			PluginResponseUtil.writeJSONResponse(request, response,
					responseJSON, callbacks, "FaxPluginService");
		} else {
			logger.info("Validation ErrorMessage::" + ErrorMessage);
			logger.info("************************************************************************");
			JSONResponse responseJSON = new JSONResponse();
			responseJSON.put("ErrorMessage", ErrorMessage);
			PluginResponseUtil.writeJSONResponse(request, response,
					responseJSON, callbacks, "FaxPluginService");

		}
	}

	private String findFileType(String myType) {
		logger.info("Inside find fileTyp ---> Started");
		String fileTypeExtension = null;

		if (myType.equalsIgnoreCase(Messages.getString("CE.MIME.PDF"))) {

			fileTypeExtension = ".pdf";
		} else if (myType.equalsIgnoreCase(Messages.getString("CE.MIME.XLSX"))) {

			fileTypeExtension = ".xlsx";
		} else if (myType.equalsIgnoreCase(Messages.getString("CE.MIME.WORDDOC"))) {

			fileTypeExtension = ".docx";
		}

		else if (myType.equalsIgnoreCase(Messages.getString("CE.MIME.TEXTDOC"))) {

			fileTypeExtension = ".txt";
		}

		else if (myType.equalsIgnoreCase(Messages.getString("CE.MIME.IMAGE"))) {

			fileTypeExtension = ".jpg";
		}

		else if (myType.equalsIgnoreCase(Messages.getString("CE.MIME.TIFF"))) {

			fileTypeExtension = ".tif";
		} 
		else if (myType.equalsIgnoreCase(Messages.getString("CE.MIME.PNG"))) {

			fileTypeExtension = ".png";
		}
		else {

			logger.info("Unknown document MIME type.");
		}
		logger.info("fileTypeExtension::"+fileTypeExtension);
		logger.info("Inside find fileTyp ---> Finished");

		return fileTypeExtension;

	}

	private double getGaussian() {
		double MEAN = 100.0f;
		double VARIANCE = 5.0f;

		Random random = new Random();
		return MEAN + random.nextGaussian() * VARIANCE;
	}

	private void deleteDir(File file) {

		File[] contents = file.listFiles();
		if (contents != null) {
			for (File f : contents) {
				deleteDir(f);
			}
		}
		file.delete();

	}



}
