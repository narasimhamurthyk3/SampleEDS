package com.ibm.plugin.service;

//package com.ibm.plugin.service;

//import SendFax;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import javax.activation.DataHandler;
import javax.activation.FileDataSource;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Multipart;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.AddressException;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;

import org.apache.log4j.Category;
import org.apache.log4j.Logger;

import com.ibm.plugin.FaxPluginLog4j;


public class SendFileToFax {
	private static final Logger logger = Logger.getLogger(SendFileToFax.class);
	 
	public void sendFax(String faxtoNumber,String faxfromName, String faxSubject, String faxNotes, File file) {
		FaxPluginLog4j faxPluginLog4j=new FaxPluginLog4j();
		logger.info("SendFileToFax: sendFax ---> Started");
		
		Properties properties = new Properties();
		properties.put("mail.smtp.host", "smtp.sbc.com");
		Session session = Session.getInstance(properties);
		Message message = new MimeMessage(session);
		try {
			
			message.setFrom(new InternetAddress(faxfromName, false));
			message.setRecipients(Message.RecipientType.TO,InternetAddress.parse(faxtoNumber, false));
			message.setSubject(faxSubject);
			message.setContent(faxNotes, "text/html");
			setFileAsAttachment(message, faxNotes, file);
			message.saveChanges();
			Transport.send(message);
			logger.info("The Mail has been sent.");

		} catch (AddressException e) {
			// TODO Auto-generated catch block
			logger.info("Errpr::"+e.getStackTrace());	
			e.printStackTrace();
			
		} catch (MessagingException e) {
			// TODO Auto-generated catch block
			logger.info("Error::"+e.getStackTrace());	
			e.printStackTrace();
			
		}
		logger.info("SendFileToFax: sendFax ---> Finished");

	}

	private void setFileAsAttachment(Message mail, String mailBody,
			File targetFile) {

		logger.info("SendFileToFax: setFileAsAttachment ---> Started");

		// Create and fill first part
		try {
			// Instantiate MimeBodyPart
			MimeBodyPart mimeBody = new MimeBodyPart();
			// Set the message text
			mimeBody.setText(mailBody);

			// Create the Multipart.
			Multipart mimeMultiPart = new MimeMultipart();
			// Add BodyPart for the body to it.
			mimeMultiPart.addBodyPart(mimeBody);

			// File file = null;
			MimeBodyPart mimeAttachment = null;

			// Create part for the attachments
			mimeAttachment = new MimeBodyPart();
			FileDataSource fileDataSource = new FileDataSource(targetFile);
			mimeAttachment.setDataHandler(new DataHandler(fileDataSource));
			mimeAttachment.setFileName(fileDataSource.getName());
			mimeMultiPart.addBodyPart(mimeAttachment);
			logger.info("Added Body Part");

			// Set Multipart as the message's content
			mail.setContent(mimeMultiPart);
		} catch (SecurityException exception) {
			logger.info("SendFileToFax: setFileAsAttachment() - "
					+ "SecurityException while checking if attachment exists.\n"
					+ exception.getMessage());
		} catch (MessagingException exception) {
			logger.info("SendFileToFax: setFileAsAttachment()"
					+ " - MessagingException while setting file as Attachment.\n"
					+ exception.getMessage());
		} catch (NullPointerException exception) {
			logger.info("SendFileToFax: setFileAsAttachment()- "
					+ "NullPointerException while setting file as Attachment.\n"
					+ exception.getMessage());
		} catch (Exception exception) {
			logger.info("SendFileToFax: setFileAsAttachment()- Exception "
					+ "while setting file as Attachment.\n "
					+ exception.getMessage());
		}
		logger.info("SendFileToFax: setFileAsAttachment ---> Finished");

	}
}