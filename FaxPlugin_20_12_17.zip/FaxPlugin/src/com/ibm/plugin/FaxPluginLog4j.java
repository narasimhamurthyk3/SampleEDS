package com.ibm.plugin;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

public class FaxPluginLog4j {
	private static final Logger logger = Logger.getLogger(FaxPluginLog4j.class);
	static{
		final String LOG_PROPERTIES_FILE = "E:/NavigatorPluginJars/Config/log4j.properties";
		try { 
			Properties logProperties = new Properties();
			logProperties.load(new FileInputStream(LOG_PROPERTIES_FILE));
			PropertyConfigurator.configure(logProperties);
			logger.info("Log4j.properties file loaded successfully");
		} catch (IOException e) {
			System.out.println("Unable to load logging property");
			System.out.println("Exception::"+ e.getMessage());
			throw new RuntimeException("Unable to load logging property");
		}
	}
	
	public static void main(String[] args) {
		
		FaxPluginLog4j faxPluginLog4j=new FaxPluginLog4j();
		System.out.println("Inside Main");
		logger.info("Logger");
		
	}
	
	

}
