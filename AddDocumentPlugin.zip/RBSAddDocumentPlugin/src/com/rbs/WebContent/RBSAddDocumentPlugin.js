require(["dojo/_base/declare",
         "dojo/_base/lang",
         "dojo/aspect", 
         "ecm/model/Request",
         "ecm/widget/dialog/AddContentItemDialog"], 
         function(declare, lang, aspect, Request, AddContentItemDialog) {
    /**
     * Use this function to add any global JavaScript methods your plug-in requires.
     */

    lang.setObject("addClientDocument",
            function(repository, items, callback, teamspace, resultSet, parameterMap) {

    //	alert("HELLO ADDDOCUMENT ET");		
		console.log("INSIDE ADD_DOCUMENT_ET....");
                // Parameters passed to the service as HttpServletRequest
		
		debugger;
		var objectStore = repository.objectStore;
		
		var etClassName="AA";
		var etName="AA";
		
	//	var parentFolderid="{A031017A-0000-CC12-85EB-6CB645FE737E}";
		var parentFolder=repository.rootItem;
		var parentFolderid=repository.rootItem.id;
		var rproperties=null;
	    // First we'll retrieve all the templates
		
/*		repository.retrieveEntryTemplates(lang.hitch(this, 
				
				function (entryTemplates, document_ET_count, folder_ET_count) {
			
			  console.log("found et...");
			
		}));*/
		var entryTemplate = null;
	    repository.retrieveEntryTemplates(
	            function (entryTemplates, document_ET_count, folder_ET_count) {
	                
	                // Then we'll search for the one that we want
	                for (var i = 0; i < entryTemplates.length; i++) {
	                    if (entryTemplates[i] && entryTemplates[i].name == etName) {	                    	
                           // entryTemplates[i].addClassName == etClassName
	                    console.log(entryTemplates[i].addClassName);	
	                    	entryTemplate = entryTemplates[i];
	                    	//console.log(entryTemplate.addClassName);
	                    	console.log("EntryTemplateName:"+entryTemplate.name);
	                        console.log("found et...");
	                       break;
	                    }
	                }
	                // No Entry Template = abort.
	                if (!entryTemplate) {
	                    alert("The Entry Template " +
	                            "\"" + etClassName + "\" " +
	                            "was not found. Please contact the administrators");
	                    return;
	                }

	                // Now we got the Entry Template, time to retrieve its content
	                // First, we design a "waiter" object.
	                // We assume here the PluginService returns the values in
	                // the "properties" entry of the object response
	                retrievalWaiter =
	                    new RetrievalWaiter (repository,
	                                         objectStore,
	                                         parentFolder,
	                                         entryTemplate,
	                                         rproperties,
	                                         AddContentItemDialog,
	                                         aspect);
	                // Then a call to retrieve its content
	                entryTemplate.retrieveEntryTemplate(null, false, true);

	                // We ignite the waiter. When the retrieval will be performed,
	                // It will fill its default values and use it to display
	                // the creation document dialog.                    
	                retrievalWaiter.wait();
	       


	            }, "Document", null, null, objectStore);
	    
	    
	    
	    
	    
	    
	    function RetrievalWaiter(repository, objectStore, parentFolder,
                entryTemplate, properties,
                AddContentItemDialog, aspect) {
			this.repository = repository;
			this.objectStore = objectStore;
			this.parentFolder = parentFolder;
			this.entryTemplate = entryTemplate;
			this.properties = properties;
			this.aspect = aspect;
			this.wait = 
			function() {
			   // If the Entry Template is not yet loaded, wait 500 ms
			   // and recheck
			   if (!this.entryTemplate.isRetrieved) {
			       var _this = this;
			       setTimeout(function() {_this.wait();}, 500);                    
			       return;
			   }
			   // Fill the Entry Template with defaults value
			   // (got from the PluginServer response, see above)
			//   fillEntryTemplate(this.entryTemplate, this.properties);
			
			   // Show the document creation dialog with the 
			   showDialog(AddContentItemDialog,
			           this.aspect,
			           this.repository, this.objectStore,
			           this.parentFolder, this.entryTemplate);
			}
			}
				    

	    function showDialog(AddContentItemDialog, aspect,
	                        repository, objectStore,
	                        parentFolder,
	                        entryTemplate) {
	        var addContentItemDialog  = new AddContentItemDialog();
	        var addContentItemPropertiesPane =
	            addContentItemDialog.addContentItemPropertiesPane;
	        var addContentItemGeneralPane =
	            addContentItemDialog.addContentItemGeneralPane;

	        addContentItemDialog.show(
	                repository,
	                parentFolder,  // parent folder 
	                true,          // document being added
	                false,         // not virtual 
	                null,          // no callback function 
	                null,          // no teamspace 
	                true,          // Use an Entry Template 
	                entryTemplate, // Entry template 
	                true           // don't allow choosing directory
	                               // from another repository
	        );

	        // Use aspect to set the value *after* the complete rendering
	        // of the properties pane   
	        aspect.after(
	                addContentItemPropertiesPane,
	                "onCompleteRendering",
	                function() {
	                    addContentItemDialog.setTitle("Duplicate a document");
	                    addContentItemDialog.setIntroText(
	                            "This form is loaded from a right-clicked document.");
	                    // Removing the help link to make the form looks like
	                    // the document creation one
	                    // addContentItemDialog.setIntroTextRef("","");
	                    // Set parent folder and prevent it from being edited.
	                    addContentItemGeneralPane.folderSelector.setRoot(parentFolder, objectStore);
	                    addContentItemGeneralPane.folderSelector.setDisabled(true);

	                }, true);
	    }
           
            });
});