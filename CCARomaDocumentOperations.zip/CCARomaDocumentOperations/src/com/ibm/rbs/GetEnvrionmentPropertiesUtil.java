package com.ibm.rbs;



import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;

public class GetEnvrionmentPropertiesUtil
{
  private Context ctx = null;
  private static String filenetCE_URI = null;
  private static String filenetUserName = null;
  private static String filenetPassword = null;
  private static String jaasLoginModule = null;
  private static String objectStore = null;
  private static String obsoleteWaterMarkDirectory = null;
  
  public GetEnvrionmentPropertiesUtil()
    throws NamingException
  {
    this.ctx = new InitialContext();
  }
  
  public String getObjectStore()
    throws NamingException
  {
    objectStore = (String)this.ctx.lookup("ObjectStoreName");
    return objectStore;
  }
  
  public String getFilenetCE_URI()
    throws NamingException
  {
    filenetCE_URI = (String)this.ctx.lookup("CE_URI");
    return filenetCE_URI;
  }
  
  public String getFilenetUserName()
    throws NamingException
  {
    filenetUserName = (String)this.ctx.lookup("FilenetUserName");
    return filenetUserName;
  }
  
  public String getFilenetPassword()
    throws NamingException
  {
    filenetPassword = (String)this.ctx.lookup("FilenetPassword");
    return filenetPassword;
  }
  
  public String getJaasLoginModule()
    throws NamingException
  {
    jaasLoginModule = (String)this.ctx.lookup("JaasLoginModule");
    return jaasLoginModule;
  }
  
  public String getobsoleteWaterMarkDirectory()
    throws NamingException
  {
    obsoleteWaterMarkDirectory = (String)this.ctx.lookup("ObsoleteWaterMarkDirectory");
    return obsoleteWaterMarkDirectory;
  }
}

