package com.ecm.filenet.ECMSampleApp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EcmSampleAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
