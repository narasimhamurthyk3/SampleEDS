package com.agcs.icn.plugin.service.workers;

import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import com.agcs.icn.plugin.service.CopyDocsPluginLogger;
import com.filenet.api.collection.PropertyDescriptionList;
import com.filenet.api.constants.Cardinality;
import com.filenet.api.constants.TypeID;
import com.filenet.api.core.Document;
import com.filenet.api.meta.PropertyDescription;
import com.filenet.api.property.Properties;
import com.filenet.api.property.Property;
import com.filenet.api.util.Id;
import com.ibm.json.java.JSONArray;
import com.ibm.json.java.JSONObject;

public abstract class ArrayWorker extends BaseWorker {

	protected String objectStore = null;
	protected HashMap<String, String> targetProperties = new HashMap<String, String>();
	private Class<?> workerClass;

	public ArrayWorker(Class<?> workerClass) {
		this.workerClass = workerClass;
	}

	public JSONObject execute(String userId, JSONObject request) {

		// Get the target property from the payload
		JSONObject target = (JSONObject) request.get("target");
		CopyDocsPluginLogger.logDebug("Target property from payload::" + target, "ArrayWorker", "execute", userId);
		if (target == null)
			return buildExceptionPayload("Invalid request payload, source must be specified { \"target\": {} }");

		// Get the properties to update
		JSONArray tpa = (JSONArray) target.get("properties");
		CopyDocsPluginLogger.logDebug("properties::" + tpa, "ArrayWorker", "execute", userId);
		if (tpa == null)
			return buildExceptionPayload(
					"Invalid request payload, source must be specified { \"target\": { properties: [] } }");

		// Look through the properties and build the String:String hash
		targetProperties.clear(); // Clear the properties, PJ
		if (tpa.size() > 0) {
			for (int i = 0; i < tpa.size(); i++) {
				JSONObject prop = (JSONObject) tpa.get(i);

				String name = (String) prop.get("property");
				String value = (String) prop.get("value");
				CopyDocsPluginLogger.logDebug("propertyName::" + name, "ArrayWorker", "execute", userId);
				CopyDocsPluginLogger.logDebug("propertyValue::" + value, "ArrayWorker", "execute", userId);
				if (name == null)
					continue;

				targetProperties.put(name, value);
			}
		}

		// This worker processes an array of items that we'll fetch here
		ArrayUnit[] units = null;

		try {
			CopyDocsPluginLogger.logInfo("Build Array ot items", "ArrayWorker", "execute", userId);
			units = buildArray(request, userId);
		} catch (Exception ex) {
			CopyDocsPluginLogger.logException(ex, "ArrayWorker", "execute", userId);
			return buildExceptionPayload(ex, units);
		}

		// Now that we have the documents to process, we have the worker process
		// the items
		try {
			CopyDocsPluginLogger.logInfo("Process the  Array ot items", "ArrayWorker", "execute", userId);
			processArray(units, userId);
		} catch (Exception ex) {
			CopyDocsPluginLogger.logException(ex, "ArrayWorker", "execute", userId);
			return buildExceptionPayload(ex, units);
		}

		// Build our counts array
		JSONObject counts = new JSONObject();
		counts.put("total", units.length);
		CopyDocsPluginLogger.logInfo("Total Count::" + units.length, "ArrayWorker", "execute", userId);
		int success = 0;

		for (int i = 0; i < units.length; i++)
			success += (units[i].isSuccessful() ? 1 : 0);

		counts.put("success", success);

		// Start building the response JSON payload
		JSONObject response = new JSONObject();
		response.put("documents", serializeUnits(units));
		response.put("exception", null);
		response.put("counts", counts);

		return response;
	}

	/**
	 * Builds an array of items to process based on a passed in set of ICN ids
	 * 
	 * @param request
	 *            Incoming request payload
	 * @return A set of retrieved work units
	 * @throws IllegalAccessException
	 * @throws InstantiationException
	 * @throws Exception
	 */
	protected ArrayUnit[] buildArray(JSONObject request, String userId) throws Exception {

		// Get the IDs array from the payload
		JSONArray guids = (JSONArray) request.get("guids");
		CopyDocsPluginLogger.logDebug("guids ::" + guids, "ArrayWorker", "buildArray", userId);
		ArrayUnit[] units = new ArrayUnit[guids.size()];

		// Prepare the items for retrieval
		for (int i = 0; i < guids.size(); i++) {
			try {
				units[i] = (ArrayUnit) workerClass.newInstance();
				units[i].assignId((String) guids.get(i));
				units[i].setValid(true);
			} catch (Exception e) {
				CopyDocsPluginLogger.logException(e, "ArrayWorker", "buildArray", userId);
				throw e;
			}
		}

		// Retrieve the documents from Content Engine
		retrieveDocuments(objectStore, units, null, userId);

		return units;
	}

	/**
	 * Processes the provided array of items
	 * 
	 * @param units
	 *            Array of work items to process
	 * @throws Exception
	 *             Thrown for any fatal errors that mean processing cannot
	 *             continue
	 */
	public abstract void processArray(ArrayUnit[] units, String UserId) throws Exception;

	protected void copyProperties(Document source, Document target, Map<String, String> targetProperties, String userId)
			throws Exception {
		CopyDocsPluginLogger.logInfo("Copy the Properties from source to target document", "ArrayWorker",
				"copyProperties", userId);
		CopyDocsPluginLogger.logDebug("Source Document::" + source.get_Id(), "ArrayWorker", "copyProperties", userId);
		CopyDocsPluginLogger.logDebug("Target Document::" + source.get_Id(), "ArrayWorker", "copyProperties", userId);
		CopyDocsPluginLogger.logDebug("TargetProperties::" + targetProperties, "ArrayWorker", "copyProperties", userId);
		Properties targetProps = source.getProperties();
		PropertyDescriptionList pdl = source.get_ClassDescription().get_PropertyDescriptions();
		for (Iterator<?> i = targetProps.iterator(); i.hasNext();) {
			Property oneProp = (Property) i.next();
			PropertyDescription onePropDesc = null;
			String propName = oneProp.getPropertyName();

			for (int j = 0; j < pdl.size(); j++) {
				if (((PropertyDescription) pdl.get(j)).get_SymbolicName().equalsIgnoreCase(oneProp.getPropertyName())) {
					onePropDesc = (PropertyDescription) pdl.get(j);
					break;
				}
			}

			if (!onePropDesc.get_IsSystemOwned() && !onePropDesc.get_IsReadOnly()) {
				CopyDocsPluginLogger.logDebug("Source Property::" + onePropDesc.get_SymbolicName(), "ArrayWorker",
						"copyProperties", userId);
				switch (onePropDesc.get_DataType().getValue()) {
				case TypeID.BOOLEAN_AS_INT:

					if (targetProperties.containsKey(propName))
						target.getProperties().putValue(propName, new Boolean(targetProperties.get(propName)));
					else if (onePropDesc.get_Cardinality() == Cardinality.LIST)
						target.getProperties().putValue(propName, oneProp.getBooleanListValue());
					else
						target.getProperties().putValue(propName, oneProp.getBooleanValue());

					break;
				case TypeID.GUID_AS_INT:

					if (targetProperties.containsKey(propName))
						target.getProperties().putValue(propName, new Id(oneProp.getObjectValue().toString()));
					else
						target.getProperties().putValue(propName, new Id(oneProp.getObjectValue().toString()));
					break;
				case TypeID.STRING_AS_INT:

					if (targetProperties.containsKey(propName))
						target.getProperties().putValue(propName, targetProperties.get(propName));
					else if (onePropDesc.get_Cardinality() == Cardinality.LIST)
						target.getProperties().putValue(propName, oneProp.getStringListValue());
					else
						target.getProperties().putValue(propName, oneProp.getStringValue());

					break;
				case TypeID.DATE_AS_INT:

					if (targetProperties.containsKey(propName)) {

						Date v = null;
						String value = (String) targetProperties.get(propName);

						if (value != null)
							v = javax.xml.bind.DatatypeConverter.parseDateTime(value).getTime();

						target.getProperties().putValue(propName, v);

					} else if (onePropDesc.get_Cardinality() == Cardinality.LIST)
						target.getProperties().putValue(propName, oneProp.getDateTimeListValue());
					else
						target.getProperties().putValue(propName, oneProp.getDateTimeValue());
					break;
				case TypeID.DOUBLE_AS_INT:

					if (onePropDesc.get_Cardinality() == Cardinality.LIST)
						target.getProperties().putValue(propName, oneProp.getFloat64ListValue());
					else
						target.getProperties().putValue(propName, oneProp.getFloat64Value());
					break;

				case TypeID.LONG_AS_INT:
					if (onePropDesc.get_Cardinality() == Cardinality.LIST)
						target.getProperties().putValue(propName, oneProp.getInteger32ListValue());
					else
						target.getProperties().putValue(propName, oneProp.getInteger32Value());

					break;
				}
			}
		}
	}

}