package com.agcs.icn.plugin.service;

import java.io.IOException;
import java.io.InputStream;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.agcs.icn.plugin.service.utilities.Configuration;
import com.filenet.api.constants.PropertyNames;
import com.filenet.api.core.Document;
import com.filenet.api.core.Domain;
import com.filenet.api.core.Factory;
import com.filenet.api.core.ObjectStore;
import com.filenet.api.property.FilterElement;
import com.filenet.api.property.PropertyFilter;
import com.ibm.ecm.extension.PluginResponseUtil;
import com.ibm.ecm.extension.PluginService;
import com.ibm.ecm.extension.PluginServiceCallbacks;
import com.ibm.ecm.json.JSONResponse;

/**
 * Provides an abstract class that is extended to create a class implementing
 * each service provided by the plug-in. Services are actions, similar to
 * servlets or Struts actions, that perform operations on the IBM Content
 * Navigator server. A service can access content server application programming
 * interfaces (APIs) and Java EE APIs.
 * <p>
 * Services are invoked from the JavaScript functions that are defined for the
 * plug-in by using the <code>ecm.model.Request.invokePluginService</code>
 * function.
 * </p>
 * Follow best practices for servlets when implementing an IBM Content Navigator
 * plug-in service. In particular, always assume multi-threaded use and do not
 * keep unshared information in instance variables.
 */
public class ReadConfigFileService extends PluginService {

	String userID;

	/**
	 * Returns the unique identifier for this service.
	 * <p>
	 * <strong>Important:</strong> This identifier is used in URLs so it must
	 * contain only alphanumeric characters.
	 * </p>
	 * 
	 * @return A <code>String</code> that is used to identify the service.
	 */
	public String getId() {
		return "ReadConfigFileService";
	}

	/**
	 * Returns the name of the IBM Content Navigator service that this service
	 * overrides. If this service does not override an IBM Content Navigator
	 * service, this method returns <code>null</code>.
	 * 
	 * @returns The name of the service.
	 */
	public String getOverriddenService() {
		return null;
	}

	/**
	 * Performs the action of this service.
	 * 
	 * @param callbacks
	 *            An instance of the <code>PluginServiceCallbacks</code> class
	 *            that contains several functions that can be used by the
	 *            service. These functions provide access to the plug-in
	 *            configuration and content server APIs.
	 * @param request
	 *            The <code>HttpServletRequest</code> object that provides the
	 *            request. The service can access the invocation parameters from
	 *            the request.
	 * @param response
	 *            The <code>HttpServletResponse</code> object that is generated
	 *            by the service. The service can get the output stream and
	 *            write the response. The response must be in JSON format.
	 * @throws Exception
	 *             For exceptions that occur when the service is running. If the
	 *             logging level is high enough to log errors, information about
	 *             the exception is logged by IBM Content Navigator.
	 */
	public void execute(PluginServiceCallbacks callbacks, HttpServletRequest request, HttpServletResponse response)
			throws Exception {

		String repositoryID = request.getParameter("repositoryID");
		String osName = request.getParameter("osName");
		userID = request.getParameter("userID");
	
		String propertiesFilePath = "/Config/DDMOperations.properties";

		Domain domain = callbacks.getP8Domain(repositoryID, null);
		ObjectStore os = Factory.ObjectStore.fetchInstance(domain, osName, null);

		java.util.Properties prop = readConfigurationsFromCE(os, propertiesFilePath);
		JSONResponse responseJSON = new JSONResponse();
		java.util.Properties propFromCE = new java.util.Properties(prop);
		String logFilePath = propFromCE.getProperty("CopyDocsPluginLogFilePath");
		String logLevel = propFromCE.getProperty("LogLevel");
		Configuration.prop_policyNumber = propFromCE.getProperty("DDM_Policy_Number");
		Configuration.prop_submissionNumber = propFromCE.getProperty("DDM_Submission_Number");
		Configuration.prop_insuredName = propFromCE.getProperty("DDM_Insured_Name");
		Configuration.prop_policyInceptionDate = propFromCE.getProperty("DDM_Policy_Inception_Date");
		Configuration.prop_businessTransactionType = propFromCE.getProperty("DDM_Business_Transaction_Type");
		Configuration.prop_claimNumber = propFromCE.getProperty("DDM_Claim_Number");
		Configuration.prop_claimantName = propFromCE.getProperty("DDM_Claimant_Name");
		Configuration.prop_claimSuffixNumber = propFromCE.getProperty("DDM_Claim_Suffix_Number");
		Configuration.prop_documentCategory = propFromCE.getProperty("DDM_Document_Category");
		Configuration.prop_documentSubCategory = propFromCE.getProperty("DDM_Document_Sub_Category");
		Configuration.prop_claim_documentCategory = propFromCE.getProperty("DDM_Claim_Document_Category");
		Configuration.prop_claim_documentSubCategory = propFromCE.getProperty("DDM_Claim_Document_Sub_Category");
		Configuration.prop_documentTitle = propFromCE.getProperty("DDM_Document_Title");
		Configuration.prop_linkedPolicies = propFromCE.getProperty("DDM_Linked_Policies");
		Configuration.prop_linkedSubmissions = propFromCE.getProperty("DDM_Linked_Submissions");
		Configuration.prop_linkedClaims = propFromCE.getProperty("DDM_Linked_Claims");
		Configuration.prop_documentSubCategory = propFromCE.getProperty("DDM_Document_Sub_Category");
		Configuration.class_claimDocument = propFromCE.getProperty("DDM_Claim_Document_Class");
		Configuration.class_underwriting = propFromCE.getProperty("DDM_Underwriting_Class");
		Configuration.folderPath_Claims = propFromCE.getProperty("DDM_FolderPath_Claims");
		Configuration.folderPath_Underwriting = propFromCE.getProperty("DDM_FolderPath_Underwriting");

		responseJSON.put("PolicyNumber", Configuration.prop_policyNumber);
		responseJSON.put("SubmissionNumber", Configuration.prop_submissionNumber);
		responseJSON.put("InsuredName", Configuration.prop_insuredName);
		responseJSON.put("PolicyInceptionDate", Configuration.prop_policyInceptionDate);
		responseJSON.put("BusinessTransactionType", Configuration.prop_businessTransactionType);
		responseJSON.put("ClaimNumber", Configuration.prop_claimNumber);
		responseJSON.put("ClaimantName", Configuration.prop_claimantName);
		responseJSON.put("ClaimSuffixNumber", Configuration.prop_claimSuffixNumber);
		responseJSON.put("DocumentCategory", Configuration.prop_documentCategory);
		responseJSON.put("DocumentSubCategory", Configuration.prop_documentSubCategory);
		responseJSON.put("ClaimDocumentCategory", Configuration.prop_claim_documentCategory);
		responseJSON.put("ClaimDocumentSubCategory", Configuration.prop_documentSubCategory);

		responseJSON.put("ClaimDocument", Configuration.class_claimDocument);
		responseJSON.put("Underwriting", Configuration.class_underwriting);
		responseJSON.put("isInvokeService", "true");

		if (logFilePath != null && !logFilePath.equals("")) {

			CopyDocsPluginLogger.changeLoggerIfAlreadyNotChanged(callbacks, "config", logLevel, logFilePath);
		}

		CopyDocsPluginLogger.logInfo("Config file was read successfully", "ReadConfigFileService", "execute", userID);
		CopyDocsPluginLogger.logDebug("responseJSON ::" + responseJSON, "ReadConfigFileService", "execute", userID);
		PluginResponseUtil.writeJSONResponse(request, response, responseJSON, callbacks, "ReadConfigFileService");
	}

	public java.util.Properties readConfigurationsFromCE(ObjectStore objectStore, String propFilePath) {

		java.util.Properties propCE = new java.util.Properties();
		InputStream proprStream = null;

		try {

			PropertyFilter pf = new PropertyFilter();
			pf.addIncludeProperty(new FilterElement(null, null, null, PropertyNames.CONTENT_ELEMENTS, null));
			Document propDoc = Factory.Document.fetchInstance(objectStore, propFilePath, null);
			proprStream = propDoc.accessContentStream(0);
			propCE.load(proprStream);

		} catch (IOException ioe) {
			CopyDocsPluginLogger.logException(ioe, "ReadConfigFileService", "readConfigurationsFromCE", userID);
		} catch (Exception ex) {
			CopyDocsPluginLogger.logException(ex, "ReadConfigFileService", "readConfigurationsFromCE", userID);
		}

		return propCE;
	}
}
