package com.agcs.icn.plugin.service.workers;

import com.agcs.icn.plugin.service.CopyDocsPluginLogger;
import com.filenet.api.core.BatchItemHandle;

import com.filenet.api.core.Document;
import com.filenet.api.core.Domain;
import com.filenet.api.core.Factory;
import com.filenet.api.core.ObjectStore;
import com.filenet.api.core.RetrievingBatch;
import com.filenet.api.property.PropertyFilter;

import com.filenet.api.util.Id;

import com.ibm.json.java.JSONArray;
import com.ibm.json.java.JSONObject;

public abstract class BaseWorker {
	private Domain domain;

	public abstract JSONObject execute(String userid, JSONObject request) throws Exception;

	protected void retrieveDocuments(String objectStore, BaseUnit[] units, PropertyFilter filter, String userId) {
		CopyDocsPluginLogger.logInfo("Retrieve the documents", "BaseWorker", "retrieveDocuments", userId);
		RetrievingBatch batch = RetrievingBatch.createRetrievingBatchInstance(domain);

		BatchItemHandle[] handles = new BatchItemHandle[units.length];

		for (int i = 0; i < handles.length; i++) {
			if (!units[i].isValid())
				continue;

			Document document = Factory.Document.getInstance(getObjectStore(units[i].getObjectStoreId()),
					units[i].getClassName(), units[i].getObjectId());
			handles[i] = batch.add(document, filter);
			units[i].setDocument(document);
			CopyDocsPluginLogger.logDebug("Document ID ::" + units[i].getObjectId(), "BaseWorker", "retrieveDocuments",
					userId);
		}

		batch.retrieveBatch();

		for (int i = 0; i < handles.length; i++) {
			if (handles[i] == null)
				continue;

			BatchItemHandle h = handles[i];
			if (!h.hasException())
				units[i].setRetrieved(true);
			else
				units[i].setException(h.getException());
		}
	}

	protected ObjectStore getObjectStore(Id objectStore) {
		return Factory.ObjectStore.getInstance(domain, objectStore);
	}

	protected ObjectStore getObjectStore(String objectStore) {
		return Factory.ObjectStore.getInstance(domain, objectStore);
	}

	public final Domain getDomain() {
		return domain;
	}

	protected JSONArray serializeUnits(BaseUnit[] units) {
		JSONArray array = new JSONArray();

		if (units != null)
			for (BaseUnit unit : units)
				array.add(unit.serialize());

		return array;
	}

	protected JSONObject buildExceptionPayload(Exception e, BaseUnit[] units) {
		JSONObject response = new JSONObject();
		response.put("documents", serializeUnits(units));

		JSONObject exception = new JSONObject();
		exception.put("message", e.getLocalizedMessage());

		JSONArray stack = new JSONArray();
		for (StackTraceElement ste : e.getStackTrace())
			stack.add(ste.toString());

		exception.put("stack", stack);

		response.put("exception", exception);

		return response;
	}

	protected JSONObject buildExceptionPayload(String message) {
		JSONObject response = new JSONObject();

		JSONObject exception = new JSONObject();
		exception.put("message", message);

		response.put("exception", exception);

		return response;
	}

	public final void setDomain(Domain domain) {
		this.domain = domain;
	}
}