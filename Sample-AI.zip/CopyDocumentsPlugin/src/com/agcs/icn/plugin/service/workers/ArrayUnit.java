package com.agcs.icn.plugin.service.workers;

public abstract class ArrayUnit extends BaseUnit {
	protected boolean prepared = false;

	public ArrayUnit() {
		super();
	}

	public final boolean isPrepared() {
		return prepared;
	}

	public final void setPrepared(boolean prepared) {
		this.prepared = prepared;
	}

}