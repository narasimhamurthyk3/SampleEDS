package com.agcs.icn.plugin.service.workers;

import java.util.HashMap;

import java.util.Map;

import com.agcs.icn.plugin.service.CopyDocsPluginLogger;
import com.agcs.icn.plugin.service.utilities.Configuration;
import com.filenet.api.collection.ContentElementList;
import com.filenet.api.constants.AutoClassify;
import com.filenet.api.constants.AutoUniqueName;
import com.filenet.api.constants.CheckinType;
import com.filenet.api.constants.DefineSecurityParentage;
import com.filenet.api.constants.RefreshMode;
import com.filenet.api.core.ContentTransfer;
import com.filenet.api.core.Document;
import com.filenet.api.core.DynamicReferentialContainmentRelationship;
import com.filenet.api.core.Factory;
import com.filenet.api.core.Folder;
import com.filenet.api.property.Properties;

/**
 * This worker will loop through a provided set of documents, validate access,
 * create copies and apply and provided property updates.
 * 
 */
public class CopyWorker extends ArrayWorker {

	public CopyWorker() {
		super(CopyUnit.class);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.ibm.icn.custom.ffic.plugin.svc.workers.ArrayWorker#processArray(com.
	 * ibm.icn.custom.ffic.plugin.svc.utilities.FFICUser,
	 * com.ibm.icn.custom.ffic.plugin.svc.workers.ArrayUnit[])
	 */
	public void processArray(ArrayUnit[] units, String userId) throws Exception {

		// Loop through the documents and prepare for and add to batch or
		// execute
		for (int i = 0; i < units.length; i++) {

			// Skip items that failed retrieval
			if (units[i].getDocument().get_IsReserved()) {
				// If the document is validated, add an exception indicating
				// they cannot update and skip
				CopyDocsPluginLogger.logDebug("Document is checked out by" + units[i].getDocument().get_LastModifier(),
						"CopyWorker", "processArray", userId);
				units[i].setException(
						new Exception("Document is checked out by " + units[i].getDocument().get_LastModifier()));
				continue;
			}
			if (!units[i].isRetrieved())
				continue;

			Document sourceDocument = units[i].getDocument();

			Document targetDocument = null;
			CopyDocsPluginLogger.logInfo("Source Document : " + units[i].getDocument().get_Name(), "CopyWorker",
					"processArray", userId);
			// Perform the validation steps and create the copy
			try {
				validate(sourceDocument, targetProperties, userId);
				targetDocument = createDocumentCopy(sourceDocument, targetProperties, userId);
				units[i].setPrepared(true);
				updateSource(sourceDocument, targetProperties, userId);
			} catch (Exception e) {
				CopyDocsPluginLogger.logInfo("Exception while process document" + e.getMessage(), "CopyWorker",
						"processArray", userId);
				units[i].setException(e);
				continue;
			}

			try {
				// Copy the document
				targetDocument.save(RefreshMode.NO_REFRESH);
				CopyDocsPluginLogger.logInfo("Save the target document", "CopyWorker", "processArray", userId);
				Folder folder = Factory.Folder.fetchInstance(targetDocument.getObjectStore(),
						Configuration.folderPath_Underwriting, null);
				CopyDocsPluginLogger.logInfo(
						"File the target document to folder " + Configuration.folderPath_Underwriting, "CopyWorker",
						"processArray", userId);
				DynamicReferentialContainmentRelationship drcr = (DynamicReferentialContainmentRelationship) folder
						.file(targetDocument, AutoUniqueName.AUTO_UNIQUE, null,
								DefineSecurityParentage.DO_NOT_DEFINE_SECURITY_PARENTAGE);
				drcr.setUpdateSequenceNumber(null);
				drcr.save(RefreshMode.NO_REFRESH);
				CopyDocsPluginLogger.logInfo("Target document filed successfully", "CopyWorker", "processArray",
						userId);
				((CopyUnit) units[i]).setCopied(true);
				// Update the source document
				sourceDocument.save(RefreshMode.NO_REFRESH);
				((CopyUnit) units[i]).setUpdated(true);
			} catch (Exception e) {
				CopyDocsPluginLogger.logInfo("Exception while processing the document" + e.getMessage(), "CopyWorker",
						"processArray", userId);
				units[i].setException(e);
				continue;
			}
		}
	}

	/**
	 * This method performs the following validation checks on the documents:
	 * <ul>
	 * <li>Checks whether the document is restricted and if so if user has
	 * access to the document</li>
	 * <li>Checks whether the document has been copied before to the target
	 * account number</li>
	 * </ul>
	 * 
	 * @param user
	 *            FFIC User object for validating access
	 * @param sourceDocument
	 *            Original document
	 * @param targetProperties
	 *            Target properties for the document
	 * @throws Exception
	 *             Thrown if user does not have access or if there are any other
	 *             validation errors
	 */
	private void validate(Document sourceDocument, HashMap<String, String> targetProperties, String userId)
			throws Exception {
		// Perform the restricted access document check and if the user cannot
		// access, throw an exception

		/**
		 * From this point forward, the code is checking to see if the document
		 * is already been copied for a given policy. If so, we need to mark the
		 * document as invalid for copying
		 */
		CopyDocsPluginLogger.logInfo("Check the linked Policies or Submission for the Document", "CopyWorker",
				"validate", userId);
		Properties props = sourceDocument.getProperties();

		if (!props.isPropertyPresent(Configuration.prop_businessTransactionType))
			throw new Exception("Document does not have a BusinessTransactionType property, so invalid document");

		String type = props.getStringValue(Configuration.prop_businessTransactionType);
		CopyDocsPluginLogger.logDebug("BusinessTransactionType=" + type, "CopyWorker", "validate", userId);
		if (type == null || type.length() == 0)
			throw new Exception(
					"Unable to determine if the document is a policy or submission because type was null or empty.");

		if (type.equalsIgnoreCase("Policy"))
			type = "1";
		else
			type = "2";

		// Depending on the type, 1/2 it's a policy or submission document
		switch (type.charAt(0)) {
		case '1': {
			String policy = targetProperties.get(Configuration.prop_policyNumber);
			CopyDocsPluginLogger.logDebug("PolicyNumber=" + policy, "CopyWorker", "validate", userId);
			String raw = props.getStringValue(Configuration.prop_linkedPolicies);
			CopyDocsPluginLogger.logDebug("linkedPolicies=" + raw, "CopyWorker", "validate", userId);
			if (raw != null && raw.length() > 0) {
				String[] values = raw.split(",");
				for (String value : values)
					if (policy.equals(value.trim())) {
						CopyDocsPluginLogger.logInfo("Document already linked to new policy", "CopyWorker", "validate",
								userId);
						throw new Exception("Document already linked to new policy");
					}

			}
			break;
		}

		case '2': {
			String submission = targetProperties.get(Configuration.prop_submissionNumber);
			CopyDocsPluginLogger.logDebug("submissionNumber=" + submission, "CopyWorker", "validate", userId);
			String raw = props.getStringValue(Configuration.prop_linkedSubmissions);
			CopyDocsPluginLogger.logDebug("linkedSubmissions=" + raw, "CopyWorker", "validate", userId);
			if (raw != null && raw.length() > 0) {
				String[] values = raw.split(",");
				for (String value : values)
					if (submission.equals(value.trim())) {
						CopyDocsPluginLogger.logInfo("Document already linked to new submission", "CopyWorker",
								"validate", userId);
						throw new Exception("Document already linked to new submission");
					}

			}
			break;
		}

		default:
			throw new Exception("Invalid business transaction type, should be a 1 or 2");
		}
	}

	/**
	 * Prepares the source document to accept the new policy or submission
	 * number.
	 * 
	 * @param sourceDocument
	 *            Original document
	 * @param targetProperties
	 *            Target properties for the new document
	 * @throws Exception
	 *             Thrown for any errors, primarliy if the business txn type is
	 *             unknown.
	 */
	private void updateSource(Document sourceDocument, HashMap<String, String> targetProperties, String userId)
			throws Exception {
		CopyDocsPluginLogger.logInfo("Update the Linked Policy or Submission field with the new value ", "CopyWorker",
				"updateSource", userId);
		Properties props = sourceDocument.getProperties();

		String type = props.getStringValue(Configuration.prop_businessTransactionType);
		if (type.equalsIgnoreCase("Policy"))
			type = "1";
		else
			type = "2";
		switch (type.charAt(0)) {
		case '1': {
			String policy = targetProperties.get(Configuration.prop_policyNumber);
			CopyDocsPluginLogger.logDebug("policyNumber" + policy, "CopyWorker", "updateSource", userId);
			String raw = props.getStringValue(Configuration.prop_linkedPolicies);
			CopyDocsPluginLogger.logDebug("linkedPolicies" + raw, "CopyWorker", "updateSource", userId);
			if (raw == null)
				raw = "";
			props.putValue(Configuration.prop_linkedPolicies, policy + (raw.length() == 0 ? "" : ", ") + raw);
			CopyDocsPluginLogger.logInfo("New Policy is set", "CopyWorker", "updateSource", userId);
			break;
		}

		case '2': {
			String submission = targetProperties.get(Configuration.prop_submissionNumber);
			CopyDocsPluginLogger.logDebug("submissionNumber" + submission, "CopyWorker", "updateSource", userId);
			String raw = props.getStringValue(Configuration.prop_linkedSubmissions);
			CopyDocsPluginLogger.logDebug("linkedSubmissions" + raw, "CopyWorker", "updateSource", userId);
			if (raw == null)
				// It could be null the first time
				raw = "";

			props.putValue(Configuration.prop_linkedSubmissions, submission + (raw.length() == 0 ? "" : ", ") + raw);
			CopyDocsPluginLogger.logInfo("New Submission is set", "CopyWorker", "updateSource", userId);
			break;
		}

		default:
			throw new Exception("Invalid business transaction type, should be a 1 or 2");
		}
	}

	private Document createDocumentCopy(Document source, Map<String, String> targetProperties, String userId)
			throws Exception {
		CopyDocsPluginLogger.logInfo("Create target document copy from source", "CopyWorker", "createDocumentCopy",
				userId);
		// Get the class type
		String name = source.get_ClassDescription().get_SymbolicName();

		// Create the new document
		Document target = Factory.Document.createInstance(source.getObjectStore(), name);

		// Copy existing custom property values
		copyProperties(source, target, targetProperties, userId);

		// Copy the content
		copyContent(source, target, userId);

		target.save(RefreshMode.REFRESH);
		target.checkin(AutoClassify.DO_NOT_AUTO_CLASSIFY, CheckinType.MAJOR_VERSION);

		CopyDocsPluginLogger.logInfo("Document created successfully", "CopyWorker", "createDocumentCopy", userId);
		return target;
	}

	@SuppressWarnings("unchecked")
	private void copyContent(Document source, Document target, String userId) {
		CopyDocsPluginLogger.logInfo("Copy Content from source to target", "CopyWorker", "copyContent", userId);

		ContentElementList sl = source.get_ContentElements();
		ContentElementList tl = Factory.ContentElement.createList();

		for (int i = 0; i < sl.size(); i++) {
			ContentTransfer se = (ContentTransfer) sl.get(i);
			ContentTransfer te = Factory.ContentTransfer.createInstance();

			te.set_ContentType(se.get_ContentType());
			te.set_RetrievalName(se.get_RetrievalName());

			te.setCaptureSource(se.accessContentStream());

			tl.add(te);
		}

		target.set_ContentElements(tl);

	}

}
