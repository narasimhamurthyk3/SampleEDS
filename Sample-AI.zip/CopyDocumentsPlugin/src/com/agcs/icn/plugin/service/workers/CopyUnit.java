package com.agcs.icn.plugin.service.workers;

public class CopyUnit extends ArrayUnit {
	private boolean updated = false, copied = false;


	public final boolean isUpdated() {
		return updated;
	}

	public final void setUpdated(boolean updated) {
		this.updated = updated;
	}

	public final boolean isCopied() {
		return copied;
	}

	public final void setCopied(boolean copied) {
		this.copied = copied;
	}

	@Override
	protected String getStatus() {
		if (updated)
			return "Complete";

		if (isPrepared())
			return "Failed copying";

		if (copied)
			return "Failed updating source document";

		return super.getStatus();
	}

	@Override
	public boolean isSuccessful() {
		return updated;
	}
}
