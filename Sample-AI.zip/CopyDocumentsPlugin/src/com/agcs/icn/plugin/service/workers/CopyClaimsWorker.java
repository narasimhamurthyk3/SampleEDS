package com.agcs.icn.plugin.service.workers;

import java.util.HashMap;

import java.util.Map;

import com.agcs.icn.plugin.service.CopyDocsPluginLogger;
import com.agcs.icn.plugin.service.utilities.Configuration;
import com.filenet.api.collection.ContentElementList;

import com.filenet.api.constants.AutoClassify;
import com.filenet.api.constants.AutoUniqueName;

import com.filenet.api.constants.CheckinType;
import com.filenet.api.constants.DefineSecurityParentage;
import com.filenet.api.constants.RefreshMode;

import com.filenet.api.core.ContentTransfer;
import com.filenet.api.core.Document;
import com.filenet.api.core.DynamicReferentialContainmentRelationship;
import com.filenet.api.core.Factory;
import com.filenet.api.core.Folder;
import com.filenet.api.property.Properties;

public class CopyClaimsWorker extends ArrayWorker {

	public CopyClaimsWorker() {
		super(CopyUnit.class);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.ibm.icn.custom.ffic.plugin.svc.workers.ArrayWorker#processArray(com.
	 * ibm.icn.custom.ffic.plugin.svc.utilities.FFICUser,
	 * com.ibm.icn.custom.ffic.plugin.svc.workers.ArrayUnit[])
	 */
	public void processArray(ArrayUnit[] units, String userId) throws Exception {

		// Loop through the documents and prepare for and add to batch or
		// execute
		for (int i = 0; i < units.length; i++) {
			// Skip items that failed retrieval
			if (units[i].getDocument().get_IsReserved()) {
				// If the document is validated, add an exception indicating
				// they cannot update and skip
				CopyDocsPluginLogger.logDebug("Document is checked out by" + units[i].getDocument().get_LastModifier(),
						"CopyClaimsWorker", "processArray", userId);
				units[i].setException(
						new Exception("Document is checked out by " + units[i].getDocument().get_LastModifier()));
				continue;
			}
			if (!units[i].isRetrieved())
				continue;

			Document sourceDocument = units[i].getDocument();

			Document targetDocument = null;
			CopyDocsPluginLogger.logInfo("Source Document : " + units[i].getDocument().get_Name(), "CopyClaimsWorker",
					"processArray", userId);
			// Perform the validation steps and create the copy
			try {
				validate(sourceDocument, targetProperties, userId);
				targetDocument = createDocumentCopy(sourceDocument, targetProperties, userId);
				units[i].setPrepared(true);
				updateSource(sourceDocument, targetProperties, userId);
			} catch (Exception e) {
				CopyDocsPluginLogger.logInfo("Exception while processing the document" + e.getMessage(),
						"CopyClaimsWorker", "processArray", userId);
				units[i].setException(e);
				continue;
			}

			try {
				// Copy the document
				targetDocument.save(RefreshMode.NO_REFRESH);
				CopyDocsPluginLogger.logInfo("Save the target document", "CopyClaimsWorker", "processArray", userId);
				Folder folder = Factory.Folder.fetchInstance(targetDocument.getObjectStore(),
						Configuration.folderPath_Claims, null);
				CopyDocsPluginLogger.logInfo("File the target document to folder " + Configuration.folderPath_Claims,
						"CopyClaimsWorker", "processArray", userId);
				DynamicReferentialContainmentRelationship drcr = (DynamicReferentialContainmentRelationship) folder
						.file(targetDocument, AutoUniqueName.AUTO_UNIQUE, null,
								DefineSecurityParentage.DO_NOT_DEFINE_SECURITY_PARENTAGE);
				drcr.setUpdateSequenceNumber(null);
				drcr.save(RefreshMode.NO_REFRESH);
				CopyDocsPluginLogger.logInfo("Target document filed successfully", "CopyClaimsWorker", "processArray",
						userId);
				((CopyUnit) units[i]).setCopied(true);
				// Update the source document
				sourceDocument.save(RefreshMode.NO_REFRESH);
				((CopyUnit) units[i]).setUpdated(true);
			} catch (Exception e) {
				CopyDocsPluginLogger.logInfo("Exception while processing the document" + e.getMessage(),
						"CopyClaimsWorker", "processArray", userId);
				units[i].setException(e);
				continue;
			}

		}

	}

	/**
	 * This method performs the following validation checks on the documents:
	 * <ul>
	 * <li>Checks whether the document is restricted and if so if user has
	 * access to the document</li>
	 * <li>Checks whether the document has been copied before to the target
	 * account number</li>
	 * </ul>
	 * 
	 * @param user
	 *            FFIC User object for validating access
	 * @param sourceDocument
	 *            Original document
	 * @param targetProperties
	 *            Target properties for the document
	 * @throws Exception
	 *             Thrown if user does not have access or if there are any other
	 *             validation errors
	 */
	private void validate(Document sourceDocument, HashMap<String, String> targetProperties, String userId)
			throws Exception {
		CopyDocsPluginLogger.logInfo("Check the linked claims for the Document", "CopyClaimsWorker", "validate",
				userId);
		Properties props = sourceDocument.getProperties();

		String claimNumber = targetProperties.get(Configuration.prop_claimNumber);
		CopyDocsPluginLogger.logDebug("claimNumber=" + claimNumber, "CopyClaimsWorker", "validate", userId);
		String raw = props.getStringValue(Configuration.prop_linkedClaims);
		CopyDocsPluginLogger.logDebug("linkedClaims=" + raw, "CopyClaimsWorker", "validate", userId);
		if (raw != null && raw.length() > 0) {
			String[] values = raw.split(",");
			for (String value : values)
				if (claimNumber.equals(value.trim())) {
					CopyDocsPluginLogger.logInfo("Document already linked to new claim", "CopyClaimsWorker", "validate",
							userId);
					throw new Exception("Document already linked to new claim");
				}

		}
	}

	/**
	 * Prepares the source document to accept the new policy or submission
	 * number.
	 * 
	 * @param sourceDocument
	 *            Original document
	 * @param targetProperties
	 *            Target properties for the new document
	 * @throws Exception
	 *             Thrown for any errors, primarliy if the business txn type is
	 *             unknown.
	 */
	private void updateSource(Document sourceDocument, HashMap<String, String> targetProperties, String userId)
			throws Exception {
		CopyDocsPluginLogger.logInfo("Update the Linked claim field with the new value ", "CopyClaimsWorker",
				"updateSource", userId);
		Properties props = sourceDocument.getProperties();

		String claimNumber = targetProperties.get(Configuration.prop_claimNumber);
		CopyDocsPluginLogger.logDebug("claimNumber=" + claimNumber, "CopyClaimsWorker", "updateSource", userId);
		String raw = props.getStringValue(Configuration.prop_linkedClaims);
		CopyDocsPluginLogger.logDebug("linkedClaims=" + raw, "CopyClaimsWorker", "updateSource", userId);
		if (raw == null)
			raw = "";
		props.putValue(Configuration.prop_linkedClaims, claimNumber + (raw.length() == 0 ? "" : ", ") + raw);
		CopyDocsPluginLogger.logInfo("New Claim is set", "CopyClaimsWorker", "updateSource", userId);
	}

	private Document createDocumentCopy(Document source, Map<String, String> targetProperties, String userId)
			throws Exception {
		CopyDocsPluginLogger.logInfo("Create target document copy from source", "CopyClaimsWorker",
				"createDocumentCopy", userId);
		// Get the class type
		String name = source.get_ClassDescription().get_SymbolicName();

		// Create the new document
		Document target = Factory.Document.createInstance(source.getObjectStore(), name);

		// Copy existing custom property values
		copyProperties(source, target, targetProperties, userId);

		// Added this to ensure the Update event is triggered
		target.save(RefreshMode.REFRESH);

		// Copy the content
		copyContent(source, target, userId);

		target.checkin(AutoClassify.DO_NOT_AUTO_CLASSIFY, CheckinType.MAJOR_VERSION);

		CopyDocsPluginLogger.logInfo("Document created successfully", "CopyWorker", "createDocumentCopy", userId);
		return target;
	}

	@SuppressWarnings("unchecked")
	private void copyContent(Document source, Document target, String userId) {
		CopyDocsPluginLogger.logInfo("Copy Content from source to target", "CopyClaimsWorker", "copyContent", userId);

		ContentElementList sl = source.get_ContentElements();
		ContentElementList tl = Factory.ContentElement.createList();

		for (int i = 0; i < sl.size(); i++) {
			ContentTransfer se = (ContentTransfer) sl.get(i);
			ContentTransfer te = Factory.ContentTransfer.createInstance();

			te.set_ContentType(se.get_ContentType());
			te.set_RetrievalName(se.get_RetrievalName());

			te.setCaptureSource(se.accessContentStream());

			tl.add(te);
		}

		target.set_ContentElements(tl);

	}

}
