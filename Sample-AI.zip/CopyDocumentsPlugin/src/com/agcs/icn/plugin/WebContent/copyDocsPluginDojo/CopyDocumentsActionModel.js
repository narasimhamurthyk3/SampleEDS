define(["dojo/_base/declare",
        "ecm/model/Request",
        "ecm/model/Action",
        "ecm/model/Desktop",
        "dojo/_base/lang",
        "ecm/widget/dialog/MessageDialog",
       "copyDocsPluginDojo/CopyDocumentsDialog"
        ],
        function(declare,Request,Action,Desktop,lang,MessageDialog,CopyDocumentsDialog) {
	return declare("copyDocsPluginDojo/CopyDocumentsActionModel", [ Action ], {
		isEnabled: function(repository, listType, items, workspace,resultSet) {
			var enabled = false;
			if((items[0].getContentClass().id=="Claim_Document" && items[0].getPath()[0].folders[0].name=="/Claim Documents") || 
					(items[0].getContentClass().id=="Underwriting_Document" && items[0].getPath()[0].folders[0].name=="/Underwriting Documents"))
			{
			for (var i in items) {
				
				var docClassName = items[i].getContentClass().id;
				if(items[i].hasPrivilege( "privEditProperties")|| items[0].hasPrivilege("privEditDoc"))					
					enabled = true;				
				else
					{
					enabled = false;break;
					}
				
				if(docClassName=="Underwriting_Document" || docClassName=="Claim_Document"){
					enabled = true;
					break;
				}
			}
			}
			else
				enabled = false;
			return enabled;
		},
		
		isVisible: function(repository, listType) {
			
			return true;
		},
		
		performAction: function(repository, items, callback,
				teamspace, resultSet, parameterMap) {
			
			if(items.length>100)
   		  	{
		   		var messageDialog = new MessageDialog();
		   		messageDialog.description.innerHTML ="Copy Documnets is allowed for a maximum of 100 documents.";
		        messageDialog.show();
   		  	}
			else
   		  	{
				var serviceParams = new Object();
				serviceParams.repositoryID = items[0].repository.id;
				serviceParams.osName = items[0].objectStore.symbolicName;
				serviceParams.userID = items[0].repository.userId;
				// this is asynchronous request.  Using asynch is preferred although slightly more complicated to code
				Request.invokePluginService("CopyDocsPlugin", "ReadConfigFileService",
					{
						requestParams: serviceParams,
						requestCompleteCallback: function(response) {	// success
							
							if(response && response.isInvokeService=="true")
							{
								var copyDocsDlg = new CopyDocumentsDialog();
								copyDocsDlg.show(repository, items, response);
												
							}
							
						}
					}
				);
				
			
				
   		  	}
		}
	});
});
/**

 * 
 */