
define([
"dojo/_base/declare",
	"ecm/MessagesMixin",
	"ecm/widget/dialog/BaseDialog",
	"ecm/model/Desktop",
	"ecm/model/Repository",
	"ecm/widget/TextBox",
	"ecm/widget/DatePicker",
	"ecm/widget/FilteringSelect",
	"ecm/widget/dialog/StatusDialog",
	"ecm/widget/dialog/MessageDialog",
	"dojo/text!./templates/CopyDocumentsDialog.html",
], function(declare,MessagesMixin,BaseDialog,Desktop,Repository,TextBox,DatePicker,FilteringSelect,StatusDialog,MessageDialog,template) {
	return declare("copyDocsPluginDojo/CopyDocumentsDialog", [
	    BaseDialog
	     ], {
		widgetsInTemplate: true,
		
		contentString: template,
		_lookupKey: null,
		_targetPolicySubmissionNumber: null,
		_grid: null,
		_copyButton: null,
		_documentClass: null,
		_sourcebtt: null,
		
		_items: null,
		_repository: null,

		_isValidatedBySource:true,
		_statusDlg: null,
		_workingDlg: null,
		policyNumber:null,
		submissionNumber:null,
		policyInceptionDate:null,
		businessTransactionType:null,
		insuredName:null,
		claimDocument:null,
		underwriting:null,
		claimNumber:null,
		claimantName:null,
		_refreshed : false,
		
		postCreate: function() {
			this.inherited(arguments);
			
			this._statusDlg = StatusDialog();
			this._statusDlg.contentNode.innerHTML="Copying...";
			this._statusDlg.showActionBar(false);
			
			this._workingDlg = StatusDialog();
			this._workingDlg.contentNode.innerHTML="Working...";
			this._workingDlg.showActionBar(false);
			
		},
		
		show: function(repository, items, response) {
			this._repository = repository;
			this._items = items;
			
			policyNumber=response.PolicyNumber;
			submissionNumber=response.SubmissionNumber;
			policyInceptionDate=response.PolicyInceptionDate;
			businessTransactionType=response.BusinessTransactionType;
			insuredName=response.InsuredName;
			claimDocument=response.ClaimDocument;
			underwriting=response.Underwriting;
			claimNumber=response.ClaimNumber;
			claimantName=response.ClaimantName;
			
			this.setTitle("Copy Documents");
			
			this._documentClass = items[0].getContentClass().id;
			
			for (var i in items) {
				if(i>0)
				{
					if(items[0].getValue(businessTransactionType)!=items[i].getValue(businessTransactionType))
					{
						var messageDialog = new MessageDialog();
				   		messageDialog.description.innerHTML ="Do not select documents of different business transaction types.";
				        messageDialog.show();
						return;
					}
					
				}	
			}
			
			if(this._documentClass==underwriting){
				
				dojo.style(this._targetClaimRow,"display","none");
				dojo.style(this._targetClaimantRow,"display","none");
				
				if(this._items[0].hasAttribute(businessTransactionType)){
				
				this._sourcebtt = this._items[0].getValue(businessTransactionType);
				this._sourcebtt = (this._sourcebtt=='Submission'?'2':'1')
				
			
			
				if(this._sourcebtt=='1'){
					this._lookupKey=policyNumber;
					this._targetPolSubRowLabel.innerHTML="Copy to Policy Number";
					
					var policy_Num = items[0].getValue(policyNumber);
					var policy_Inception_Date = items[0].getValue(policyInceptionDate);
					
					this._targetPolicySubNumber.set("value",policy_Num);
				
					this._targetPolicyEffectiveDate.constraints.fullYear=true;
					this._targetPolicyEffectiveDate.set("value",items[0].getValue(policyInceptionDate));
					
					
					for (var i in items) {
						if(i>0)
						{
							if(policy_Num!=items[i].getValue(policyNumber) || policy_Inception_Date!=items[i].getValue(policyInceptionDate))
							{
								var messageDialog = new MessageDialog();
						   		messageDialog.description.innerHTML ="Do not select documents of different policies.";
						        messageDialog.show();
								
								return;
							}
							
						}	
					}
					
					
				}else{
					this._lookupKey=submissionNumber;
					this._targetPolSubRowLabel.innerHTML="Copy to Submission Number";
					var sub_Num = items[0].getValue(submissionNumber);
					
					this._targetPolicySubNumber.set("value",sub_Num);
					var policy_Inception_Date = items[0].getValue(policyInceptionDate);
					this._targetPolicyEffectiveDate.constraints.fullYear=true;
					this._targetPolicyEffectiveDate.set("value",items[0].getValue(policyInceptionDate));
					for (var i in items) {
						
						
						if(i>0)
						{
							if(sub_Num!=items[i].getValue(submissionNumber) || policy_Inception_Date!=items[i].getValue(policyInceptionDate))
							{
								var messageDialog = new MessageDialog();
						   		messageDialog.description.innerHTML ="Do not select documents of different submission.";
						        messageDialog.show();
								
								return;
							}
							
						}
						
							
					}
					
					
					}
				}
				
				this._copyButton = this.addButton("Copy", "_onClickCopy", true, true);
			}
			else{
				dojo.style(this._targetPolicyRow,"display","none");
				dojo.style(this._targetPolicyEffectiveDateRow,"display","none");
				
				var claim_Num = items[0].getValue(claimNumber);
				var claimant_Name = items[0].getValue(claimantName);
				
				this._targetClaimNumber.set("value",claim_Num);
				this._targetClaimant.set("value",claimant_Name);
				
				
				for (var i in items) {
					
					
					if(i>0)
					{
						if(claim_Num!=items[i].getValue(claimNumber) || claimant_Name!=items[i].getValue(claimantName))
						{
							var messageDialog = new MessageDialog();
					   		messageDialog.description.innerHTML ="Do not select documents of different claim numbers.";
					        messageDialog.show();
							
							return;
						}
						
					}
					
						
				}
				this._copyButton = this.addButton("Copy", "_onClickCopyClaims", true, true);
			}
				
			
			this._createEmptyGrid();
			
			this.inherited("show", []);
			
		},
		
		formatDateFromIso: function(datum){
	        // Format the value in store, so as to be displayed.
	        if(datum!=null && datum!=""){
	        	var d = dojo.date.stamp.fromISOString(datum);
	        	return dojo.date.locale.format(d, {selector:"date", formatLength: "short"})
	        }else{
	        	return "";
	        }
	    },
		_onClickCopy: function(e) {
			var copyDocsPayload = new Object();
			var docGuids = new Array();
			var updateProps=new Object();
			var contentType= "application/json";
			var params = new Object();
			
			//Check if the copy button is enabled
			if(this._copyButton.get("disabled")){
				return false;	
			}
			
			updateProps.properties=[];
			
			params.repositoryId = this._repository.id;
			params.userID = this._repository.userId;
			params.os =this._repository.name;
			params.type = this._repository.type;
			params.server =this._repository.id;
			params.serverType =this._repository.type;
			params.ndocs = this._items.length;
			for (var i in this._items) {
				docGuids.push(this._items[i].id);
			}

			var targetProps = new Array();
			
			var polSubNumber = new Object();
			polSubNumber.property = this._lookupKey;
			polSubNumber.value = this._targetPolicySubNumber.get('value');
			targetProps.push(polSubNumber);
			
			if(this._targetPolicyEffectiveDate.get('value')!=null){
				var polEffDate = new Object();
				polEffDate.property = policyInceptionDate;
				polEffDate.value = dojo.date.stamp.toISOString(this._targetPolicyEffectiveDate.get('value'));
				targetProps.push(polEffDate);
			}	
			
			
			

			var targetPropsNode = new Object();
			targetPropsNode.properties = targetProps;
			
			var sourcePropsNode = new Object();
			sourcePropsNode.properties = new Array();
			
			copyDocsPayload.guids =  docGuids;
			copyDocsPayload.source = sourcePropsNode;
 			copyDocsPayload.target = targetPropsNode;
 			
			var displayCopyStatusFn = dojo.hitch(this,"_displayCopyStatus");
			var postParams = new Object();
			postParams.requestParams = params;
			postParams.requestBody = dojo.toJson(copyDocsPayload);
			postParams.requestCompleteCallback = displayCopyStatusFn;
			postParams.requestFailedCallback = dojo.hitch(this,function(response) {
													this.setMessage("Error Occured:" + response,"error");
													this._statusDlg.hide();
													}
												);
			
			ecm.model.Request.postPluginService(
					"CopyDocsPlugin",
					"CopyDocumentsService",
					contentType,
					postParams			
			);

			
			this._statusDlg.show();
			
		},
		
		_onClickCopyClaims: function(e) {

			var copyDocsPayload = new Object();
			var docGuids = new Array();
			var updateProps=new Object();
			var contentType= "application/json";
			var params = new Object();
			
			//Check if the copy button is enabled
			if(this._copyButton.get("disabled")){
				return false;	
			}
			
			updateProps.properties=[];
			
			params.repositoryId = this._repository.id;
			params.userID = this._repository.userId;
			params.os =this._repository.name;
			params.type = this._repository.type;
			params.server =this._repository.id;
			params.serverType =this._repository.type;
			params.ndocs = this._items.length;
			for (var i in this._items) {
				docGuids.push(this._items[i].id);
			}

			var targetProps = new Array();
			
			var targetclaimNumber = new Object();
			targetclaimNumber.property = claimNumber;
			targetclaimNumber.value = this._targetClaimNumber.get('value');
			targetProps.push(targetclaimNumber);
			
			if(this._targetClaimant.get('value')!=null){
				var targetClaimantName = new Object();
				targetClaimantName.property = claimantName;
				targetClaimantName.value = this._targetClaimant.get('value');
				targetProps.push(targetClaimantName);
			}	
			
			var targetPropsNode = new Object();
			targetPropsNode.properties = targetProps;
			
			var sourcePropsNode = new Object();
			sourcePropsNode.properties = new Array();
			
			copyDocsPayload.guids =  docGuids;
			copyDocsPayload.source = sourcePropsNode;
 			copyDocsPayload.target = targetPropsNode;
 			
			var displayCopyStatusFn = dojo.hitch(this,"_displayCopyStatus");
			var postParams = new Object();
			postParams.requestParams = params;
			postParams.requestBody = dojo.toJson(copyDocsPayload);
			postParams.requestCompleteCallback = displayCopyStatusFn;
			postParams.requestFailedCallback = dojo.hitch(this,function(response) {
													this.setMessage("Error Occured:" + response,"error");
													this._statusDlg.hide();
													}
												);
			
			ecm.model.Request.postPluginService(
					"CopyDocsPlugin",
					"CopyDocumentsClaimService",
					contentType,
					postParams			
			);

			
			this._statusDlg.show();
			
		},
		_createEmptyGrid: function() {
			
			this._destroyGrid();

			var layout = null;
			if(this._documentClass==underwriting){
				layout = [[
				           {'name': (this._sourcebtt=='2'?'Submission#':'Policy#'), 'field': (this._sourcebtt=='2'?'SubmissionNumber':'PolicyNumber'),'width': '100px'},
				           {'name': 'Document Title', 'field': 'title', 'width': '100px'},
				           {'name': 'Document Category', 'field': 'Underwriting_Document_Category','width': '170px'},
				           {'name': 'Document Sub Category', 'field': 'Underwriting_Document_Sub_Category','width': '180px'},
				           {'name': 'Copy Status', 'field': 'status'},
				           {'name': 'Error Description', 'field': 'ErrorDescription', 'width': '170px'}
				          
				]];		
			}
			else{
				layout = [[
				           {'name': 'Claim Number', 'field': 'ClaimNumber', 'width': '100px'},
				           {'name': 'Document Title', 'field': 'title', 'width': '100px'},
				           {'name': 'Document Category', 'field': 'Claim_Document_Category','width': '170px'},
				           {'name': 'Document Sub Category', 'field': 'Claim_Document_Sub_Category','width': '180px'},
				           {'name': 'Copy Status', 'field': 'status'},
				           {'name': 'Error Description', 'field': 'ErrorDescription', 'width': '170px'}
				           
				]];	
			}
 
		    /*set up data store*/
		    var data = {
		      identifier: "guid",
		      items: []
		    };
		    
		    var store = new dojo.data.ItemFileReadStore({data: data});
		    
			  /*create a new grid:*/
			this._grid = new dojox.grid.DataGrid({
		        structure: layout,
		        store: store,
		        selectionMode: "single"
		        });

			  /*append the new grid to the div*/
		    this._copyStatusGrid.appendChild(this._grid.domNode);
			
		     /*Call startup() to render the grid*/
			this._grid.startup();
			
		},
		
		_lookupEffectiveDates: function(value){
			this._enableCopy();
		},
		
		_enableCopy: function(e){
			var enableCopy =false;

			
			if(this._targetPolicySubNumber.isValid() && this._targetPolicyEffectiveDate.isValid())
				{
				this._targetPolicyEffectiveDate.constraints.fullYear=true;
				if(this._copyButton!=null)
					this._copyButton.set("disabled",false);
				enableCopy=true;
			}else if(this._targetClaimNumber.isValid() && this._targetClaimant.isValid())
				{
				if(this._copyButton!=null)
					this._copyButton.set("disabled",false);
				enableCopy=true;
			}
			else{
				if(this._copyButton!=null)
					this._copyButton.set("disabled",true);
			}
				
			return enableCopy;
			
			
		},

		_destroyGrid: function() {
			if (this._grid ) {
				this._grid.destroy();
			}
		},
		
		
		
		_displayCopyStatus: function(retPayload){
			this._statusDlg.hide();
			
			if(retPayload.exception!=null){
				this.setMessage("Error Occured: " + retPayload.exception,"error");
				return;
			}
			
			var copyStatus = retPayload.counts.success + " of " + retPayload.counts.total + " documents copied"
												+ (parseInt(retPayload.counts.success)==0? "" :" successfully. ");
			
			var msgType="info";
			if(parseInt(retPayload.counts.success)==0)
				msgType = "error";
			if(parseInt(retPayload.counts.success)<parseInt(retPayload.counts.total))
				msgType = "warning";
				
			this.setMessage(copyStatus,msgType);
			
		    /*set up data store*/
		    var data = {
		      identifier: "guid",
		      items: retPayload.documents
		    };
		    
		    var store = new dojo.data.ItemFileReadStore({data: data});
		    this._grid.setStore(store);
		    this._copyButton.set("disabled",true);
		    
		}
});
});