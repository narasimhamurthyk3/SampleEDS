package com.agcs.icn.custom.plugin;

import java.io.IOException;
import java.io.InputStream;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import com.filenet.api.constants.PropertyNames;
import com.filenet.api.core.Document;
import com.filenet.api.core.Factory;
import com.filenet.api.core.ObjectStore;
import com.filenet.api.exception.EngineRuntimeException;
import com.filenet.api.property.FilterElement;
import com.filenet.api.property.PropertyFilter;
import com.ibm.ecm.extension.PluginService;
import com.ibm.ecm.extension.PluginServiceCallbacks;
import com.ibm.ecm.json.JSONResponse;

/**
 * Provides an abstract class that is extended to create a class implementing
 * each service provided by the plug-in. Services are actions, similar to
 * servlets or Struts actions, that perform operations on the IBM Content
 * Navigator server. A service can access content server application programming
 * interfaces (APIs) and Java EE APIs.
 * <p>
 * Services are invoked from the JavaScript functions that are defined for the
 * plug-in by using the <code>ecm.model.Request.invokePluginService</code>
 * function.
 * </p>
 * Follow best practices for servlets when implementing an IBM Content Navigator
 * plug-in service. In particular, always assume multi-threaded use and do not
 * keep unshared information in instance variables.
 */
public class ReadConfigFileService extends PluginService {
	
	public String userID;

	/**
	 * Returns the unique identifier for this service.
	 * <p>
	 * <strong>Important:</strong> This identifier is used in URLs so it must
	 * contain only alphanumeric characters.
	 * </p>
	 * 
	 * @return A <code>String</code> that is used to identify the service.
	 */
	public String getId() {
		return "ReadConfigFileService";
	}

	/**
	 * Returns the name of the IBM Content Navigator service that this service
	 * overrides. If this service does not override an IBM Content Navigator
	 * service, this method returns <code>null</code>.
	 * 
	 * @returns The name of the service.
	 */
	public String getOverriddenService() {
		return null;
	}

	/**
	 * Performs the action of this service.
	 * 
	 * @param callbacks
	 *            An instance of the <code>PluginServiceCallbacks</code> class
	 *            that contains several functions that can be used by the
	 *            service. These functions provide access to the plug-in
	 *            configuration and content server APIs.
	 * @param request
	 *            The <code>HttpServletRequest</code> object that provides the
	 *            request. The service can access the invocation parameters from
	 *            the request.
	 * @param response
	 *            The <code>HttpServletResponse</code> object that is generated
	 *            by the service. The service can get the output stream and
	 *            write the response. The response must be in JSON format.
	 * @throws Exception
	 *             For exceptions that occur when the service is running. If the
	 *             logging level is high enough to log errors, information about
	 *             the exception is logged by IBM Content Navigator.
	 */

	public void execute(PluginServiceCallbacks callbacks, HttpServletRequest request, HttpServletResponse response)
			throws Exception {

		String repositoryID = request.getParameter("repositoryID");
		String propertiesFilePath = "/Config/DDMOperations.properties";
		userID = request.getParameter("userID");
		
		ObjectStore os = callbacks.getP8ObjectStore(repositoryID);
		
		java.util.Properties prop = readConfigurationsFromCE(os, propertiesFilePath);
		JSONResponse responseJSON = new JSONResponse();
		java.util.Properties propFromCE = new java.util.Properties(prop);
		String entryTemplates = propFromCE.getProperty("entryTemplates");
		String mainProps = propFromCE.getProperty("mainProps");
		String readOnlyPropUW = propFromCE.getProperty("readOnlyPropUnderwriting_Document");
		String readOnlyPropClaim = propFromCE.getProperty("readOnlyPropClaim_Document");
		String logFilePath = propFromCE.getProperty("AGCSPluginLogFilePath");
		String logLevel = propFromCE.getProperty("LogLevel");
		responseJSON.put("entryTemplates", entryTemplates);
		responseJSON.put("mainProps", mainProps);
		responseJSON.put("readOnlyPropClaim", readOnlyPropClaim);
		responseJSON.put("readOnlyPropUW", readOnlyPropUW);
		
		responseJSON.put("isInvokeService", "true");
		
		if (logFilePath != null && !logFilePath.equals("")) {
			
			AGCSPluginLogger.changeLoggerIfAlreadyNotChanged(callbacks, "config", logLevel, logFilePath);
		}
		
		AGCSPluginLogger.logInfo(" - Config file was read successfully", "ReadConfigFileService", "execute",userID);

		responseJSON.serialize(response.getOutputStream());
	}

	public String[][] getEntryTemplateFields(java.util.Properties prop) {

		String[] mainProps = prop.getProperty("mainProps").split(";");
		String[][] entryTemplateProps = new String[mainProps.length][];

		for (int i = 0; i < mainProps.length; i++) {
			entryTemplateProps[i] = mainProps[i].split(",");

		}
		return entryTemplateProps;
	}

	public java.util.Properties readConfigurationsFromCE(ObjectStore objectStore, String propFilePath) {

		java.util.Properties propCE = new java.util.Properties();
		InputStream proprStream = null;

		try {

			PropertyFilter pf = new PropertyFilter();
			pf.addIncludeProperty(new FilterElement(null, null, null, PropertyNames.CONTENT_ELEMENTS, null));
			Document propDoc = Factory.Document.fetchInstance(objectStore, propFilePath, null);
			proprStream = propDoc.accessContentStream(0);
			propCE.load(proprStream);

		} catch (IOException ioe) {
			AGCSPluginLogger.logException( ioe, "ReadConfigFileService", "readConfigurationsFromCE",userID);

		} catch (EngineRuntimeException ex) {
			AGCSPluginLogger.logException(ex, "ReadConfigFileService", "readConfigurationsFromCE",userID);
		}

		return propCE;
	}

}
