dojo.require("agcsPluginDojo.AddManyDocumentsDialog");

require(["dojo/_base/declare",
					"dojo/dom-class",
					"dojo/dom-style",
					"dojo/_base/lang",
					"dojo/aspect",
					"ecm/widget/AddContentItemPropertiesPane",
					"ecm/widget/listView/ContentList",
					"ecm/widget/listView/gridModules/DndFromDesktopAddDoc",
					"ecm/widget/AddContentItemGeneralPane",
					"ecm/widget/dialog/AddContentItemDialog",
					"ecm/widget/listView/gridModules/DndFromDesktop",
					"dojo/_base/array",
					"ecm/model/Request",
					"aRCNetPluginDojo/DNDMetaDataUpdateAction",
					"ecm/widget/dialog/MessageDialog",
					"ecm/widget/search/SearchTab",
					"ecm/widget/search/SearchForm",
					"ecm/widget/search/SearchTabController",
					"ecm/model/_searchUtils",
					"ecm/widget/PropertyEditors",
					"ecm/widget/dialog/ShowHyperlinkDialog"
], 

function(declare,
					domClass,
					domStyle,
					lang,
					aspect,
					AddContentItemPropertiesPane,
					ContentList,
					DndFromDesktopAddDoc,
					AddContentItemGeneralPane,
					AddContentItemDialog,
					DndFromDesktop,
					array,
					Request,
					DNDMetaDataUpdateAction,
					MessageDialog,
					SearchTab,
					SearchForm,
					SearchTabController,
					utils,
					PropertyEditors,
					ShowHyperlinkDialog
) {   
    
                /*
                Global Variable
                */
                
                var searchTemplateName;
                var searchTemplateContentClass; 
                var dndRowGridObject;
                var isDragNDrop="false";
                var isMultipleDoc="false";
                var entryTemplateName,mainProps,entryTemplates,entryTemplateIndex;
                var repo,isInvokeService="false";
                
                lang.setObject("executeAddMany", function(repository, items, callback, teamspace, resultSet, parameterMap, context) {

                        console.debug("Entering::executeAddMany ::",this);
                        isDragNDrop="false";
                        console.debug("repository.getOpenedSearches",repository.getOpenedSearches());
                        console.debug("repository.openedSearches",repository.openedSearches);
                        var rootItem = repository.getOpenedSearches();
                        console.debug("rootItem ",rootItem );
                        var addManyDocsDlg = new agcsPluginDojo.AddManyDocumentsDialog();
                        try {
                             	console.debug("Before show dialog",addManyDocsDlg);
                             	console.log("Before show dialog"+repository.toString());
															var callback = lang.hitch(this, function(item){});

                                  
                                	  /*
                                	  aspect.after(addManyDocsDlg.addContentItemPropertiesPane, "onCompleteRendering", function() {
                                		  console.log("inside set");
                                		  addManyDocsDlg.addContentItemPropertiesPane.setPropertyValue("Business_Transaction_Type", "00998877665544332211");
                                		  console.log("BTT set.")
                                		  //addManyDocsDlg.addContentItemPropertiesPane.setPropertyValue("AccountName", "foo bar");
                                	    }, true);
                                	  */
                               addManyDocsDlg.showUsingTemplateItem(repository, null, true, false, callback, null ,null );
                               console.debug("After show dialog");

                       	} catch (e) {
                            	   console.error("Error showing add many dialog",e);
                        }

                               console.debug("Exiting::executeAddMany");

                });

                
								/*
                Handle things post get search results NOT USED
                */
								
								/*aspect.around(SearchForm.prototype, "_enableSearch", lang.hitch(this,function(originalFunction){

										return function() {
											
										}
								}));*/
							
							
								/*
								aspect.around(SearchForm.prototype, "onSearchCriteriaLoad", lang.hitch(this,function(originalFunction){

										return function() {
											
											console.debug("On Search onSearchCriteriaLoad");
											//this._moreOptions.fileTypeOptionHidden=true;
											
										}
								}));*/
								
								/*
								aspect.around(SearchTabController, "onClick", lang.hitch(this,function(originalFunction){

										return function() {
											
											console.debug("On Search Tab Button Click");
											
										}
								}));*/
								
								
								/**
								*Code to remove version buttons from showhyperlink as well as Text in the Dialog to remove version references
								*NOT REQUIRED as per Katie -- 07/09/2016 19:15CET
								*/
							/*	
								aspect.after(ShowHyperlinkDialog.prototype,"show",function(originalFunction){
									console.log("Entering After ShowHyperlinkDialog::show");
									if(ecm.model.desktop.name=="DDM"){
										
										//console.log("ShowHyperlinkDialog::show", this.introText.innerHTML);
										//console.log("ShowHyperlinkDialog::show", this._showHyperlink._showHyperlinkShowOptions);
										domStyle.set(this._showHyperlink._showHyperlinkShowOptions, "display", "none");
										var introText=this.introText.innerHTML;
										var introTextNoVersion=introText.split(".");
										this.introText.innerHTML = introTextNoVersion[0]+".";
										
									}
									console.log("Exiting After ShowHyperlinkDialog::show");							
								});
							*/
								//allow search on adding atleast one criterion
								aspect.around(SearchTab.prototype, "_meetsMinimumCriteria", lang.hitch(this,function(originalFunction){
                    	return function(minCriteriaMet, criteria) {
													minCriteriaMet=false;
                          criteria = this.searchTemplate.searchCriteria;
                          //minCriteriaMet=originalFunction(this);
                          console.debug("On _meetsMinimumCriteria");
                          if (this.repository._isP8()) {
                                var hasTextCriteria = this.searchForm.isTextSearchCriteriaDefined();
                                var hasAttribCriteria = array.some(criteria, function(criterion) {
                                        return utils.meetsMinimumCriteria(criterion);
                                });
                                minCriteriaMet = hasTextCriteria || hasAttribCriteria;
                          }else { // subclass selected
                          			minCriteriaMet = true;
                          }
                          
                          if (!minCriteriaMet)
                           			this._showMessage(this.messages.search_insufficient_input);
                          return minCriteriaMet;
	          					}
    						}));

								
								/*aspect.around(AddContentItemPropertiesPane.prototype, "afterRenderAttributes", lang.hitch(this,function(originalFunction){

									return function(attributeDefinitions, item, reason, isReadOnly) {
									
										console.log("Inside afterRenderAttributes");
										//var titlePropertyName = this.getTitlePropertyName();
										var field = this._commonProperties.getFieldWithName(this.getTitlePropertyName());
										console.log("field "+field);
										array.some(attributeDefinitions, function(attributeDefinition) {
											console.log(attributeDefinition);
											if (attributeDefinition.id == titlePropertyName) {
												console.log("***********");
												//attributeDefinition.required = false;
												//attributeDefinition.readOnly = true;
												// Clear the default value.
												// It may have been set by an entry template or EDS, and the file name will be used instead.
												attributeDefinition.defaultValue = [];
												return true;
											}
										});
									}
								}));*/
									
								
                aspect.around(SearchTab.prototype, "onLoad", lang.hitch(this,function(originalFunction){

										return function() {
		
		                	 	console.log("Inside Overridden Search onLoad");
		                	 	
		                	 	/**Below code will modify search tab and disables hyperlink available on search page for - Search In, More Options, Property Options and Result Display Button
		                	 	*
		                	 	*/
		                	 	
		                	 	domClass.add(this._propertyOptions._optionsLink.domNode,"idxDropDownLinkDisabled dijitDisabled");   //Disables PropertyOPtions HyperLink
		                  	domClass.add(this._propertyOptions._optionsDialog.domNode, "dijitHidden"); //Hides Property Options from SearchTab
		                  	//domClass.add(this._propertyOptions.domNode, "dijitHidden");//Hides Property Options from SearchTab
		                  	domClass.add(this._resultsDisplayButton.domNode, "dijitHidden"); ////Hides Display Options Button
		                  	// Disabled all Moreoptions as per latest req. Below line can be commented
		                  	//domClass.add(this._moreOptions._fileTypeOptionNode, "dijitHidden"); //Hides File Type Filter from search Options
		                  	domClass.add(this._moreOptions._optionsLink.domNode, "idxDropDownLinkDisabled dijitDisabled");//Disables More OPtions HyperLink
		                		domClass.add(this._moreOptions._optionsDialog.domNode, "dijitHidden"); //Hides More OPtions Options from SearchTab
		                  	
		                  	
		                  	
		                  	domClass.add(this._searchIn._optionsLink.domNode, "idxDropDownLinkDisabled dijitDisabled");//Disables SearchIn HyperLink
		                		domClass.add(this._searchIn._optionsDialog.domNode, "dijitHidden"); //Hides SearchIn Options from SearchTab
		                		
		                		/**
												Code Module to read properties from config file, these properties will be used by DnD		                		
		                		*/
		
														searchTemplateName=this.searchTemplate.name;
														console.log("1SearchTab");
														searchTemplateContentClass=this.searchTemplate._searchContentClass;
														console.log("2SearchTab"+this.searchTemplate);
														repo=this.searchTemplate.repository;
														console.log("3SearchTab");
														if(isInvokeService=="false"){
																var serviceParams = new Object;
																serviceParams.repositoryID= repo.id;
																console.log("4SearchTab"+repo.id);
																 Request.invokePluginService("agcsplugin", "ReadConfigFileService",
																 {
																        requestParams: serviceParams,
																        requestCompleteCallback: function(response) {    
																			      if(response){
																		  	 	  	console.log("response SearchTab::",response);
																			     	  if(response.entryTemplates && response.mainProps && response.isInvokeService){
																			     	  	       	isInvokeService=response.isInvokeService;
																			                  mainProps=response.mainProps;
																			                  entryTemplates=response.entryTemplates;
																			                  console.debug("entryTemplates SearchTab>>>>>>",entryTemplates);
																			                  console.debug("mainProps SearchTab>>>>>>",mainProps);
																			                  console.debug("isInvokeService SearchTab>>>>>>",isInvokeService);
																							}
																		
																		        }
																
																     		}
																
																 })
																console.log("Exiting getResultSet SearchTab ");
				
				                     		
		                     		}
		                    		this._loaded = true;             
		                } 
                	 
                }));
                
                
                /** Read Configurations moved from  ContentList.prototype, "getResultSet" to other aspect.around, currently on  ;; SearchTab.prototype, "onLoad",
                */
								
								/*
                
                
                /*
                //Disable multiple browsing of file
                aspect.around(AddContentItemGeneralPane.prototype, "_onBrowseForFile", lang.hitch(this,function(originalFunction){
                	console.log("Inside _onBrowseForFile");
                	//domAttr.remove(this._fileInput, "multiple");              	               
                }));*/



               /* aspect.around(AddContentItemDialog.prototype, "onAdd", lang.hitch(this,function(originalFunction){

                    return function() {

                            console.log("Entering onAdd :",this);
                            console.log("originalFunction onAdd :",originalFunction);
                            var lineOfBusiness=this.addContentItemPropertiesPane.getPropertyValue("DDM_Line_Of_Business");
                            var restrictedAccess=this.addContentItemPropertiesPane.getPropertyValue("Restricted_Access");
        										var className=this.addContentItemPropertiesPane._contentClass.name;
        										var serviceParams = new Object;
                        		serviceParams.repositoryID= this.addContentItemPropertiesPane._commonProperties.repository.id;
                        		serviceParams.LOB=lineOfBusiness;
                        		serviceParams.restrictedAccess=restrictedAccess;
        										Request.invokePluginService("agcsplugin", "UpdateSecurityPolicy",

                            {
													           requestParams: serviceParams,
                                     requestCompleteCallback: function(response) {    

                                     if(response){
                                  	   
                                  	   console.log("success");
                                     }

                             }

                             })
        					
                           
                    }
            		}));*/

                /*

                * This method is called when the ICN tries to open a add document dialog box on drag-n-drop of a document.

                * Here, depending upon the searchContentClass, the entry template is getting fetched.

                */

                aspect.around(DndFromDesktopAddDoc.prototype, "displayDialog", lang.hitch(this,function(originalFunction){

		              return function(files, targetItem, teamspace, defaultClass) {
		              		var tempThis=this;
		              		var repository = targetItem.repository ? targetItem.repository : targetItem;
		              		var openAction = new DNDMetaDataUpdateAction();
		              		/**
		
		                      * ARCNET SPECIFIC CODE
		
		                      */
		              		var items=this._getTargetItem(targetItem);
		              		console.log(this._getTargetItem(targetItem))
		                 	var parent = targetItem.parentFolder ? targetItem.parentFolder : targetItem.parent;
		              		//console.log(parent)
		                  var itemPath=(items.attributes.PathName);
		                      //console.log(parent.attributes.PathName)
		                  console.log(itemPath)
			    						if(undefined != itemPath){
		                     	var substring="ARCNet";
		                     	var index=itemPath.indexOf(substring);
		                     	if(index>-1){
		                      		console.log("ARCNet entity")
		                      		openAction.performAction(repository, items, null, teamspace, null, null,files);
		
		                      }
													else{  
		                      		var messageDialog=new MessageDialog({
		                      				text: "Document cannot be Dragged and Dropped to this Location"
		                      		});
														messageDialog.show();
													}
											}else{	
													var entryTemplateArray;
		                      console.debug("Entering displayDialog ::",tempThis);
		                      if(isMultipleDoc=="false"){

                              /*console.log("isDragNDrop in displayDialog :: ",isDragNDrop);         

                              console.log("inside displayDialog ::",tempThis);

                              console.log("targetItem ::",targetItem);

                              console.log("defaultClass ::",defaultClass);

                              console.log("files ::",files);

                              console.log("teamspace ::",teamspace);

                              console.log("repository ::",repository);*/
															console.log("searchTemplateContentClass::",searchTemplateContentClass);
		                          console.log("itemPath::",itemPath);
		                          if(searchTemplateContentClass)
		                             	defaultClass=searchTemplateContentClass;
		
		                          if (tempThis.addContentItem)
		                             	tempThis.addContentItem.destroyRecursive();
		
		                              tempThis.addContentItem = new AddContentItemDialog();
		
		                              if (defaultClass) {
		                              	tempThis.addContentItem.setDefaultContentClass(defaultClass);
		                              }
		                              
		                              tempThis.addContentItem.setFiles(files);
		                              /*var tempCallback = lang.hitch(this, function(item){
		                              	console.log("tempCallback >>>"+item.toString());
		                              	
		                             		 });*/
		
		                              if(entryTemplates)
		                              	entryTemplateArray=entryTemplates.split(',');
		
		                              console.log("entryTemplateArray >>>",entryTemplateArray);
		
		                              var entryTemplateListRetrievedHandler = lang.hitch(this, function(entryTemplatesObj) {
		                              		var isEntryTemplateRetrieved=false;
		                                  var entryTemplateRetrievedHandler = lang.hitch(this, function(entryTemplate) {
		                                  			var tempCallback = lang.hitch(this, function(item){});
		                                   			if(entryTemplate && entryTemplate.addClassName && entryTemplate.addClassName==defaultClass.id && entryTemplate.folder)
		                                   			{
		
																								 var parentFolderContentItem=entryTemplate.folder;
																								 isEntryTemplateRetrieved=true;
																								 entryTemplateName=entryTemplate.name;
																								 tempThis.addContentItem.show(repository, parentFolderContentItem, (entryTemplate.type == ecm.model.EntryTemplate.TYPE.DOCUMENT), false, tempCallback,teamspace, true, entryTemplate);
																								 return false;
		                                   			}
		
		                                  });
		                              		dojo.every(entryTemplatesObj, function(entryTemplate) {
																						dojo.every(entryTemplateArray, function(et,index){
																												if(entryTemplate.name==et){
																														entryTemplateIndex=index;
																														console.log("entryTemplateIndex >>",entryTemplateIndex);
																														if (!entryTemplate.isRetrieved) {
																																entryTemplate.retrieveEntryTemplate(entryTemplateRetrievedHandler, false, false);
																																console.debug("entry template was not retrieved >>",entryTemplate);
															console.log("searchTemplateName "+searchTemplateName);
																																
if(searchTemplateName=="Claim Search" || searchTemplateName=="Claim Engineering Search"){
entryTemplateIndex=0;
}				
																														}else{
														
																																entryTemplateRetrievedHandler(entryTemplate);
																																console.debug("entry template was already retrieved >>",entryTemplate);
		
		                                                      	}
																												}
		                                                    return true;
		
		                                        });
		
                                            if(isEntryTemplateRetrieved==true){
                                            	console.log("isEntryTemplateRetrieved >>",isEntryTemplateRetrieved);
                                            	return false;

                                            }
		                                        return true;
		                              		});
		
		                              });
		
		                              repository.retrieveEntryTemplates(entryTemplateListRetrievedHandler,"Document",null,null,null);
		                              console.debug("Exiting displayDialog ");
		
		                      }
		                  }
		              }
                }));

               /* aspect.around(AddContentItemDialog.prototype, "_onFileInputChange", lang.hitch(this,function(originalFunction){
            		return function() {

            			console.log("DDM FileInput Change");
            			if(this.parentFolder!=null)
		            	{
		            			var FiledInFolder=this.parentFolder.attributes.PathName;
		            			
		            				var fileName = this.addContentItemGeneralPane.getInputFileName();
		            			
		            				var titlePropertyName = this.addContentItemPropertiesPane.getTitlePropertyName();
var docTitle=this.addContentItemPropertiesPane.getPropertyValue(titlePropertyName);
console.log("docTitle:"+docTitle);
console.log("fileName:"+fileName);

		            				console.log("clearing DocumentTitle doc is filed in "+FiledInFolder+fileName+titlePropertyName);
		            				//if(((FiledInFolder=="/Underwriting Documents" || FiledInFolder=="/Claim Documents")||undefined == FiledInFolder))
if(undefined==FiledInFolder)
this._onChangeProperties();
							if((FiledInFolder=="/Underwriting Documents" || FiledInFolder=="/Claim Documents")&&(docTitle==null||docTitle.trim().length==0))
		            				fileName='';//
		            				console.log("setting docTitle"+docTitle);
		            				this.addContentItemPropertiesPane.setPropertyValue(titlePropertyName, docTitle);
		            				console.log("Exit DDM file Input Change");
            				}
            				else{
            					console.log("Calling Original_onFileInputChange ");
            					originalFunction(this);
            				}
            		};
            	}));*/

                /*

        *"_getExternalDropTargetRow" method is used to fetch the row id, on which the user

        * has dropped the files. This is required to fetch all the fields corresponding that row document.  

         */

                aspect.around(DndFromDesktop.prototype, "_getExternalDropTargetRow", lang.hitch(this,function(originalFunction){
                	return function(evt) {
                		var t = this, g = t.grid;
                		var rowNode = t._getExternalDropTargetRowNode(evt);
                		console.debug("Entering _getExternalDropTargetRow ::",t);
                		isDragNDrop="true";
                		
                		if (rowNode) {

                             //console.log("g.row(rowNode.getAttribute('rowid'))---",g.row(rowNode.getAttribute('rowid')));
                			dndRowGridObject=g.row(rowNode.getAttribute('rowid'));
                			return g.row(rowNode.getAttribute('rowid'));

                    }

                    else{
                        	//console.log("dndRowGridObject in else null");
                        	dndRowGridObject=null;

                    }
                		console.debug("Exiting _getExternalDropTargetRow");
                		return null;

                }

        }));

  aspect.around(ContentList.prototype, "getResultSet", lang.hitch(this,function(originalFunction){

                        return function() {

                                console.log("Entering getResultSet :",this);

                                if(this && this._resultSet && this._resultSet.searchTemplate){
										console.log(this._resultSet);
                                        searchTemplateName=this._resultSet.searchTemplate.name;
                                        console.log("1");
                                        searchTemplateContentClass=this._resultSet.searchTemplate._searchContentClass;
                                        console.log("2");
                                        repo=this._resultSet.searchTemplate.repository;
                                        //console.debug("this in content list isInvokeService :",isInvokeService);
                                        console.log("3");
                                        if(isInvokeService=="false"){
                                        	var serviceParams = new Object;
                                        	serviceParams.repositoryID= repo.id;
                                        	console.log("4"+repo.id);
                                            Request.invokePluginService("agcsplugin", "ReadConfigFileService",

                                             {

                                                   requestParams: serviceParams,
                                                   requestCompleteCallback: function(response) {    

                                                   if(response){
                                                	   console.log("response ::",response);
                                                	   if(response.entryTemplates && response.mainProps && response.isInvokeService)

                                                          {

                                                             isInvokeService=response.isInvokeService;
                                                             mainProps=response.mainProps;
                                                             entryTemplates=response.entryTemplates;
                                                             console.debug("entryTemplates >>>>>>",entryTemplates);
                                                             console.debug("mainProps >>>>>>",mainProps);
                                                             console.debug("isInvokeService >>>>>>",isInvokeService);

                                                                                        
                                                          }

                                                        }

                                                }

                                                })

                                        }

                                console.log("Exiting getResultSet ");

                                //return this._resultSet;
                                }
                                return this._resultSet;
                        }
                }));
      

        /*

        * onDrop method is called whenever the user drops some file(s) onto the search results

        * Customization is done in order to show an error message whenever the user drops multiple documents  

         */

         	aspect.around(DndFromDesktopAddDoc.prototype, "onDrop", lang.hitch(this,function(originalFunction){
                	return function(row, files, evt) {
                			var t = this;
                			var rowItem = row ? row.item() : null;
                			console.debug("Entering onDrop ::",t);

                			if(files && files.length>1){

                					//console.log("files.length in onDrop ::",files.length);
                					isMultipleDoc="true";
                					var messageDialog = new ecm.widget.dialog.MessageDialog({
                						text: "Sorry! Cannot add multiple documents" // Message to be changed according to OBT requirement
                					});
                					messageDialog.show();
                					console.debug("Error message shown");

                                    if(t.addContentItem){
                                    	t.addContentItem.destroy();
                                    }
                			}

                else{
                		isMultipleDoc="false";
                		t._drop(t._getTargetItem(rowItem), files, evt);
                }
                }
                	console.debug("Exiting onDrop");

        	}));
/*aspect.around(AddContentItemPropertiesPane.prototype, "setDefaultDocumentTitle", lang.hitch(this,function(originalFunction){
            	 		return function() {
console.log("Inside setDefaulttitle"+this);
var contentClass=this._contentClass.id;
console.log(contentClass);
//_addContentItemDialog.addContentItemGeneralPane
//
if(contentClass=="Underwriting_Document" || contentClass=="Claim_Document")
console.log("DDM Template selected");
else
{
var titlePropertyName = this.getTitlePropertyName();
				if (titlePropertyName) {
					var currValue = this.getPropertyValue(titlePropertyName);
					if (!currValue || currValue.length == 0) {
						var fileName;
						if (this._addContentItemDialog.addContentItemGeneralPane.hasExternalFiles()) {
							var fileNameArray = this._addContentItemDialog.addContentItemGeneralPane._externalFileNames.get("value");
							fileName = ((fileNameArray != null) && (fileNameArray.length > 0)) ? fileNameArray[0] : "";
						} else {
							fileName = this._addContentItemDialog.addContentItemGeneralPane.getInputFileName();
						}
						if (fileName) {
							this.setPropertyValue(titlePropertyName, fileName);
						}
					}
				}
}
//this.inherited(arguments);			
//
console.log("After setDefaulttitle");

}
}));*/
        /*aspect.around(PropertyEditors.prototype, "validateRequiredFields", lang.hitch(this,function(originalFunction){
            		console.log("Validate required fields");
            			return null;
            		            	}));*/

        /*

        * This method is called when the add document dialog fields are rendered.

        * Here we are setting all the fields values with respect to the fields of the document row on which the 

         * file has been dragged and dropped.

        */

             aspect.around(AddContentItemPropertiesPane.prototype, "onCompleteRendering", lang.hitch(this,function(originalFunction){
            	 		return function() {
            		 				var t=this;
            		 				var arrayOfFields,mainPropsArray;
            		 				console.debug("Entering onCompleteRendering ::",t);
            		 				console.debug("mainProps in onCompleteRendering ::",mainProps);
//console.log(t.addContentItemPropertiesPane._contentClass);
//console.log(this._renderingClass.id);
//t.addContentItemPropertiesPane.setPropertyValue("DocumentTitle", '');
//var file='';
//console.log("this.addContentItemGeneralPane.getInputFileName()"+this.addContentItemGeneralPane.getInputFileName());
//console.log(t._commonProperties.setPropertyValue("DocumentTitle"));
//t._commonProperties.setPropertyValue("DocumentTitle",file);
//console.log("Document title set to ="+t._commonProperties.getPropertyValue("DocumentTitle"));


												if(mainProps){
					                   	mainPropsArray=mainProps.split(';');
                            	var entryTemplateProps=new Array(mainPropsArray.length);

		                          for(var i=0;i<mainPropsArray.length;i++){
		                          	entryTemplateProps[i]=mainPropsArray[i].split(',');
		                          	console.debug("Entry Template Properties >>",entryTemplateProps);
		
		                          }
		                          if(isDragNDrop=="true"){        console.log("entryTemplateIndex="+entryTemplateIndex);
					                          	arrayOfFields=entryTemplateProps[entryTemplateIndex];
					                          	console.debug("arrayOfFields >>",arrayOfFields);
					                          	if(dndRowGridObject && dndRowGridObject.item()){
					                          			gridRowContentItemObject=        dndRowGridObject.item();
					                          			console.debug("gridRowObject item >>",gridRowContentItemObject);
					                          			gridRowContentItemObject.retrieveAttributes(function(gridRowCallBack){
					                          			console.log("gridRowCallBack >>",gridRowCallBack)
					                          			if(t && t._commonProperties){
																							
					                          					//var fileName='';
																							//t._commonProperties.setPropertyValue("DocumentTitle", fileName);
 								
 																							//to force not to check changed values - Test
 								
 																							//t._commonProperties.fieldschanged=false;
 								
																							//this._clearClassErrorMessage();
																							//console.log("cleared title");
																							//var Docfield = t._commonProperties.getFieldWithName(this.getTitlePropertyName());
																							//console.log("get title"+this.getTitlePropertyName());
 																							/*
														 								 		//var titlePropertyName = this.addContentItemPropertiesPane.getTitlePropertyName();
														            				//console.log("clearing DocumentTitle doc is filed in "+FiledInFolder);
														            				//if(FiledInFolder=="/Underwriting Documents" || FiledInFolder=="/Claim Documents")
														            				//fileName='';
														            				//console.log("FileName"+fileName);
														            				//this.addContentItemPropertiesPane.setPropertyValue(titlePropertyName, fileName);
														 								 */
                                							dojo.forEach(arrayOfFields, function(item, index){
		                                							if(item && gridRowCallBack.getValue(item)){
		                                									if(gridRowCallBack.getAttributeType(item)=="xs:timestamp"){
		                                												fieldValue = new Date(gridRowCallBack.getValue(item));
		                                									}else{                               									
		                                												fieldValue = gridRowCallBack.getValue(item);
		                                									//console.log("VALUE "+fieldValue);
		                                									}
																											//console.log("item inside "+t.addContentItemPropertiesPane.getTitlePropertyName());
																											//if(item=="DocumentTitle")
																											//fieldValue='';
		                                                  t._commonProperties.setPropertyValue(item, fieldValue);
		                                                  console.log("CommonProperties item >> ",item," value >>",fieldValue);
																											//var field = this._commonProperties.getFieldWithName(this.getTitlePropertyName());
																											//console.log(field);								
																											//t._commonProperties.setFieldFocus("Business_Transaction_Type");
		
		
		                                              }
                                							})

                                          }

                                         },null,false,function(error){console.debug("Error in RetrieveAttribute Service",error)});

                                			}	
                              }
												}

                  }

        		}));
});
