/**
 * @author Philip
 *
 */
package com.agcs.icn.custom.plugin;

import java.util.Locale;

import com.ibm.ecm.extension.PluginAction;

/**
 * @author Philip
 *
 */
public class AGCSAddManyDocumentsAction extends PluginAction {

	@Override
	public String getActionFunction() {
		return "executeAddMany";
	}

	@Override
	public String getIcon() {
		return null;
	}

	@Override
	public String getId() {
		return "AGCSAddManyDocumentsAction";
	}

	@Override
	public String getName(Locale arg0) {
		return "Add Documents";
	}

	@Override
	public String getPrivilege() {
		return "privViewDoc";
	}

	@Override
	public String getServerTypes() {

		return "p8";
	}

	@Override
	public boolean isMultiDoc() {
		return true;
	}

	@Override
	public boolean isGlobal() {
		return true;
	}
}
