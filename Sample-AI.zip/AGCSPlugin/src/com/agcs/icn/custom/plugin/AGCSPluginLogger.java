/**
 * 
 */
package com.agcs.icn.custom.plugin;

import java.io.File;
import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.apache.log4j.PatternLayout;
import org.apache.log4j.RollingFileAppender;

import com.ibm.ecm.extension.PluginServiceCallbacks;

/**
 * @author
 *
 */
public class AGCSPluginLogger {

	private static Logger agcsPluginLogger = null;

	public static void clearLogger() {
		if (agcsPluginLogger != null) {
			agcsPluginLogger.removeAllAppenders();
		}

		agcsPluginLogger = null;
	}

	private static void changeLogFile(String logFilePath, String logLevel) throws Exception {
		try {

			if (agcsPluginLogger != null) {
				return;
			}

			agcsPluginLogger = Logger.getLogger(AGCSPluginLogger.class);

			if (!logFilePath.toLowerCase().endsWith(".log") && !logFilePath.toLowerCase().endsWith(".txt")) {
				logFilePath += ".log";

			}

			File file = new File(logFilePath);

			if (!file.exists()) {
				String parentDirPath = file.getParent();
				if (parentDirPath != null) {
					File parentDir = new File(parentDirPath);
					if (!parentDir.exists()) {
						throw new Exception(String.format("Invalid File path '%s' - The directory '%s' does not exists",
								logFilePath, parentDir));
					}
				} else {
					throw new Exception(String.format("Invalid File path '%s'", logFilePath));
				}
				file.createNewFile();
			}

			agcsPluginLogger.setLevel(Level.toLevel(logLevel.toUpperCase()));
			
			PatternLayout layout = new PatternLayout();
			layout.setConversionPattern("%-5d{yyyy-MM-dd HH:mm:ss} %-6p    -  %m%n");
			
			RollingFileAppender rollingFileAppender =  new RollingFileAppender(layout, file.getAbsolutePath());
			rollingFileAppender.setName("agcsPluginAppender");
			rollingFileAppender.setMaxFileSize("2MB");
			rollingFileAppender.setMaxBackupIndex(3);
			
			agcsPluginLogger.addAppender(rollingFileAppender);
			

		}

		catch (Exception e) {

			throw e;

		}
	}

	public synchronized static void logDebug(String logMessage, String sourceClass, String sourceMethod, String username) {

		logMessage = "UserName : "+ username +",Class :'" + sourceClass + "',Method :'" + sourceMethod + "',Message :" + logMessage+System.getProperty("line.separator");
		agcsPluginLogger.debug(logMessage);

	}

	public synchronized static void logInfo(String logMessage, String sourceClass, String sourceMethod, String username) {
		logMessage = "UserName : "+ username +",Class :'" + sourceClass + "',Method :'" + sourceMethod + "',Message :" + logMessage+System.getProperty("line.separator");
		agcsPluginLogger.info(logMessage);

	}

	public synchronized static void logWarning(String logMessage, String sourceClass, String sourceMethod, String username) {
		logMessage = "UserName : "+ username +",Class :'" + sourceClass + "',Method :'" + sourceMethod + "',Message :" + logMessage+System.getProperty("line.separator");
		agcsPluginLogger.warn(logMessage);

	}

	public synchronized static void logError(String logMessage, String sourceClass, String sourceMethod, String username) {
		logMessage = "UserName : "+ username +",Class :'" + sourceClass + "',Method :'" + sourceMethod + "',Message :" + logMessage+System.getProperty("line.separator");
		agcsPluginLogger.error(logMessage);
	}

	public synchronized static void logFatal(String logMessage, String sourceClass, String sourceMethod, String username) {
		logMessage = "UserName : "+ username +",Class :'" + sourceClass + "',Method :'" + sourceMethod + "',Message :" + logMessage+System.getProperty("line.separator");
		agcsPluginLogger.warn(logMessage);
	}

	public synchronized static void logException(Exception e, String sourceClass, String sourceMethod, String username) {

		logError("Exception -- " + e.getMessage(), sourceClass, sourceMethod, username);
		StackTraceElement[] elem = e.getStackTrace();
		int len = elem.length;
		String stackTrace = "Exception Details ---\n";
		for (int i = 0; i < len; i++) {
			stackTrace += "at " + elem[i].toString() + "\n";

		}
		logError(stackTrace, sourceClass, sourceMethod, username);

	}

	public static void changeLoggerIfAlreadyNotChanged(PluginServiceCallbacks callbacks, String requestType,
			String logLevel, String logFilePath) throws Exception {
		String finalLogFilePath = "";

		if (agcsPluginLogger == null) {
			finalLogFilePath = logFilePath;

			try {
				if (null != logFilePath && !logFilePath.equalsIgnoreCase("")) {

					changeLogFile(finalLogFilePath, logLevel);

				}
			} catch (Exception ex) {

				if (requestType != null && requestType.equalsIgnoreCase("config")) {
					throw new Exception("Log Filepath is null or incorrect.");
				}
				finalLogFilePath = "C:\\" + logFilePath;

				clearLogger();
				changeLogFile(finalLogFilePath, logLevel);
				ex.printStackTrace();

			}
		}
	}

}
