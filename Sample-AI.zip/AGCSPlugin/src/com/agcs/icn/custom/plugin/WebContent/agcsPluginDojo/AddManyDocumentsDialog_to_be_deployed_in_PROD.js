dojo.provide("agcsPluginDojo.AddManyDocumentsDialog");

dojo.require("ecm.widget.dialog.AddContentItemDialog");
dojo.require("ecm.widget.dialog.MessageDialog");

dojo.declare("agcsPluginDojo.AddManyDocumentsDialog",
		[ ecm.widget.dialog.AddContentItemDialog ], {

		_addMoreButton: null,
		_addMultipleInProgress: false,
		_onAddError: false,
		
		constructor: function() {
			this.inherited(arguments);
		},
		
		show: function(){
			console.debug("Entering::AddManyDocumentsDialog::show");
			var t=this;
			this.inherited(arguments);	
			console.debug("Exiting::show--",t,t.addContentItemPropertiesPane);
			
			/*if(t && t.addContentItemPropertiesPane && t.addContentItemPropertiesPane._commonProperties){
			var fieldsOfET=t.addContentItemPropertiesPane._commonProperties._propertyEditors._fields;
			console.log("fieldsOfET--",fieldsOfET);
			dojo.forEach(fieldsOfET, function(item, index){
				console.log("inside foreach showUsingTemplateItem--",this.addContentItemPropertiesPane._commonProperties._propertyEditors._fields[index]);
				t.addContentItemPropertiesPane._commonProperties._propertyEditors._fields[index].setValue("");
			});
			}*/
		},

		showUsingTemplateItem: function(){
			console.debug("Entering::AddManyDocumentsDialog::showUsingTemplateItem--",this);
			
			this.inherited(arguments);
			this._addMoreButton = this.addButton("Add & Attach More", "_onClickAddMore", true, true);	
			
		},
		
		postCreate: function() {
			console.debug("Entering::postCreate");
			
			this.inherited(arguments);
			try {
				
			} catch (e) {
				console.error(e);
			}
			
			console.debug("Exiting::postCreate");
		},
		
		addFolderInMemory: function(){
			console.debug("Entering::addFolderInMemory");
			this.inherited(arguments);
		},
		
		isValid: function() {
			console.debug("Entering::isValid");
	
			var isValid = this.inherited(arguments);
			console.debug("isValid="+isValid);
			this._addMoreButton.set("disabled", !isValid);
			return isValid;
			
			console.debug("Returning::isValid");
		},
		
		_onClickAddMore: function(){
			console.debug("Entering::_onClickAddMore");
			
			this._addMultipleInProgress = true;
			
			try{
				this.onAdd();
			}
			catch( exp){
				this._onAddError =true;
				console.error("AddManyDocumentsDialog:: Error adding document",e);
			}
			
			
			console.debug("Exiting::_onClickAddMore");
		},
		
		onAdd: function(){
			console.debug("Entering::onAdd");
			this.inherited(arguments);
			console.debug("Exiting::onAdd");
			
		},
		
		onCancel: function(){
			console.debug("Entering::AddManyDocumentsDialog::onCancel");
			if(!this._addMultipleInProgress)
				this.inherited(arguments);
			console.debug("Exiting::AddManyDocumentsDialog::onCancel");
		},
		
		hide: function(){
			console.debug("Entering::AddManyDocumentsDialog::hide");
			
			//If not a multi add, continue with the add
			if(!this._addMultipleInProgress)
				this.inherited(arguments);
			else{
			//Assume this was a successful multi-add
				try {
					//Clear the file
					this.addContentItemGeneralPane.getFileInputForm().reset();
					this.addContentItemGeneralPane.onFileInputChange();
					console.debug("DocumentTitle>>>>>",this);
					this.addContentItemPropertiesPane.setPropertyValue(this.addContentItemPropertiesPane.getTitlePropertyName(), '');
					var attrDefArray=this.addContentItemPropertiesPane._commonProperties.attributeDefinitions;
					var count = 0;
					require(["dojo/_base/array"], function(array){
						array.forEach(attrDefArray, function(attribute){
						      if(attrDefArray[count].id=="DDM_PolicyNumber"){
						    	  
						    	  attrDefArray[count].readOnly=true;
						      }
						      count++;
						});
					});
					
				} catch (e) {
					console.error("AddManyDocumentsDialog:: Error clearing file input form",e);
				}
				
				if(!this._onAddError)
				{
					//Display add success
					var messageDialog = new ecm.widget.dialog.MessageDialog({
						text: "Document was uploaded successfully"
					});
					messageDialog.show();
					this._onAddError=false;
				}
				this._addMultipleInProgress=false;
			}
			console.debug("Exiting::AddManyDocumentsDialog::hide");
		}
});