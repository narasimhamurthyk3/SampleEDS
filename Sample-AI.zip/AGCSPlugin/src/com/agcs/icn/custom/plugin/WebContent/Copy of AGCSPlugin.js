dojo.require("agcsPluginDojo.AddManyDocumentsDialog");

require(["dojo/_base/declare",

                 "dojo/_base/lang", "dojo/aspect", "ecm/widget/AddContentItemPropertiesPane",

                 "ecm/widget/listView/ContentList","ecm/widget/listView/gridModules/DndFromDesktopAddDoc",

                 "ecm/widget/AddContentItemGeneralPane","ecm/widget/dialog/AddContentItemDialog",

                 "ecm/widget/listView/gridModules/DndFromDesktop","dojo/_base/array","ecm/model/Request",
                 
                 "aRCNetPluginDojo/DNDMetaDataUpdateAction","ecm/widget/dialog/MessageDialog"], 

function(declare,lang,aspect,AddContentItemPropertiesPane,ContentList,DndFromDesktopAddDoc,
		 AddContentItemGeneralPane,AddContentItemDialog,DndFromDesktop,array,Request,
         DNDMetaDataUpdateAction,MessageDialog) {               

                var searchTemplateName,searchTemplateContentClass,dndRowGridObject;;
                var isDragNDrop="false",isMultipleDoc="false";
                var entryTemplateName,mainProps,entryTemplates,entryTemplateIndex;
                var repo,isInvokeService="false";
                
                lang.setObject("executeAddMany", function(repository, items, callback, teamspace, resultSet, parameterMap, context) {

                        console.debug("Entering::executeAddMany ::",this);
                        isDragNDrop="false";
                        console.debug("repository.getOpenedSearches",repository.getOpenedSearches());
                        console.debug("repository.openedSearches",repository.openedSearches);

                        var rootItem = repository.getOpenedSearches();

                        console.debug("rootItem ",rootItem );
                        var addManyDocsDlg = new agcsPluginDojo.AddManyDocumentsDialog();

                          try {

                                console.debug("Before show dialog",addManyDocsDlg);
                                console.log("Before show dialog"+repository.toString());
                            
                                      
                                	  var callback = lang.hitch(this, function(item){/*
                                		  
                                		  console.log("in Callback"+item);
                                		  console.log("Document Uploaded, parent is "+item.parent.id);
                        					var serviceParams = new Object();
                        				    serviceParams.repositoryID = item.repository.id;
                        				    serviceParams.serverType = item.repository.type;
                        				    serviceParams.parentID = item.parent.id;
                        				  	serviceParams.itemID = item.id;
                        				  	
                        				  	console.log("item.repository.id "+item.repository.id);
                        				  	console.log("item.repository.type "+item.repository.type);
                        				  	console.log("item.parent.id "+item.parent.id);
                        				  	console.log("item.id "+item.id);
                        					
                    					Request.invokePluginService("agcsplugin", "UpdateSecurityPolicy",

                                        {
                    									requestParams: serviceParams,
                                                       requestCompleteCallback: function(response) {    
                                                       if(response){                                                 	   
                                                    	   console.log("success");
                                                       }
                                                    }
                                                    })

                                	  */});

                                  

                               addManyDocsDlg.showUsingTemplateItem(repository, null, true, false, callback, null ,null );
                               console.debug("After show dialog");

                               } catch (e) {
                            	   console.error("Error showing add many dialog",e);
                               }

                               console.debug("Exiting::executeAddMany");

                });

                
                //aspect.around(SearchTab.prototype, "onLoad", lang.hitch(this,function(originalFunction){
                /*
                	 console.log("Inside Overridden Search onLoad");
                   // console.log(this._resultsDisplayButton.domNode);
                	 
                	 console.log("Entering getResultSet onLoad :",SearchTab);

                   
								//console.log(this._resultSet);
                             searchTemplateName=SearchTab.searchTemplate.name;
                             console.log("1SearchTab");
                             searchTemplateContentClass=SearchTab.searchTemplate._searchContentClass;
                             console.log("2SearchTab");
                             repo=SearchTab.searchTemplate.repository;
                             //console.debug("this in content list isInvokeService :",isInvokeService);
                             console.log("3SearchTab");
                             if(isInvokeService=="false"){
                             	var serviceParams = new Object;
                             	serviceParams.repositoryID= repo.id;
                             	console.log("4SearchTab"+repo.id);
                                 Request.invokePluginService("agcsplugin", "ReadConfigFileService",

                                  {

                                        requestParams: serviceParams,
                                        requestCompleteCallback: function(response) {    

                                        if(response){
                                     	   console.log("response SearchTab::",response);
                                     	   if(response.entryTemplates && response.mainProps && response.isInvokeService)

                                               {

                                                  isInvokeService=response.isInvokeService;
                                                  mainProps=response.mainProps;
                                                  entryTemplates=response.entryTemplates;
                                                  console.debug("entryTemplates SearchTab>>>>>>",entryTemplates);
                                                  console.debug("mainProps SearchTab>>>>>>",mainProps);
                                                  console.debug("isInvokeService SearchTab>>>>>>",isInvokeService);

                                                                             
                                               }

                                             }

                                     }

                                     })

                             

                     console.log("Exiting getResultSet SearchTab ");

                     //return this._resultSet;
                     }
                    // return this._resultSet;
             
                	 
                	 
                    *///}));
                /*

                * getResultSet method is called whenever the search results are populated

                */

                aspect.around(ContentList.prototype, "getResultSet", lang.hitch(this,function(originalFunction){

                        return function() {

                                console.log("Entering getResultSet :",this);

                                if(this && this._resultSet && this._resultSet.searchTemplate){
										console.log(this._resultSet);
                                        searchTemplateName=this._resultSet.searchTemplate.name;
                                        console.log("1");
                                        searchTemplateContentClass=this._resultSet.searchTemplate._searchContentClass;
                                        console.log("2");
                                        repo=this._resultSet.searchTemplate.repository;
                                        //console.debug("this in content list isInvokeService :",isInvokeService);
                                        console.log("3");
                                        if(isInvokeService=="false"){
                                        	var serviceParams = new Object;
                                        	serviceParams.repositoryID= repo.id;
                                        	console.log("4"+repo.id);
                                            Request.invokePluginService("agcsplugin", "ReadConfigFileService",

                                             {

                                                   requestParams: serviceParams,
                                                   requestCompleteCallback: function(response) {    

                                                   if(response){
                                                	   console.log("response ::",response);
                                                	   if(response.entryTemplates && response.mainProps && response.isInvokeService)

                                                          {

                                                             isInvokeService=response.isInvokeService;
                                                             mainProps=response.mainProps;
                                                             entryTemplates=response.entryTemplates;
                                                             console.debug("entryTemplates >>>>>>",entryTemplates);
                                                             console.debug("mainProps >>>>>>",mainProps);
                                                             console.debug("isInvokeService >>>>>>",isInvokeService);

                                                                                        
                                                          }

                                                        }

                                                }

                                                })

                                        }

                                console.log("Exiting getResultSet ");

                                //return this._resultSet;
                                }
                                return this._resultSet;
                        }
                }));
                
                /*//Disable multiple browsing of file
                aspect.around(AddContentItemGeneralPane.prototype, "_onBrowseForFile", lang.hitch(this,function(originalFunction){
                	console.log("Inside _onBrowseForFile");
                	//domAttr.remove(this._fileInput, "multiple");              	               
                }));*/

               /* aspect.around(AddContentItemDialog.prototype, "onAdd", lang.hitch(this,function(originalFunction){

                    return function() {

                            console.log("Entering onAdd :",this);
                            console.log("originalFunction onAdd :",originalFunction);
                            var lineOfBusiness=this.addContentItemPropertiesPane.getPropertyValue("DDM_Line_Of_Business");
                            var restrictedAccess=this.addContentItemPropertiesPane.getPropertyValue("Restricted_Access");
        					var className=this.addContentItemPropertiesPane._contentClass.name;
        					var serviceParams = new Object;
                        	serviceParams.repositoryID= this.addContentItemPropertiesPane._commonProperties.repository.id;
                        	serviceParams.LOB=lineOfBusiness;
                        	serviceParams.restrictedAccess=restrictedAccess;
        					Request.invokePluginService("agcsplugin", "UpdateSecurityPolicy",

                            {

                                           requestParams: serviceParams,
                                           requestCompleteCallback: function(response) {    

                                           if(response){
                                        	   
                                        	   console.log("success");
                                           }

                                        }

                                        })
        					
                           
                    }
            }));*/

                /*

                * This method is called when the ICN tries to open a add document dialog box on drag-n-drop of a document.

                * Here, depending upon the searchContentClass, the entry template is getting fetched.

                */

                aspect.around(DndFromDesktopAddDoc.prototype, "displayDialog", lang.hitch(this,function(originalFunction){

                        return function(files, targetItem, teamspace, defaultClass) {
                        		var tempThis=this;
                        		var repository = targetItem.repository ? targetItem.repository : targetItem;
                        		var openAction = new DNDMetaDataUpdateAction();
                        		/**

                                * ARCNET SPECIFIC CODE

                                */
                        		var items=this._getTargetItem(targetItem);
                        		console.log(this._getTargetItem(targetItem))
                                var parent = targetItem.parentFolder ? targetItem.parentFolder : targetItem.parent;
                        		//console.log(parent)
                                var itemPath=(items.attributes.PathName);
                                //console.log(parent.attributes.PathName)
                                console.log(itemPath)

 
                                if(undefined != itemPath){

                                	var substring="ARCNet";
                                	var index=itemPath.indexOf(substring);

                                	if(index>-1){

                                		console.log("ARCNet entity")
                                		openAction.performAction(repository, items, null, teamspace, null, null,files);

                                	}

 

                                	else{  
                                		
                                		var messageDialog=new MessageDialog({
                                			text: "Document cannot be Dragged and Dropped to this Location"
                                		});

                                		messageDialog.show();

                                	}

 

                                }else{

                                		var entryTemplateArray;
                                		console.debug("Entering displayDialog ::",tempThis);
                                		if(isMultipleDoc=="false"){

                                        /*console.log("isDragNDrop in displayDialog :: ",isDragNDrop);         

                                        console.log("inside displayDialog ::",tempThis);

                                        console.log("targetItem ::",targetItem);

                                        console.log("defaultClass ::",defaultClass);

                                        console.log("files ::",files);

                                        console.log("teamspace ::",teamspace);

                                        console.log("repository ::",repository);*/

                                        

                                        console.log("searchTemplateContentClass::",searchTemplateContentClass);
                                        console.log("itemPath::",itemPath);
                                        if(searchTemplateContentClass)
                                        	defaultClass=searchTemplateContentClass;

                                        if (tempThis.addContentItem)
                                        	tempThis.addContentItem.destroyRecursive();

                                        tempThis.addContentItem = new AddContentItemDialog();

                                        if (defaultClass) {
                                        	tempThis.addContentItem.setDefaultContentClass(defaultClass);
                                        }

                                        tempThis.addContentItem.setFiles(files);
                                        /*var tempCallback = lang.hitch(this, function(item){
                                        	console.log("tempCallback >>>"+item.toString());
                                        	
                                        });*/

                                        if(entryTemplates)
                                        	entryTemplateArray=entryTemplates.split(',');

                                        console.log("entryTemplateArray >>>",entryTemplateArray);

                                        

                                        var entryTemplateListRetrievedHandler = lang.hitch(this, function(entryTemplatesObj) {
                                        	var isEntryTemplateRetrieved=false;
                                            var entryTemplateRetrievedHandler = lang.hitch(this, function(entryTemplate) {
                                            	var tempCallback = lang.hitch(this, function(item){/*
                                                	console.log("tempCallback On DragDrop Add >>>"+item);
                                                	console.log("On Drag and Drop Document Uploaded, parent is "+item.parent.id);
                                  					var serviceParams = new Object();
                                  				    serviceParams.repositoryID = item.repository.id;
                                  				    serviceParams.serverType = item.repository.type;
                                  				    serviceParams.parentID = item.parent.id;
                                  				  	serviceParams.itemID = item.id;
                                  				  	
                                  				  	//console.log("item.repository.id "+item.repository.id);
                                  				  	//console.log("item.repository.type "+item.repository.type);
                                  				  	console.log("item.parent.id "+item.parent.id);
                                  				  	console.log("item.id "+item.id);
                                  					
                              					Request.invokePluginService("agcsplugin", "UpdateSecurityPolicy",

                                                  {

                                                                 requestParams: serviceParams,
                                                                 requestCompleteCallback: function(response) {    

                                                                 if(response){
                                                              	   
                                                              	   console.log("success");
                                                                 }

                                                              }

                                                              })

                                                	
                                                */});
                                             if(entryTemplate && entryTemplate.addClassName && 
                                            		 entryTemplate.addClassName==defaultClass.id && entryTemplate.folder){

    												 var parentFolderContentItem=entryTemplate.folder;
    												 isEntryTemplateRetrieved=true;
    												 entryTemplateName=entryTemplate.name;
    												 tempThis.addContentItem.show(repository, parentFolderContentItem, (entryTemplate.type == ecm.model.EntryTemplate.TYPE.DOCUMENT), false, tempCallback,teamspace, true, entryTemplate);
    												 return false;
                                             		}

                                            });
                                        	dojo.every(entryTemplatesObj, function(entryTemplate) {
																dojo.every(entryTemplateArray, function(et,index){
																	
																	if(entryTemplate.name==et){
																		entryTemplateIndex=index;
																		console.log("entryTemplateIndex >>",entryTemplateIndex);
																
																	if (!entryTemplate.isRetrieved) {
																				entryTemplate.retrieveEntryTemplate(entryTemplateRetrievedHandler, false, false);
																				console.debug("entry template was not retrieved >>",entryTemplate);
																}else{
																	
																	entryTemplateRetrievedHandler(entryTemplate);
																	console.debug("entry template was already retrieved >>",entryTemplate);

                                                                }
																}

                                                                return true;

                                                        });

                                                        if(isEntryTemplateRetrieved==true){
                                                        	console.log("isEntryTemplateRetrieved >>",isEntryTemplateRetrieved);
                                                        	return false;

                                                        }
                                                        return true;
                                        		});

                                           });

                                        repository.retrieveEntryTemplates(entryTemplateListRetrievedHandler,"Document",null,null,null);
                                        console.debug("Exiting displayDialog ");

                                }
                               }
                        }
                	}));

                aspect.around(AddContentItemDialog.prototype, "_onFileInputChange", lang.hitch(this,function(originalFunction){
            		return function() {

            			console.log("DDM FileInput Change");
            			if(this.parentFolder.attributes!=null && this.addContentItemPropertiesPane.getTitlePropertyName().length==0)
            				{
            			var FiledInFolder=this.parentFolder.attributes.PathName;
            			console.log(FiledInFolder);
            			
            				var fileName = this.addContentItemGeneralPane.getInputFileName();
            			
            				var titlePropertyName = this.addContentItemPropertiesPane.getTitlePropertyName();
            				//console.log("clearing DocumentTitle doc is filed in "+FiledInFolder);
            				if(FiledInFolder=="/Underwriting Documents" || FiledInFolder=="/Claim Documents")
            				fileName='';
            				console.log("FileName"+fileName);
            				this.addContentItemPropertiesPane.setPropertyValue(titlePropertyName, fileName);
            				console.log("Exit DDM file Input Change");
            				}
            		};
            	}));

                /*

        *"_getExternalDropTargetRow" method is used to fetch the row id, on which the user

        * has dropped the files. This is required to fetch all the fields corresponding that row document.  

         */

                aspect.around(DndFromDesktop.prototype, "_getExternalDropTargetRow", lang.hitch(this,function(originalFunction){
                	return function(evt) {
                		var t = this, g = t.grid;
                		var rowNode = t._getExternalDropTargetRowNode(evt);
                		console.debug("Entering _getExternalDropTargetRow ::",t);
                		isDragNDrop="true";
                		
                		if (rowNode) {

                             //console.log("g.row(rowNode.getAttribute('rowid'))---",g.row(rowNode.getAttribute('rowid')));
                			dndRowGridObject=g.row(rowNode.getAttribute('rowid'));
                			return g.row(rowNode.getAttribute('rowid'));

                        }

                        else{
                        	//console.log("dndRowGridObject in else null");
                        	dndRowGridObject=null;

                        }
                		console.debug("Exiting _getExternalDropTargetRow");
                		return null;

                }

        }));

        

        /*

        * onDrop method is called whenever the user drops some file(s) onto the search results

        * Customization is done in order to show an error message whenever the user drops multiple documents  

         */

                aspect.around(DndFromDesktopAddDoc.prototype, "onDrop", lang.hitch(this,function(originalFunction){
                	return function(row, files, evt) {
                			var t = this;
                			var rowItem = row ? row.item() : null;
                			console.debug("Entering onDrop ::",t);

                			if(files && files.length>1){

                					//console.log("files.length in onDrop ::",files.length);
                					isMultipleDoc="true";
                					var messageDialog = new ecm.widget.dialog.MessageDialog({
                						text: "Sorry! Cannot add multiple documents" // Message to be changed according to OBT requirement
                					});
                					messageDialog.show();
                					console.debug("Error message shown");

                                    if(t.addContentItem){
                                    	t.addContentItem.destroy();
                                    }
                			}

                else{
                		isMultipleDoc="false";
                		t._drop(t._getTargetItem(rowItem), files, evt);
                }
                }
                	console.debug("Exiting onDrop");

        }));

             

        /*

        * This method is called when the add document dialog fields are rendered.

        * Here we are setting all the fields values with respect to the fields of the document row on which the 

         * file has been dragged and dropped.

        */

             aspect.around(AddContentItemPropertiesPane.prototype, "onCompleteRendering", lang.hitch(this,function(originalFunction){
            	 return function() {
            		 	var t=this;
            		 	var arrayOfFields,mainPropsArray;
            		 	console.debug("Entering onCompleteRendering ::",t);
            		 	console.debug("mainProps in onCompleteRendering ::",mainProps);
						if(mainProps){

                                mainPropsArray=mainProps.split(';');
                                var entryTemplateProps=new Array(mainPropsArray.length);

                                for(var i=0;i<mainPropsArray.length;i++){
                                	entryTemplateProps[i]=mainPropsArray[i].split(',');
                                	console.debug("Entry Template Properties >>",entryTemplateProps);

                                }
                                if(isDragNDrop=="true"){        
                                	arrayOfFields=entryTemplateProps[entryTemplateIndex];
                                	console.debug("arrayOfFields >>",arrayOfFields);
                                	if(dndRowGridObject && dndRowGridObject.item()){
                                			gridRowContentItemObject=        dndRowGridObject.item();
                                			console.debug("gridRowObject item >>",gridRowContentItemObject);
                                			gridRowContentItemObject.retrieveAttributes(function(gridRowCallBack){
                                				console.log("gridRowCallBack >>",gridRowCallBack)
                                				
                                				if(t && t._commonProperties){
                                					dojo.forEach(arrayOfFields, function(item, index){
                                							if(item && gridRowCallBack.getValue(item)){
                                								if(gridRowCallBack.getAttributeType(item)=="xs:timestamp"){
                                									fieldValue = new Date(gridRowCallBack.getValue(item));
                                								}else{
                                									fieldValue = gridRowCallBack.getValue(item);
                                								}

                                                                t._commonProperties.setPropertyValue(item, fieldValue);
                                                                console.log("CommonProperties item >> ",item," value >>",fieldValue);

                                                                }
                                					})

                                                   }

                                                },null,false,function(error){console.debug("Error in RetrieveAttribute Service",error)});

                                }
                                }
						}

                       }

        }));

                

                

                

        

                

        });