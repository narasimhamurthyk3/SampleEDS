aspect.around(DndFromDesktopAddDoc.prototype, "displayDialog", lang.hitch(this,function(originalFunction){
                return function(files, targetItem, teamspace, defaultClass) {
                        var t = new AddContentItemDialog;
                        var repository = targetItem.repository ? targetItem.repository : targetItem;
                        var openAction = new DNDMetaDataUpdateAction();
                        console.log(targetItem.path)  ;
                        var items=this._getTargetItem(targetItem);
                        console.log(this._getTargetItem(targetItem))
                        var parent = targetItem.parentFolder ? targetItem.parentFolder : targetItem.parent;
                        //  console.log(parent)
                        var itemPath=(items.attributes.PathName);
                        //   console.log(parent.attributes.PathName)
                        console.log(itemPath)
                        if(undefined != itemPath){
                                var substring="ARCNet";
                        var index=itemPath.indexOf(substring);
                        if(index>-1){
                                console.log("ARCNet entity")
                                openAction.performAction(repository, items, null,                                                teamspace, null, null,files);
                        }

                        else{  
                        	var messageDialog=new MessageDialog({
                        		text: "Document cannot be Dragged and Dropped to this Location"

                                        });

                                        messageDialog.show();

                        }

                        

                }   

                        else{

                        var t = new AddContentItemDialog;

        

        if (defaultClass) {

              t.setDefaultContentClass(defaultClass);

        }

        

    

        t.setFiles(files);

        var repository = targetItem.repository ? targetItem.repository : targetItem;

        //var titlePropertyName = t.addContentItemPropertiesPane.getTitlePropertyName();

        //t.addContentItemPropertiesPane.setPropertyValue(titlePropertyName, "Test123");

        //t.addContentItemPropertiesPane.setPropertyValue("Policy_ref", "Test123232");

        t.show(repository, targetItem, true, false, null, teamspace, true, null);

 

                        //  t.setFiles(files);

                        // var repository = targetItem.repository ? targetItem.repository : targetItem;

                        //var titlePropertyName = t.addContentItemPropertiesPane.getTitlePropertyName();

                        //t.addContentItemPropertiesPane.setPropertyValue(titlePropertyName, "Test123");

                        //t.addContentItemPropertiesPane.setPropertyValue("Policy_ref", "Test123232");

                        //  t.show(repository, targetItem, true, false, callbackfromUpload, null, true, null);

                

                        }};

        }));

