dojo.require("agcsPluginDojo.AddManyDocumentsDialog");

require(["dojo/_base/declare",
         "dojo/dom-class",
         "dojo/dom-style",
         "dojo/dom-attr",
         "dojo/_base/lang",
         "dojo/aspect",
         "ecm/widget/AddContentItemPropertiesPane",
         "ecm/widget/listView/ContentList",
         "ecm/widget/listView/gridModules/DndFromDesktopAddDoc",
         "ecm/widget/AddContentItemGeneralPane",
         "ecm/widget/dialog/AddContentItemDialog",
         "ecm/widget/listView/gridModules/DndFromDesktop",
         "dojo/_base/array",
         "ecm/model/Request",
         "aRCNetPluginDojo/DNDMetaDataUpdateAction",
         "ecm/widget/dialog/MessageDialog",
         "ecm/widget/search/SearchTab",
         "ecm/widget/search/SearchForm",
         "ecm/widget/search/SearchTabController",
         "ecm/model/_searchUtils",
         "ecm/widget/PropertyEditors",
         "ecm/widget/dialog/ShowHyperlinkDialog",
         "ecm/widget/dialog/BaseDialog",
         "agcsPluginDojo/AddManyDocumentsDialog"
         ], 

         function(declare,
        		 domClass,
        		 domStyle,
        		 domAttr,
        		 lang,
        		 aspect,
        		 AddContentItemPropertiesPane,
        		 ContentList,
        		 DndFromDesktopAddDoc,
        		 AddContentItemGeneralPane,
        		 AddContentItemDialog,
        		 DndFromDesktop,
        		 array,
        		 Request,
        		 DNDMetaDataUpdateAction,
        		 MessageDialog,
        		 SearchTab,
        		 SearchForm,
        		 SearchTabController,
        		 utils,
        		 PropertyEditors,
        		 ShowHyperlinkDialog,
        		 BaseDialog,
        		 AddManyDocumentsDialog
         ) {   

	/*
                Global Variable
	 */

	var searchTemplateName;
	var searchTemplateContentClass; 
	var dndRowGridObject;
	var isDragNDrop="false";
	var isMultipleDoc="false";
	var entryTemplateName,mainProps,entryTemplates,entryTemplateIndex;
	var repo,isInvokeService="false",addMultipleInProgress=false,addMoreButton,onAddError;
	var readOnlyPropUW;
	var readOnlyPropClaim;
	lang.extend(AddContentItemDialog, {
                
		onClickAddMoreDND: function(){
	           
	            
	            addMultipleInProgress = true;
	            
	            try{
	            	this.onAdd();
	            }
	            catch( exp){
	            	this.onAddError = true;
	            	
	            }
	            	            
	           
            }
    });

	lang.setObject("executeAddMany", function(repository, items, callback, teamspace, resultSet, parameterMap, context) {

		
		isDragNDrop="false";
		
		var rootItem = repository.getOpenedSearches();
		
		var addManyDocsDlg = new agcsPluginDojo.AddManyDocumentsDialog();
		try {
			
			var callback = lang.hitch(this, function(item){});                                 
			addManyDocsDlg.showUsingTemplateItem(repository, null, true, false, callback, null ,null );
			

		} catch (e) {
			console.error("Error showing add many dialog",e);
		}

		

	});


	/*
                Handle things post get search results NOT USED
	 */

	/*aspect.around(SearchForm.prototype, "_enableSearch", lang.hitch(this,function(originalFunction){

										return function() {

										}
								}));*/


	/*
								aspect.around(SearchForm.prototype, "onSearchCriteriaLoad", lang.hitch(this,function(originalFunction){

										return function() {

											console.debug("On Search onSearchCriteriaLoad");
											//this._moreOptions.fileTypeOptionHidden=true;

										}
								}));*/

	/*
								aspect.around(SearchTabController, "onClick", lang.hitch(this,function(originalFunction){

										return function() {

											console.debug("On Search Tab Button Click");

										}
								}));*/


	/**
	 *Code to remove version buttons from showhyperlink as well as Text in the Dialog to remove version references
	 *NOT REQUIRED as per Katie -- 07/09/2016 19:15CET
	 */
	/*	
								aspect.after(ShowHyperlinkDialog.prototype,"show",function(originalFunction){
									console.log("Entering After ShowHyperlinkDialog::show");
									if(ecm.model.desktop.name=="DDM"){

										//console.log("ShowHyperlinkDialog::show", this.introText.innerHTML);
										//console.log("ShowHyperlinkDialog::show", this._showHyperlink._showHyperlinkShowOptions);
										domStyle.set(this._showHyperlink._showHyperlinkShowOptions, "display", "none");
										var introText=this.introText.innerHTML;
										var introTextNoVersion=introText.split(".");
										this.introText.innerHTML = introTextNoVersion[0]+".";

									}
									console.log("Exiting After ShowHyperlinkDialog::show");							
								});
	 */
	//allow search on adding atleast one criterion
	aspect.around(SearchTab.prototype, "_meetsMinimumCriteria", lang.hitch(this,function(originalFunction){
		return function(minCriteriaMet, criteria) {
			minCriteriaMet=false;
			criteria = this.searchTemplate.searchCriteria;
			//minCriteriaMet=originalFunction(this);
			console.debug("On _meetsMinimumCriteria");
			if (this.repository._isP8()) {
				var hasTextCriteria = this.searchForm.isTextSearchCriteriaDefined();
				var hasAttribCriteria = array.some(criteria, function(criterion) {
					return utils.meetsMinimumCriteria(criterion);
				});
				minCriteriaMet = hasTextCriteria || hasAttribCriteria;
			}else { // subclass selected
				minCriteriaMet = true;
			}

			if (!minCriteriaMet)
				this._showMessage(this.messages.search_insufficient_input);
			return minCriteriaMet;
		}
	}));

	aspect.around(SearchTab.prototype, "onLoad", lang.hitch(this,function(originalFunction){

		return function() {

			console.log("Inside Overridden Search onLoad");

			/**Below code will modify search tab and disables hyperlink available on search page for - Search In, More Options, Property Options and Result Display Button
			 *
			 */

			domClass.add(this._propertyOptions._optionsLink.domNode,"idxDropDownLinkDisabled dijitDisabled");   //Disables PropertyOPtions HyperLink
			domClass.add(this._propertyOptions._optionsDialog.domNode, "dijitHidden"); //Hides Property Options from SearchTab
			//domClass.add(this._propertyOptions.domNode, "dijitHidden");//Hides Property Options from SearchTab
			domClass.add(this._resultsDisplayButton.domNode, "dijitHidden"); ////Hides Display Options Button
			// Disabled all Moreoptions as per latest req. Below line can be commented
			//domClass.add(this._moreOptions._fileTypeOptionNode, "dijitHidden"); //Hides File Type Filter from search Options
			domClass.add(this._moreOptions._optionsLink.domNode, "idxDropDownLinkDisabled dijitDisabled");//Disables More OPtions HyperLink
			domClass.add(this._moreOptions._optionsDialog.domNode, "dijitHidden"); //Hides More OPtions Options from SearchTab



			domClass.add(this._searchIn._optionsLink.domNode, "idxDropDownLinkDisabled dijitDisabled");//Disables SearchIn HyperLink
			domClass.add(this._searchIn._optionsDialog.domNode, "dijitHidden"); //Hides SearchIn Options from SearchTab

			/**
												Code Module to read properties from config file, these properties will be used by DnD		                		
			 */

			searchTemplateName=this.searchTemplate.name;
			
			searchTemplateContentClass=this.searchTemplate._searchContentClass;
			
			repo=this.searchTemplate.repository;
			
			if(isInvokeService=="false"){
				var serviceParams = new Object;
				serviceParams.repositoryID= repo.id;
				serviceParams.userID= this.searchTemplate.repository.userId;
				Request.invokePluginService("agcsplugin", "ReadConfigFileService",
						{
					requestParams: serviceParams,
					requestCompleteCallback: function(response) {    
						if(response){
							console.log("response SearchTab::",response);
							if(response.entryTemplates && response.mainProps && response.isInvokeService){
								isInvokeService=response.isInvokeService;
								mainProps=response.mainProps;
								entryTemplates=response.entryTemplates;
								readOnlyPropUW=response.readOnlyPropUW;
								readOnlyPropClaim=response.readOnlyPropClaim;
								
							}

						}

					}

						})
						


			}
			this._loaded = true;             
		} 

	}));


	/** Read Configurations moved from  ContentList.prototype, "getResultSet" to other aspect.around, currently on  ;; SearchTab.prototype, "onLoad", reverted back
	 */

	aspect.around(ContentList.prototype, "getResultSet", lang.hitch(this,function(originalFunction){

		return function() {

			

			if(this && this._resultSet && this._resultSet.searchTemplate){
				
				searchTemplateName=this._resultSet.searchTemplate.name;
				
				searchTemplateContentClass=this._resultSet.searchTemplate._searchContentClass;
				
			}
			return this._resultSet;
		}
	}));

	/*

	 * This method is called when the ICN tries to open a add document dialog box on drag-n-drop of a document.

	 * Here, depending upon the searchContentClass, the entry template is getting fetched.

	 */

	aspect.around(DndFromDesktopAddDoc.prototype, "displayDialog", lang.hitch(this,function(originalFunction){

		return function(files, targetItem, teamspace, defaultClass) {
			var tempThis=this;
			var repository = targetItem.repository ? targetItem.repository : targetItem;
			var openAction = new DNDMetaDataUpdateAction();
			/**

			 * ARCNET SPECIFIC CODE

			 */
			 var items=this._getTargetItem(targetItem);
			 
			 var parent = targetItem.parentFolder ? targetItem.parentFolder : targetItem.parent;
			
			 var itemPath=(items.attributes.PathName);
			 
			
			 if(undefined != itemPath){
				 var substring="ARCNet";
				 var index=itemPath.indexOf(substring);
				 if(index>-1){
					
					 openAction.performAction(repository, items, null, teamspace, null, null,files);

				 }
				 else{  
					 var messageDialog=new MessageDialog({
						 text: "Document cannot be Dragged and Dropped to this Location"
					 });
					 messageDialog.show();
				 }
			 }else{	
				 var entryTemplateArray;
				 
				 if(isMultipleDoc=="false"){

					
					 if(searchTemplateContentClass)
						 defaultClass=searchTemplateContentClass;

					 if (tempThis.addContentItem)
						 tempThis.addContentItem.destroyRecursive();

					tempThis.addContentItem = new AddContentItemDialog();
					//addMultipleInProgress=true;
                                        try{
                                        	addMoreButton=tempThis.addContentItem.addButton("Add & Attach More", "onClickAddMoreDND", true, true);
                                        
                                        }catch(exp){
                                        	onAddError=true;
                                        }

					 if (defaultClass) {
						 tempThis.addContentItem.setDefaultContentClass(defaultClass);
					 }

					 tempThis.addContentItem.setFiles(files);

		                             		 if(entryTemplates)
		                             			 entryTemplateArray=entryTemplates.split(',');

		                             		 

		                             		 var entryTemplateListRetrievedHandler = lang.hitch(this, function(entryTemplatesObj) {
		                             			 var isEntryTemplateRetrieved=false;
		                             			 var entryTemplateRetrievedHandler = lang.hitch(this, function(entryTemplate) {
		                             				 var tempCallback = lang.hitch(this, function(item){});
		                             				 if(entryTemplate && entryTemplate.addClassName && entryTemplate.addClassName==defaultClass.id && entryTemplate.folder)
		                             				 {

		                             					 var parentFolderContentItem=entryTemplate.folder;
		                             					 isEntryTemplateRetrieved=true;
		                             					 entryTemplateName=entryTemplate.name;
		                             					 tempThis.addContentItem.show(repository, parentFolderContentItem, (entryTemplate.type == ecm.model.EntryTemplate.TYPE.DOCUMENT), false, tempCallback,teamspace, true, entryTemplate);
		                             					 return false;
		                             				 }

		                             			 });
		                             			 dojo.every(entryTemplatesObj, function(entryTemplate) {
		                             				 dojo.every(entryTemplateArray, function(et,index){
		                             					 if(entryTemplate.name==et){
		                             						 entryTemplateIndex=index;
		                             						 
		                             						 if (!entryTemplate.isRetrieved) {
		                             							 entryTemplate.retrieveEntryTemplate(entryTemplateRetrievedHandler, false, false);
		                             							
		                             							 if(searchTemplateName=="Claim Search" || searchTemplateName=="Claim Engineering Search"){
		                             							 entryTemplateIndex=0;
		                             							 }				
		                             						 }else{

		                             							 entryTemplateRetrievedHandler(entryTemplate);
		                             							 

		                             						 }
		                             					 }
		                             					 return true;

		                             				 });

		                             				 if(isEntryTemplateRetrieved==true){
		                             					 
		                             					 return false;

		                             				 }
		                             				 return true;
		                             			 });

		                             		 });

		                             		 repository.retrieveEntryTemplates(entryTemplateListRetrievedHandler,"Document",null,null,null);
		                             		 

				 }
			 }
		}
	}));


	/*

	 *"_getExternalDropTargetRow" method is used to fetch the row id, on which the user

	 * has dropped the files. This is required to fetch all the fields corresponding that row document.  

	 */

	aspect.around(DndFromDesktop.prototype, "_getExternalDropTargetRow", lang.hitch(this,function(originalFunction){
		return function(evt) {
			var t = this, g = t.grid;
			var rowNode = t._getExternalDropTargetRowNode(evt);
			
			isDragNDrop="true";

			if (rowNode) {
				dndRowGridObject=g.row(rowNode.getAttribute('rowid'));
				return g.row(rowNode.getAttribute('rowid'));

			}

			else{
				dndRowGridObject=null;

			}
		
			return null;

		}

	}));



	/*

	 * onDrop method is called whenever the user drops some file(s) onto the search results

	 * Customization is done in order to show an error message whenever the user drops multiple documents  

	 */

	aspect.around(DndFromDesktopAddDoc.prototype, "onDrop", lang.hitch(this,function(originalFunction){
		return function(row, files, evt) {
			var t = this;
			var rowItem = row ? row.item() : null;
			

			if(files && files.length>1){

				
				isMultipleDoc="true";
				var messageDialog = new ecm.widget.dialog.MessageDialog({
					text: "Sorry! Cannot add multiple documents" // Message to be changed according to OBT requirement
				});
				messageDialog.show();
				

				if(t.addContentItem){
					t.addContentItem.destroy();
				}
			}

			else{
				isMultipleDoc="false";
				t._drop(t._getTargetItem(rowItem), files, evt);
			}
		}
		

	}));

	
	           
    AddContentItemDialog.extend({
	    onCancel: function() {
		   
		    if(!addMultipleInProgress)
		    	this.inherited(arguments);
		    
	    }
    })
                
    AddContentItemDialog.extend({
    
    	hide: function() {
    		
                
    		if(!addMultipleInProgress){
    			this.inherited(arguments);
    			
            }
            else{
                
	            try{
	            
	                this.addContentItemGeneralPane.getFileInputForm().reset();
	                var file;
	                this.addContentItemGeneralPane._externalFiles=file;
	                if(this.addContentItemGeneralPane._externalFileNamesDiv){
	                	domStyle.set(this.addContentItemGeneralPane._externalFileNamesDiv, "display", "none");
	                
	                }
	    
				    if (this.addContentItemGeneralPane._fileInputArea) {
				    
					    domAttr.set(this.addContentItemGeneralPane._fileInput, "multiple", "multiple");
					   
					    
					    domStyle.set(this.addContentItemGeneralPane._fileInputArea, "display", "");
				    }
	    
				    this.addContentItemGeneralPane.onFileInputChange();
	    
				    this.addContentItemPropertiesPane.setPropertyValue(this.addContentItemPropertiesPane.getTitlePropertyName(), '');
				    console.debug("CommonProp",this.addContentItemPropertiesPane._commonProperties);
					//this.addContentItemPropertiesPane._commonProperties._controller.collections.Properties.propertyControllers.PolicyNumber.set("readOnly",true);
					var readOnlyProp = null;
					
					
					if(this.addContentItemPropertiesPane._contentClass.id=="Underwriting_Document"){
						readOnlyProp=readOnlyPropUW;
					}
					if(this.addContentItemPropertiesPane._contentClass.id=="Claim_Document"){
						readOnlyProp=readOnlyPropClaim;
					}
					console.debug("readOnlyPropUW",readOnlyPropUW);
					console.debug("readOnlyPropClaim",readOnlyPropClaim);
					console.debug("readOnlyProp",readOnlyProp);
					var prop = readOnlyProp.split(",");
					
					var attrDefinitions=this.addContentItemPropertiesPane._commonProperties._controller.collections.Properties.propertyControllers;
					
					for(var i=0;i<prop.length;i++){
						
						attrDefinitions[prop[i]].set("readOnly",true);	
					}
				    
	            }
	            catch (e) {
	            	console.error("AddManyDocumentsDialog:: Error clearing file input form",e);
	            }
	            this.isValid();
	            if(!onAddError)
	            {
	                //Display add success
	            	var messageDialog = new ecm.widget.dialog.MessageDialog({
	            	text: "Document was uploaded successfully"
	            	});
	            	messageDialog.show();
	            	onAddError=false;
	            }
	           
    
	            addMultipleInProgress=false;
    
	            
                
           }
                
      }
    })
                


	 aspect.around(AddContentItemDialog.prototype, "isValid", lang.hitch(this,function(originalFunction){
		 
                return function(onSaveStatus) {
                
	               
	        
	                var generalValid = this.addContentItemGeneralPane.isValid();
	
	
		        	// Returns null if all entries are valid, otherwise returns the first invalid field widget.
		        	var propertiesValid = !this.addContentItemPropertiesPane.validate(this._checkin, onSaveStatus);
		        	var isValid=generalValid && propertiesValid;
		        	
		        	//var isValid = originalFunction(onSaveStatus);
		        	if(addMoreButton)
		        		addMoreButton.set("disabled", !isValid);
		        	// Both panes must be in a valid state.
		        	return isValid;
        
        	}
        }));

	/*

	 * This method is called when the add document dialog fields are rendered.

	 * Here we are setting all the fields values with respect to the fields of the document row on which the 

	 * file has been dragged and dropped.

	 */

	aspect.around(AddContentItemPropertiesPane.prototype, "onCompleteRendering", lang.hitch(this,function(originalFunction){
		return function() {
			var t=this;
			var arrayOfFields,mainPropsArray;
			

			
			var attrDefArray=t._commonProperties.attributeDefinitions;



			if(mainProps){
				mainPropsArray=mainProps.split(';');
				var entryTemplateProps=new Array(mainPropsArray.length);

				for(var i=0;i<mainPropsArray.length;i++){
					entryTemplateProps[i]=mainPropsArray[i].split(',');
					

				}
				if(isDragNDrop=="true"){        
				arrayOfFields=entryTemplateProps[entryTemplateIndex];
				
				if(dndRowGridObject && dndRowGridObject.item()){
					gridRowContentItemObject=        dndRowGridObject.item();
					
					gridRowContentItemObject.retrieveAttributes(function(gridRowCallBack){
						
						if(t && t._commonProperties){

							dojo.forEach(arrayOfFields, function(item, index){
								if(item && gridRowCallBack.getValue(item)){
									if(gridRowCallBack.getAttributeType(item)=="xs:timestamp"){
										fieldValue = new Date(gridRowCallBack.getValue(item));
									}else{                               									
										fieldValue = gridRowCallBack.getValue(item);
									}
									t._commonProperties.setPropertyValue(item, fieldValue);
									
									


								}
							})

						}

					},null,false,function(error){console.debug("Error in RetrieveAttribute Service",error)});

				}	
				}
			}

		}

	}));
});
