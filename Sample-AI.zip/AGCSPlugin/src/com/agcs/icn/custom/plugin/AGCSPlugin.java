package com.agcs.icn.custom.plugin;

import java.util.Locale;

import com.ibm.ecm.extension.Plugin;
import com.ibm.ecm.extension.PluginAction;
import com.ibm.ecm.extension.PluginFeature;
import com.ibm.ecm.extension.PluginLayout;
import com.ibm.ecm.extension.PluginMenu;
import com.ibm.ecm.extension.PluginMenuType;
import com.ibm.ecm.extension.PluginODAuthenticationService;
import com.ibm.ecm.extension.PluginRequestFilter;
import com.ibm.ecm.extension.PluginResponseFilter;
import com.ibm.ecm.extension.PluginViewerDef;

public class AGCSPlugin extends Plugin {

	@Override
	public String getId() {
		return "agcsplugin";
	}

	@Override
	public String getName(Locale arg0) {
		return "AGCSPlugin";
	}

	@Override
	public String getVersion() {
		return "1.0";
	}

	@Override
	public String getScript() {
		return "AGCSPlugin.js";
	}

	@Override
	public String getDojoModule() {
		return "agcsPluginDojo";
	}

	@Override
	public PluginAction[] getActions() {
		return new PluginAction[] {

				new AGCSAddManyDocumentsAction()

		};
	}

	/**
	 * Provides a list of services that are provided by this plug-in. The
	 * services run on the web server, and can be called by the web browser
	 * logic component of the plug-in.
	 * 
	 * @return An array of {@link com.ibm.ecm.extension.PluginService
	 *         PluginService} objects. The plug-in should return the same set of
	 *         objects on every call. If there are no services defined by the
	 *         plug-in, the call should return an empty array.
	 */
	public com.ibm.ecm.extension.PluginService[] getServices() {
		return new com.ibm.ecm.extension.PluginService[] { new com.agcs.icn.custom.plugin.ReadConfigFileService(),
				};
	}

	/**
	 * Provides a list of filters that are run before a requested service. This
	 * method can be used to modify the request or block the request.
	 * 
	 * @return An array of <code>
	 *         {@link com.ibm.ecm.extension.PluginRequestFilter PluginRequestFilter}</code>
	 *         objects.
	 */
	public PluginRequestFilter[] getRequestFilters() {
		return new PluginRequestFilter[0];
	}

	/**
	 * Provides a list of filters that are run after a requested service. This
	 * list of filters can be used to modify the response that is returned.
	 * 
	 * @return An array of <code>
	 *         {@link com.ibm.ecm.extension.PluginResponseFilter PluginResponseFilter}</code>
	 *         objects.
	 */
	public PluginResponseFilter[] getResponseFilters() {
		return new PluginResponseFilter[0];
	}

	/**
	 * Provides a custom service used for Content Manager OnDemand single
	 * sign-on (SSO). This is an optional service that will be called when SSO
	 * is enabled on a Content Manager OnDemand server. The result of the
	 * service will be the information passed through the Content Manager
	 * OnDemand Web Enablement Kit "passThru" API.
	 * 
	 * @since 2.0.2
	 * @return A {@link com.ibm.ecm.extension.PluginODAuthenticationService
	 *         PluginODAuthenticationService} object used as an authentication
	 *         exit for Content Manager OnDemand single sign-on.
	 */
	public PluginODAuthenticationService getODAuthenticationService() {
		return null;
	}

	/**
	 * Returns the name of a Dojo <code>dijit</code> class that provides a
	 * configuration interface widget for this plug-in. The widget must extend
	 * the <code>ecm.widget.admin.PluginConfigurationPane</code> widget. An
	 * instance of the widget is created and displayed in the IBM Content
	 * Navigator administration tool for configuration that is specific to the
	 * plug-in.
	 * <p>
	 * Refer to the documentation on
	 * {@link ecm.widget.admin.PluginConfigurationPane PluginConfigurationPane}
	 * for more information on what is required for a plug-in configuration user
	 * interface.
	 * </p>
	 */
	public String getConfigurationDijitClass() {
		return "agcsPluginDojo.ConfigurationPane";
	}

	/**
	 * Provides a list of viewers that are provided by this plug-in. The viewers
	 * become available in the viewer configuration area of the IBM Content
	 * Navigator administration tool. The viewers can be mapped to be used to
	 * view certain document types.
	 * <p>
	 * <strong>Note:</strong> Typically, a plug-in does not define multiple
	 * viewers. However, this method can be used to provide multiple
	 * configurations of the same viewer, such as a view-only version and an
	 * editing mode version of the same viewer.
	 * </p>
	 * 
	 * @return An array of {@link ecm.widget.admin.PluginViewerDef
	 *         PluginViewerDef} objects describing the viewers provided by the
	 *         plug-in.
	 */
	public PluginViewerDef[] getViewers() {
		return new PluginViewerDef[0];
	}

	/**
	 * Specifies one or more custom layouts that are provided by this plug-in.
	 * Custom layouts can display the features and other user interface
	 * components of IBM Content Navigator in a different arrangement. The IBM
	 * Content Navigator administration tool is used to select the layout to use
	 * for a desktop.
	 * 
	 * @return An array of plug-in layout objects.
	 */
	public PluginLayout[] getLayouts() {
		return new PluginLayout[0];
	}

	/**
	 * Specifies custom features that are provided by this plug-in. Features are
	 * the major user interface sections, which appear as icons on the left side
	 * of the user interface in the default layout. Examples of features include
	 * Search, Favorites, and Teamspaces.
	 * 
	 * @return An array of custom plug-in feature objects.
	 */
	public PluginFeature[] getFeatures() {
		return new PluginFeature[0];
	}

	/**
	 * Provides a list of new menu types defined by the plug-in.
	 * 
	 * @return An array of new menu type objects.
	 */
	public PluginMenuType[] getMenuTypes() {
		return new PluginMenuType[0];
	}

	/**
	 * Provides a list of menus defined by the plug-in.
	 * 
	 * @return An array of plug-in menu objects.
	 */
	public PluginMenu[] getMenus() {
		return new PluginMenu[0];
	}

}
