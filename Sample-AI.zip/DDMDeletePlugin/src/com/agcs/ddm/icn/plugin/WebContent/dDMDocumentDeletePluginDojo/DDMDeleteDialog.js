define([
"dojo/_base/declare",
	"ecm/MessagesMixin",
	"ecm/widget/dialog/BaseDialog",
	"ecm/model/Desktop",
	"ecm/model/Repository",
	"ecm/widget/TextBox",
	"ecm/widget/DatePicker",
	"dijit/form/FilteringSelect",
	"dojo/store/Memory",
	"ecm/widget/dialog/StatusDialog",
	"ecm/widget/dialog/MessageDialog",
	"dojo/text!./templates/DDMDeleteDialog.html",
], function(declare,MessagesMixin,BaseDialog,Desktop,Repository,TextBox,DatePicker,FilteringSelect,Memory,StatusDialog,MessageDialog,template) {
	return declare("dDMDocumentDeletePluginDojo/DDMDeleteDialog", [
	    BaseDialog
	     ], {
		widgetsInTemplate: true,
		contentString: template,
		_lookupKey: null,
		_targetPolicySubmissionNumber: null,
		_grid: null,
		_deleteButton: null,
		_documentClass: null,
		_sourcebtt: null,
		_filteringSelect : null,
		_items: null,
		_repository: null,
		
		_isValidatedBySource:true,
		_statusDlg: null,
		_workingDlg: null,
		policyNumber:null,
		submissionNumber:null,
		policyInceptionDate:null,
		businessTransactionType:null,
		insuredName:null,
		claimDocument:null,
		underwriting:null,
		claimNumber:null,
		claimantName:null,
		_refreshed : false,
		_deletionReason: null,
		postCreate: function() {
			
			this.inherited(arguments);
			
			//Could not find a better way to show and set the status dialog message 
			this._statusDlg = StatusDialog();
			this._statusDlg.contentNode.innerHTML="Deleting...";
			this._statusDlg.showActionBar(false);
			
			this._workingDlg = StatusDialog();
			this._workingDlg.contentNode.innerHTML="Working...";
			this._workingDlg.showActionBar(false);
			
		},
		
		show: function(repository, items, response) {
			
			var deleteChoices = new Array();
			var stringValue = response.DeletionReasonChoiceList;
			deleteChoices = stringValue.split(',');
			
			this._repository = repository;
			this._items = items;
			
			this._deleteButton = this.addButton("Delete", "_onClickDelete", true, true);
			this.setTitle("Delete Document");
			var mydata = [];
			
			for(var i in deleteChoices)
			{
				var thisDeleteReason = deleteChoices[i];
				mydata.push({ name: thisDeleteReason,
					id: thisDeleteReason
				});
			}
			
			var stateStore = new Memory({
		        data: mydata
		    });
			var parent=this;
			this._targetDocumentDelete = new FilteringSelect({
		        id: this.id+"_ddmDelete",
		        name: "DDM Delete",
		        value: "",
		        style: "width: 200px;",
		        store: stateStore,
		        searchAttr: "name",
		        onChange: function (){
		        	

					if(this.item!=null && this.isValid())
					{
						_filteringSelect=this;
						parent._deletionReason=this.item.name;
						if(parent._deleteButton!=null)
							parent._deleteButton.set("disabled",false);
					}
					else{
						if(parent._deleteButton!=null)
							parent._deleteButton.set("disabled",true);
					}
						
		        	
		        }
			
		    }, this.id+"_ddmDelete").startup();
			
			
					
			
			this.inherited("show", []);
		},
		
		_onClickDelete: function(e) {
			var deleteDocsPayload = new Object();
			var docGuids = new Array();
			var updateProps=new Object();
			var contentType= "application/json";
			var params = new Object();
			
			//Check if the copy button is enabled
			if(this._deleteButton.get("disabled")){
				return false;	
			}
			
			updateProps.properties=[];
			
			params.repositoryId = this._repository.id;
			params.os =this._repository.name;
			params.userID =this._repository.userId;
			params.type = this._repository.type;
			params.server =this._repository.id;
			params.serverType =this._repository.type;
			params.ndocs = this._items.length;
			for (var i in this._items) {
				docGuids.push(this._items[i].id);
			}

			var targetProps = new Array();
			
			var DeletionReason = new Object();
			DeletionReason.property = "Deletion_Reason";
			console.debug("this._deletionReason : >>",this._deletionReason);
			DeletionReason.value = this._deletionReason;
			
			targetProps.push(DeletionReason);
			
			var DeletionDate = new Object();
			DeletionDate.property = "Deletion_Date";
			DeletionDate.value = new Date();
			
			targetProps.push(DeletionDate);
			
			

			var targetPropsNode = new Object();
			targetPropsNode.properties = targetProps;
			
			var sourcePropsNode = new Object();
			sourcePropsNode.properties = new Array();
			
			deleteDocsPayload.guids =  docGuids;
			deleteDocsPayload.deletionReason = this._deletionReason;
			deleteDocsPayload.target = targetPropsNode;
 			
 			
			var displayDeleteStatusFn = dojo.hitch(this,"_displayDeleteStatus");
			var postParams = new Object();
			postParams.requestParams = params;
			postParams.requestBody = dojo.toJson(deleteDocsPayload);
			postParams.requestCompleteCallback = displayDeleteStatusFn;
			postParams.requestFailedCallback = dojo.hitch(this,function(response) {
													console.debug("Error",response);
													this.setMessage("Error Occured:" + response,"error");
													this._statusDlg.hide();
													}
												);
			
			ecm.model.Request.postPluginService(
					"DDMDocumentDeletePlugin",
					"DDMDeleteService",
					contentType,
					postParams			
			);

			
			this._statusDlg.show();
			
		},
		

		
		_displayDeleteStatus: function(retPayload){

			this._statusDlg.hide();
			
			
			if(retPayload.exception!=null){
				this.setMessage("Error Occured: " + retPayload.exception,"error");
				return;
			}
			
			var deleteStatus = "Document deleted successfully.";
			
				
			this.setMessage(deleteStatus,"info");
			
		    this._deleteButton.set("disabled",true);
		    
		    _filteringSelect.disabled=true;
		    
		    
		}
});
});