define(["dojo/_base/declare",
        "ecm/model/Request",
        "ecm/model/Action",
        "ecm/model/Desktop",
        "dojo/_base/lang",
        "ecm/widget/dialog/MessageDialog",
       "dDMDocumentDeletePluginDojo/DDMDeleteDialog"
        ],
        function(declare,Request,Action,Desktop,lang,MessageDialog,DeleteDocumentsDialog) {
	return declare("dDMDocumentDeletePluginDojo/DDMDeleteActionModel", [ Action ], {
		isEnabled: function(repository, listType, items, workspace,resultSet) {
			
			if(items.length>1)
				return false;
			
			var enabled = false;
			
			for (var i in items) {
				
				var docClassName = items[i].getContentClass().id;
				
				if(items[i].hasPrivilege( "privEditProperties")|| items[0].hasPrivilege("privEditDoc"))					
					enabled = true;				
				else
					{
					enabled = false;break;
					}
				if(docClassName=="Underwriting_Document" || docClassName=="Claim_Document"){
					
					if(items[i].attributes.Deletion_Reason==null){
						
						enabled = true;
						
						break;
					}
					else
						enabled = false;
				}
				
			}
			
			return enabled;
		},
		
		isVisible: function(repository, items) {
			
			return true;
		},
		
		performAction: function(repository, items, callback,
				teamspace, resultSet, parameterMap) {
			
					

			if(items[0].locked){
				var messageDialog = new MessageDialog();
		   		messageDialog.description.innerHTML ="Document is checked out by "+items[0].lockedUser+ ". It cannot be deleted.";
		        messageDialog.show();
			}
			else{
			
			var serviceParams = new Object();
			serviceParams.repositoryID = items[0].repository.id;
			serviceParams.objectStoreID = items[0].objectStore.id;
			serviceParams.userID = items[0].repository.userId;
			
			
			// this is asynchronous request.  Using asynch is preferred although slightly more complicated to code
			Request.invokePluginService("DDMDocumentDeletePlugin", "ReadConfigFileService",
				{
					requestParams: serviceParams,
					requestCompleteCallback: function(response) {	// success
						
						if(response && response.isInvokeService=="true")
						{
							
							var deleteDocsDlg = new DeleteDocumentsDialog();
							deleteDocsDlg.show(repository, items, response);
											
							
						}
						
					}
				}
			
			);
			}
		
			
		  	


   		  	
   		  	
		}
	});
});
/**

 * 
 */