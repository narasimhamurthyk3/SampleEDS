package com.agcs.ddm.icn.plugin;

import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;

import java.util.Date;
import java.util.Iterator;
import java.util.StringTokenizer;

import javax.security.auth.Subject;

import com.filenet.api.collection.ReferentialContainmentRelationshipSet;
import com.filenet.api.constants.AutoUniqueName;
import com.filenet.api.constants.DefineSecurityParentage;
import com.filenet.api.constants.PropertyNames;
import com.filenet.api.constants.RefreshMode;
import com.filenet.api.core.Document;
import com.filenet.api.core.Domain;
import com.filenet.api.core.Factory;
import com.filenet.api.core.Folder;
import com.filenet.api.core.ObjectStore;
import com.filenet.api.core.ReferentialContainmentRelationship;
import com.filenet.api.events.CustomEvent;
import com.filenet.api.exception.EngineRuntimeException;
import com.filenet.api.property.FilterElement;
import com.filenet.api.property.Properties;
import com.filenet.api.property.PropertyFilter;
import com.filenet.api.util.Id;
import com.filenet.api.util.UserContext;
import com.ibm.ecm.extension.PluginServiceCallbacks;

public class P8Operations {

	public static void readConfigurationsFromCE(ObjectStore objectStore, String userID) throws Exception {

		java.util.Properties propFromCE = new java.util.Properties();
		InputStream proprStream = null;

		try {

			PropertyFilter pf = new PropertyFilter();
			pf.addIncludeProperty(new FilterElement(null, null, null, PropertyNames.CONTENT_ELEMENTS, null));
			Document propDoc = Factory.Document.fetchInstance(objectStore, "/Config/DDMOperations.properties", null);
			proprStream = propDoc.accessContentStream(0);
			propFromCE.load(proprStream);
			String logFilePath = propFromCE.getProperty("DeletePluginLogFilePath");
			String logLevel = propFromCE.getProperty("LogLevel");
			if (logFilePath != null && !logFilePath.equals("")) {

				DeletePluginLogger.changeLoggerIfAlreadyNotChanged("config", logLevel, logFilePath);
			}

		} catch (IOException ioe) {
			DeletePluginLogger.logException(ioe, "P8Operations",
					"readConfigurationsFromCE", userID);
			
		} catch (EngineRuntimeException ex) {
			DeletePluginLogger.logException(ex, "P8Operations",
					"readConfigurationsFromCE", userID);
		}

		Configuration.prop_policyNumber = propFromCE.getProperty("DDM_Policy_Number");
		Configuration.prop_submissionNumber = propFromCE.getProperty("DDM_Submission_Number");
		Configuration.prop_insuredName = propFromCE.getProperty("DDM_Insured_Name");
		Configuration.prop_policyInceptionDate = propFromCE.getProperty("DDM_Policy_Inception_Date");
		Configuration.prop_businessTransactionType = propFromCE.getProperty("DDM_Business_Transaction_Type");
		Configuration.prop_claimNumber = propFromCE.getProperty("DDM_Claim_Number");
		Configuration.prop_claimantName = propFromCE.getProperty("DDM_Claimant_Name");
		Configuration.prop_claimSuffixNumber = propFromCE.getProperty("DDM_Claim_Suffix_Number");
		Configuration.prop_documentCategory = propFromCE.getProperty("DDM_Document_Category");
		Configuration.prop_documentSubCategory = propFromCE.getProperty("DDM_Document_Sub_Category");
		Configuration.prop_claim_documentCategory = propFromCE.getProperty("DDM_Claim_Document_Category");
		Configuration.prop_claim_documentSubCategory = propFromCE.getProperty("DDM_Claim_Document_Sub_Category");
		Configuration.prop_documentTitle = propFromCE.getProperty("DDM_Document_Title");
		Configuration.prop_linkedPolicies = propFromCE.getProperty("DDM_Linked_Policies");
		Configuration.prop_linkedSubmissions = propFromCE.getProperty("DDM_Linked_Submissions");
		Configuration.prop_linkedClaims = propFromCE.getProperty("DDM_Linked_Claims");
		Configuration.prop_documentSubCategory = propFromCE.getProperty("DDM_Document_Sub_Category");
		Configuration.class_claimDocument = propFromCE.getProperty("DDM_Claim_Document_Class");
		Configuration.class_underwriting = propFromCE.getProperty("DDM_Underwriting_Class");
		Configuration.folderPath_Claims = propFromCE.getProperty("DDM_FolderPath_Claims");
		Configuration.folderPath_Underwriting = propFromCE.getProperty("DDM_FolderPath_Underwriting");
		Configuration.recycleBin_folderPath_Claims = propFromCE.getProperty("DDM_RecycleBin_FolderPath_Claims");
		Configuration.recycleBin_folderPath_Underwriting = propFromCE
				.getProperty("DDM_RecycleBin_FolderPath_Underwriting");
		Configuration.prop_deletionReason = propFromCE.getProperty("DDM_Deletion_Reason");
		Configuration.prop_deletionDate = propFromCE.getProperty("DDM_Deletion_Date");
		Configuration.prop_audit_action_flag = propFromCE.getProperty("DDM_Audit_Action_Flag");
		Configuration.prop_action_Performed = propFromCE.getProperty("DDM_Action_Performed");
		Configuration.delete_event_name = propFromCE.getProperty("DDM_Deletion_Event_Name");
		Configuration.restore_event_name = propFromCE.getProperty("DDM_Restore_Event_Name");
		Configuration.delete_event_flag = propFromCE.getProperty("DDM_Deletion_Event_Flag");
		Configuration.restore_event_flag = propFromCE.getProperty("DDM_Restore_Event_Flag");
		Configuration.choiceList_DeletionReason = propFromCE.getProperty("DDM_Deletion_Reason_ChoiceList");

	}

	public static void restorDDMDocument(PrintWriter responseWriter, PluginServiceCallbacks callbacks,
			String repositoryId, String docId,String userID) {
		try {

			Domain domain = callbacks.getP8Domain(repositoryId, null);
			Subject subject = callbacks.getP8Subject(repositoryId);
			UserContext.get().pushSubject(subject);

			// A P8 docId in Content Navigator is actually three id's separated
			// by commas.
			StringTokenizer docIdTok = new StringTokenizer(docId, ",");
			String classID = (docIdTok.hasMoreTokens() ? docIdTok.nextToken() : null);
			DeletePluginLogger.logDebug("classID :" + classID, "P8Operations", "restorDDMDocument",
					userID);
			String objectStoreID = (docIdTok.hasMoreTokens() ? docIdTok.nextToken() : null);
			String objectID = (docIdTok.hasMoreTokens() ? docIdTok.nextToken() : null);
			// Retrieve the document
			ObjectStore os = Factory.ObjectStore.fetchInstance(domain, new Id(objectStoreID), null);

			String folderPath = null;

			Document document = Factory.Document.fetchInstance(os, objectID, null);

			String docClass = document.getClassName().toString();
			DeletePluginLogger.logDebug("DocumentClass :" + docClass, "P8Operations", "restorDDMDocument",
					userID);
			if (docClass.equalsIgnoreCase(Configuration.class_underwriting))
				folderPath = Configuration.folderPath_Underwriting;
			if (docClass.equalsIgnoreCase(Configuration.class_claimDocument))
				folderPath = Configuration.folderPath_Claims;
			Folder deletedDocumentDDM = Factory.Folder.fetchInstance(os, folderPath, null);
			DeletePluginLogger.logDebug("Restore folder Path :" + folderPath, "P8Operations", "restorDDMDocument",
					userID);

			DeletePluginLogger.logDebug("Unfile the document :" + document.get_Id(), "P8Operations",
					"restorDDMDocument", userID);
			unfileDocument(document, null);
			DeletePluginLogger.logInfo("Document is Unfiled from the folder", "P8Operations", "restorDDMDocument",
					userID);

			ReferentialContainmentRelationship recyclebinRCR = deletedDocumentDDM.file(document,
					AutoUniqueName.AUTO_UNIQUE, document.get_Name(),
					DefineSecurityParentage.DO_NOT_DEFINE_SECURITY_PARENTAGE);
			recyclebinRCR.set_Tail(deletedDocumentDDM);
			recyclebinRCR.set_Head(document);
			recyclebinRCR.save(RefreshMode.NO_REFRESH);
			recyclebinRCR.refresh();

			DeletePluginLogger.logDebug("Restored back to folder -" + deletedDocumentDDM.get_FolderName(),
					"P8Operations", "restorDDMDocument", userID);
			DeletePluginLogger.logDebug("Raise Event -" + Configuration.restore_event_name, "P8Operations",
					"restorDDMDocument", userID);
			raiseEvent(objectID, os, Configuration.restore_event_name, Configuration.restore_event_flag);
			DeletePluginLogger.logInfo("Restore Event raised successfully ", "P8Operations", "restorDDMDocument",
					userID);
			UserContext.get().popSubject();

			responseWriter.print("}");
		} catch (EngineRuntimeException e) {

			DeletePluginLogger.logException(e, "P8Operations", "restorDDMDocument", userID);
			responseWriter.print("}");
		}
	}

	public static void deleteDDMDocument(PrintWriter responseWriter, PluginServiceCallbacks callbacks,
			String repositoryId, String docId, String deletionReason,String userID) throws Exception {
		try {

			Domain domain = callbacks.getP8Domain(repositoryId, null);
			Subject subject = callbacks.getP8Subject(repositoryId);
			UserContext.get().pushSubject(subject);

			// A P8 docId in Content Navigator is actually three id's separated
			// by commas.
			StringTokenizer docIdTok = new StringTokenizer(docId, ",");
			String classID = (docIdTok.hasMoreTokens() ? docIdTok.nextToken() : null);
			String objectStoreID = (docIdTok.hasMoreTokens() ? docIdTok.nextToken() : null);
			String objectID = (docIdTok.hasMoreTokens() ? docIdTok.nextToken() : null);
			
			DeletePluginLogger.logDebug("docIdTok -" + docIdTok,
					"P8Operations", "deleteDDMDocument", userID);
			DeletePluginLogger.logDebug("classID -" + classID,
					"P8Operations", "deleteDDMDocument", userID);
			DeletePluginLogger.logDebug("objectStoreID -" + objectStoreID,
					"P8Operations", "deleteDDMDocument", userID);
			DeletePluginLogger.logDebug("objectID -" + objectID,
					"P8Operations", "deleteDDMDocument", userID);
			
			ObjectStore os = Factory.ObjectStore.fetchInstance(domain, new Id(objectStoreID), null);

			String folderPath = null;

			Document document = Factory.Document.fetchInstance(os, objectID, null);

			String docClass = document.getClassName().toString();
			DeletePluginLogger.logDebug("DocumentClass :" + docClass, "P8Operations", "deleteDDMDocument",
					userID);
			if (docClass.equalsIgnoreCase(Configuration.class_underwriting))
				folderPath = Configuration.recycleBin_folderPath_Underwriting;
			if (docClass.equalsIgnoreCase(Configuration.class_claimDocument))
				folderPath = Configuration.recycleBin_folderPath_Claims;
			Folder deletedDocumentDDM = Factory.Folder.fetchInstance(os, folderPath, null);
			DeletePluginLogger.logDebug("Delete folder Path :" + folderPath, "P8Operations", "deleteDDMDocument",
					userID);

			DeletePluginLogger.logDebug("Unfile the document :" + document.get_Id(), "P8Operations",
					"deleteDDMDocument", userID);

			unfileDocument(document, deletionReason);
			DeletePluginLogger.logDebug("Deletion Reason : " + deletionReason, "P8Operations", "deleteDDMDocument",
					userID);
			DeletePluginLogger.logInfo("Document is Unfiled from the folder", "P8Operations", "deleteDDMDocument",
					userID);

			ReferentialContainmentRelationship recyclebinRCR = deletedDocumentDDM.file(document,
					AutoUniqueName.AUTO_UNIQUE, document.get_Name(),
					DefineSecurityParentage.DO_NOT_DEFINE_SECURITY_PARENTAGE);
			recyclebinRCR.set_Tail(deletedDocumentDDM);
			recyclebinRCR.set_Head(document);
			recyclebinRCR.save(RefreshMode.REFRESH);
			recyclebinRCR.refresh();

			DeletePluginLogger.logDebug(
					"File the document to Recyclebin folder -" + deletedDocumentDDM.get_FolderName(), "P8Operations",
					"deleteDDMDocument", userID);
			DeletePluginLogger.logDebug("Raise Event -" + Configuration.delete_event_name, "P8Operations",
					"deleteDDMDocument", userID);

			raiseEvent(objectID, os, Configuration.delete_event_name, Configuration.delete_event_flag);

			DeletePluginLogger.logDebug("Delete Event raised successfully", "P8Operations", "deleteDDMDocument",
					userID);

			UserContext.get().popSubject();

			responseWriter.print("}");
		} catch (EngineRuntimeException e) {
			DeletePluginLogger.logException(e, "P8Operations", "deleteDDMDocument", userID);
			responseWriter.print("}");
		}
	}

	private static void unfileDocument(Document objectDoc, String deletionReason) {

		ReferentialContainmentRelationshipSet existingRcs = objectDoc.get_Containers();
		if (!existingRcs.isEmpty()) {
			Iterator<?> iterRcrT = existingRcs.iterator();
			while (iterRcrT.hasNext()) {

				ReferentialContainmentRelationship rcrNow = (ReferentialContainmentRelationship) iterRcrT.next();

				rcrNow.delete();
				rcrNow.save(RefreshMode.NO_REFRESH);
				Properties prop = objectDoc.getProperties();
				prop.putValue(Configuration.prop_deletionReason, deletionReason);
				if (deletionReason != null)
					prop.putValue(Configuration.prop_deletionDate, new Date());
				else
					prop.putObjectValue(Configuration.prop_deletionDate, null);
				objectDoc.save(RefreshMode.NO_REFRESH);
				break;
			}
		}
	}

	private static void raiseEvent(String objectID, ObjectStore os, String eventName, String eventflag) {

		CustomEvent custEvent = Factory.CustomEvent.createInstance(os, eventName);
		Document doc = Factory.Document.fetchInstance(os, objectID, null);
		Properties prop = doc.getProperties();
		prop.putValue(Configuration.prop_audit_action_flag, eventflag);
		prop.putValue(Configuration.prop_action_Performed, eventflag);
		doc.raiseEvent(custEvent);
		doc.save(RefreshMode.REFRESH);
		doc.refresh();
		prop = doc.getProperties();
		prop.putValue(Configuration.prop_audit_action_flag, "Metadata Update");
		doc.save(RefreshMode.NO_REFRESH);

	}

}
