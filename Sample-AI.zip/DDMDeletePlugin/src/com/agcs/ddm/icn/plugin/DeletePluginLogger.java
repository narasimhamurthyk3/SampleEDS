/**
 * 
 */
package com.agcs.ddm.icn.plugin;

import java.io.File;
import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.apache.log4j.PatternLayout;
import org.apache.log4j.RollingFileAppender;

/**
 * @author
 *
 */
public class DeletePluginLogger {

	private static Logger deletePluginLogger = null;

	public static void clearLogger() {
		if (deletePluginLogger != null) {
			deletePluginLogger.removeAllAppenders();
		}

		deletePluginLogger = null;
	}

	private static void changeLogFile(String logFilePath, String logLevel) throws Exception {
		try {

			if (deletePluginLogger != null) {
				return;
			}

			deletePluginLogger = Logger.getLogger(DeletePluginLogger.class);

			if (!logFilePath.toLowerCase().endsWith(".log") && !logFilePath.toLowerCase().endsWith(".txt")) {
				logFilePath += ".log";

			}

			File file = new File(logFilePath);

			if (!file.exists()) {
				String parentDirPath = file.getParent();
				if (parentDirPath != null) {
					File parentDir = new File(parentDirPath);
					if (!parentDir.exists()) {
						throw new Exception(String.format("Invalid File path '%s' - The directory '%s' does not exists",
								logFilePath, parentDir));
					}
				} else {
					throw new Exception(String.format("Invalid File path '%s'", logFilePath));
				}
				file.createNewFile();
			}

			deletePluginLogger.setLevel(Level.toLevel(logLevel.toUpperCase()));
			
			PatternLayout layout = new PatternLayout();
			layout.setConversionPattern("%-5d{yyyy-MM-dd HH:mm:ss} %-6p    -  %m%n");
			
			RollingFileAppender rollingFileAppender =  new RollingFileAppender(layout, file.getAbsolutePath());
			rollingFileAppender.setName("deletePluginAppender");
			rollingFileAppender.setMaxFileSize("2MB");
			rollingFileAppender.setMaxBackupIndex(3);
			
			deletePluginLogger.addAppender(rollingFileAppender);
			

		}

		catch (Exception e) {

			throw e;

		}
	}

	public synchronized static void logDebug(String logMessage, String sourceClass, String sourceMethod, String username) {

		logMessage = "Username :'" + username + "',Class :'" + sourceClass + "',Method :'" + sourceMethod + "',Message :" + logMessage+System.getProperty("line.separator");
		deletePluginLogger.debug(logMessage);

	}

	public synchronized static void logInfo(String logMessage, String sourceClass, String sourceMethod, String username) {
		logMessage = "Username :'" + username + "',Class :'" + sourceClass + "',Method :'" + sourceMethod + "',Message :" + logMessage+System.getProperty("line.separator");
		deletePluginLogger.info(logMessage);

	}

	public synchronized static void logWarning(String logMessage, String sourceClass, String sourceMethod, String username) {
		logMessage = "Username :'" + username + "',Username :'" + username + "',Class :'" + sourceClass + "',Method :'" + sourceMethod + "',Message :" + logMessage+System.getProperty("line.separator");
		deletePluginLogger.warn(logMessage);

	}

	public synchronized static void logError(String logMessage, String sourceClass, String sourceMethod, String username) {
		logMessage = "Username :'" + username + "',Class :'" + sourceClass + "',Method :'" + sourceMethod + "',Message :" + logMessage+System.getProperty("line.separator");
		deletePluginLogger.error(logMessage);
	}

	public synchronized static void logFatal(String logMessage, String sourceClass, String sourceMethod, String username) {
		logMessage = "Username :'" + username + "',Class :'" + sourceClass + "',Method :'" + sourceMethod + "',Message :" + logMessage+System.getProperty("line.separator");
		deletePluginLogger.warn(logMessage);
	}

	public synchronized static void logException(Exception e, String sourceClass, String sourceMethod, String username) {

		logError("Exception -- " + e.getMessage(), sourceClass, sourceMethod, username);
		StackTraceElement[] elem = e.getStackTrace();
		int len = elem.length;
		String stackTrace = "Exception Details ---\n";
		for (int i = 0; i < len; i++) {
			stackTrace += "at " + elem[i].toString() + "\n";

		}
		logError(stackTrace, sourceClass, sourceMethod, username);

	}

	public static void changeLoggerIfAlreadyNotChanged(String requestType,
			String logLevel, String logFilePath) throws Exception {
		String finalLogFilePath = "";

		if (deletePluginLogger == null) {
			finalLogFilePath = logFilePath;

			try {
				if (null != logFilePath && !logFilePath.equalsIgnoreCase("")) {

					changeLogFile(finalLogFilePath, logLevel);

				}
			} catch (Exception ex) {

				if (requestType != null && requestType.equalsIgnoreCase("config")) {
					throw new Exception("Log Filepath is null or incorrect.");
				}
				finalLogFilePath = "C:\\" + logFilePath;

				clearLogger();
				changeLogFile(finalLogFilePath, logLevel);
				ex.printStackTrace();

			}
		}
	}

}
