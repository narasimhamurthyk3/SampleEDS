define(["dojo/_base/declare",
        "ecm/model/Request",
        "ecm/model/Action",
        "ecm/model/Desktop",
        "dojo/_base/lang",
        "ecm/widget/dialog/MessageDialog",
        "ecm/widget/dialog/ConfirmationDialog",
       "dDMDocumentDeletePluginDojo/DDMDeleteDialog"
        ],
        function(declare,Request,Action,Desktop,lang,MessageDialog,ConfirmationDialog,DeleteDocumentsDialog) {
	return declare("dDMDocumentDeletePluginDojo/DDMRestoreActionModel", [ Action ], {
		isEnabled: function(repository, listType, items, workspace,resultSet) {
			if(items.length>1)
				return false;
			var enabled = false;
			for (var i in items) {
				
				var docClassName = items[i].getContentClass().id;
				if(items[i].hasPrivilege( "privEditProperties")|| items[0].hasPrivilege("privEditDoc"))					
					enabled = true;				
				else
					{
					enabled = false;break;
					}
				if(docClassName=="Underwriting_Document" || docClassName=="Claim_Document"){
					
					if(items[i].attributes.Deletion_Reason!=null){
						enabled = true;
						break;
					}
					else
						enabled = false;
				}
			}
			return enabled;
		},
		
		isVisible: function(repository, listType) {
			
			return true;
		},
		
		performAction: function(repository, items, callback,
				teamspace, resultSet, parameterMap) {
			
			if(items[0].locked){
				var messageDialog = new MessageDialog();
		   		messageDialog.description.innerHTML ="Document is checked out by "+items[0].lockedUser+ ". It cannot be restored.";
		        messageDialog.show();
			}
			else{
			var confirmationDialog = new ConfirmationDialog({
				buttonLabel : "Confirm",
				onExecute : function(){
					var docGuids = new Array();
					var serviceParams = new Object();
					serviceParams.repositoryID = items[0].repository.id;
					serviceParams.osName = items[0].objectStore.symbolicName;
					serviceParams.userID= items[0].repository.userId;
					serviceParams.ndocs = items.length;
					for (var i in items) {
						serviceParams["docId"+i] = items[i].id;
					
					}
					serviceParams.guids = docGuids;
					Request.invokePluginService("DDMDocumentDeletePlugin", "DDMRestoreService",
							{
								requestParams: serviceParams,
								requestCompleteCallback: function(response) {	// success
									
									if(response)
									{
										var messageDialog = new MessageDialog();
								   		messageDialog.description.innerHTML ="Document Restored Successfully";
								        messageDialog.show();
														
									}
									
								}
							}
						);
				}
			
			});
			
			confirmationDialog.setTitle("Restore Document");
			confirmationDialog.description.innerHTML ="Are you sure you want to restore the document?";
			confirmationDialog.show();
			}
   		  	
		}
	});
});
/**

 * 
 */