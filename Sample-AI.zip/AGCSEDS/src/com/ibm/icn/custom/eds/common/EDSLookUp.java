package com.ibm.icn.custom.eds.common;

import java.util.HashMap;

import com.ibm.json.java.JSONArray;

public abstract class EDSLookUp {
	public abstract HashMap<Integer, HashMap<String, String>> lookupData(String requestUser ,
			String[] propNames,String[] propValues,String[] propOrigValues, 
			JSONArray reqProps,String[] lookupAttrName) throws Exception;
}
