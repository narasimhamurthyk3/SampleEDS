/**
 * @author Philip
 *
 */
package com.ibm.icn.custom.eds.impl;

import java.util.HashMap;

import org.apache.log4j.Logger;

import com.ibm.icn.custom.eds.common.EDSProperties;
import com.ibm.icn.custom.eds.common.EDSValidator;
import com.ibm.json.java.JSONObject;

/**
 * @author Philip
 *
 */
public class ValidationImpl extends EDSValidator {

	Logger logger = null;
	/**
	 * 
	 */
	public ValidationImpl() {
		logger= Logger.getLogger(ValidationImpl.class.getName());
	}
	
	/* (non-Javadoc)
	 * @see com.ibm.icn.custom.eds.common.EDSValidator#clearCaches()
	 */
	@Override
	public boolean clearCaches() throws Exception {
		return false;
	}

	/* (non-Javadoc)
	 * @see com.ibm.icn.custom.eds.common.EDSValidator#getValidationStatus(java.lang.String, java.util.HashMap)
	 */
	@Override
	public String getValidationStatus(String propertyName,
			HashMap<String, String> matchedListKeyValPairs,String validationMessageKey) throws Exception {
		logger.debug("Entering validation for " + propertyName);
		String errorMessage="";

		if(EDSProperties.edsProperties.get(validationMessageKey)!=null)
			errorMessage = (String)EDSProperties.edsProperties.get(validationMessageKey);
		else
			errorMessage = "Validaiton failed for "+ propertyName;
		
		logger.debug("Validation returned " + errorMessage);
		return errorMessage;
	}

}
