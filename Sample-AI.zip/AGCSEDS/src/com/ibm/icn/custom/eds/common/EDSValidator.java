package com.ibm.icn.custom.eds.common;

import java.util.HashMap;

import com.ibm.json.java.JSONObject;

public abstract class EDSValidator {

	public abstract String getValidationStatus(String propertyName,HashMap<String, String> matchedListKeyValPairs,String invalidMessageKey) throws Exception ;
	public abstract boolean clearCaches() throws Exception ;
	
}
