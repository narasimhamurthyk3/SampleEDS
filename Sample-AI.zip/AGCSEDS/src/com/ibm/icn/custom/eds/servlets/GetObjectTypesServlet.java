package com.ibm.icn.custom.eds.servlets;


import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.ibm.json.java.JSONArray;

/**
 * Servlet implementation class GetObjectTypesServlet
 */
public class GetObjectTypesServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public GetObjectTypesServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String repositoryId = request.getParameter("repositoryId");

		String strConfigFile = "WEB-INF" + File.separator
				+ "config" + File.separator + "ObjectTypes.json";

		System.out.println("Trying to get "+strConfigFile);
		InputStream objectTypesStream = this.getClass().getClassLoader().getResourceAsStream(strConfigFile);
		JSONArray jsonResponse = JSONArray.parse(objectTypesStream);
		PrintWriter writer = response.getWriter();
		jsonResponse.serialize(writer);
	}


}
