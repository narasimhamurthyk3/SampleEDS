package com.ibm.icn.custom.eds.common;

public enum EDSOverrideTypes {

	CHOICELIST,
	DEFAULTVALUE,
	LOOKUP,
	LOOKUP_LIMITOR,
	REQUIRED,
	NOTREQUIRED,
	READONLY,
	HIDDEN,
	FORMATTER,
	VALIDATOR
}

