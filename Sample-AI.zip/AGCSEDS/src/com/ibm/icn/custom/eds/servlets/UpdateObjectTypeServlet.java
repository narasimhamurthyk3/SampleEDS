package com.ibm.icn.custom.eds.servlets;


import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.Locale;
import java.util.Properties;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.ibm.icn.custom.eds.common.EDSAttributes;
import com.ibm.icn.custom.eds.common.EDSChoiceList;
import com.ibm.icn.custom.eds.common.EDSEvaluator;
import com.ibm.icn.custom.eds.common.EDSException;
import com.ibm.icn.custom.eds.common.EDSLookUp;
import com.ibm.icn.custom.eds.common.EDSOverrideTypes;
import com.ibm.icn.custom.eds.common.EDSOverrideValues;
import com.ibm.icn.custom.eds.common.EDSProperties;
import com.ibm.icn.custom.eds.providers.LDAPSearch;
import com.ibm.json.java.JSONArray;
import com.ibm.json.java.JSONObject;


/**
 * Servlet implementation class UpdateObjectTypeServlet
 */
public class UpdateObjectTypeServlet extends HttpServlet {
	private Logger logger;
	private static final long serialVersionUID = 1L;
	private HashMap<String, HashMap<Integer, HashMap<String, String>>> populatedResultSets=null;       
	
	public void init() throws ServletException {
		super.init();
		System.out.println("UpdateObjectTypeServlet::init()");
		try {
			EDSProperties.init(getClass());
		} catch (Exception e) {
			e.printStackTrace();
			throw new ServletException(e.getMessage());
		}
	
		logger=Logger.getLogger(UpdateObjectTypeServlet.class.getName());
		
	}
	
	/*
	 * This is how the JSON coming in is structured. 

		POST /type/<object type name>
		
		{
			"repositoryId":"<target repository>",
			"objectId" : "<if an existing instance, the GUID, PID, etc>",
			"requestMode" : "<indicates context that info is being requested>",
			"externalDataIdentifier" : "<opaque identifier meaningful to service">,
			"properties":
			[
				{
					"symbolicName" : "<symbolic_name>", 
					"value" : <The current value>,
				}
				// More properties ...
			],
			"clientContext":
			{
				"userid":"<user id>",
				"locale":"<browser locale>",
				"desktop": "<desktop id>"
			}
		}
	 *
	 * The requestMode has values:
	 *  initialNewObject -- when a new object is being created (when add doc, create folder, checkin dialogs first appear)
	 *  initialExistingObject -- when an existing object is being edited (when edit properties first appears)
	 *  inProgressChanges -- when an object is being modified (for dependent choice lists)
	 *  finalNewObject -- before the object is persisted (when action is performed on add doc, create folder, checkin)
	 *  finalExistingObject -- before the existing object is persisted (when save action is performed on edit properties)
	 */

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		
		logger.debug("Entering doPost");
		logger.debug("request.getInputStream().available()::"+request.getInputStream().available());
		JSONObject edsErrObject = null;
		JSONArray requestProperties = new JSONArray();
		JSONArray responseProperties = new JSONArray();
		JSONArray origReqProperties =null;
		JSONArray extDataIdProperties =new JSONArray();
		JSONArray jsonRespROFields=null;
		boolean isSearchTemplate=false;
		String incomingRequestMode =null;
		String reqUserId="";
		
	
			
		try{
				String objectType = request.getPathInfo().substring(1);
				InputStream requestInputStream = request.getInputStream();
				JSONObject jsonRequest = JSONObject.parse(requestInputStream);
				String requestMode = jsonRequest.get(EDSAttributes.ATTR_REQUESTMODE).toString();
				incomingRequestMode=requestMode;
				
				if(jsonRequest.containsKey(EDSAttributes.ATTR_CLIENTCONTEXT)){
					JSONObject cliCtxt= (JSONObject)jsonRequest.get(EDSAttributes.ATTR_CLIENTCONTEXT);
					reqUserId=(String)cliCtxt.get(EDSAttributes.ATTR_USERID);
					logger.debug("EDS Request by "+ reqUserId);
				}
				
				requestProperties = (JSONArray)jsonRequest.get(EDSAttributes.ATTR_PROPERTIES);
				responseProperties = new JSONArray();
				isSearchTemplate= checkForStoredSearch(objectType,requestMode,requestProperties);
				
				//If this is a search template
				if(isSearchTemplate)
					objectType=objectType+"_Search";
				
				logger.debug("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
				logger.debug("INCOMING REQUEST PROPERTIES");
				logger.debug(requestMode);
				logger.debug(jsonRequest.toString());
				logger.debug(requestProperties.toString());
				logger.debug("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");

				JSONArray propertyData = getPropertyData(objectType, request.getLocale());
				
				if(!requestMode.equals(EDSAttributes.REQMODE_INITIALNEWOBJECT) && !requestMode.equals(EDSAttributes.REQMODE_INITIALEXISTINGOBJECT) 
							&& jsonRequest.containsKey(EDSAttributes.ATTR_EXTERNALDATAIDENTIFIER)
							&& !(jsonRequest.get(EDSAttributes.ATTR_EXTERNALDATAIDENTIFIER)==null || jsonRequest.get(EDSAttributes.ATTR_EXTERNALDATAIDENTIFIER).toString().isEmpty())){
					String sOrigReqProperties= jsonRequest.get(EDSAttributes.ATTR_EXTERNALDATAIDENTIFIER).toString();
					sOrigReqProperties.replace("\\\"", "\"");
					JSONObject jsonOrignalProps = JSONObject.parse(sOrigReqProperties);
					origReqProperties = (JSONArray)jsonOrignalProps.get(EDSAttributes.ATTR_ORIGPROPS);
					logger.debug("origReqProperties.toString()="+origReqProperties.toString());
					//Workaround Start: Have to do this because of the Bug- RO fields do not have values in the POST
					//jsonRespROFields = (JSONArray)jsonOrignalProps.get("responseROFields");
					//mashInRoPropertyVals(incomingRequestMode,requestProperties,jsonRespROFields,true);
					//Workaround End 

					//Workaround Start: Some additional Gyrations for double posts
					String originalReqMode = (String)jsonOrignalProps.get(EDSAttributes.ATTR_ORIGREQMODE);
					if(requestMode.equalsIgnoreCase(EDSAttributes.REQMODE_INPROGRESSCHANGES) && 
							(originalReqMode.equalsIgnoreCase(EDSAttributes.REQMODE_INITIALNEWOBJECT) || originalReqMode.equalsIgnoreCase(EDSAttributes.REQMODE_INITIALEXISTINGOBJECT))){
						logger.debug(originalReqMode + " Followed immediatedly by " + requestMode);
						logger.debug("OVERIDING RequestMode for "+requestMode);
						requestMode=originalReqMode;
					}
					//Workaround End 
				}

				extDataIdProperties = getEDSIdentifierProps(requestMode,propertyData,requestProperties);
				
				logger.debug("extDataIdProperties.hashCode()::"+extDataIdProperties.hashCode());
				
				//Workaround Start: Handle for double posts
				if(origReqProperties!=null){
					logger.debug("origReqProperties.hashCode()::"+origReqProperties.hashCode());
					if(extDataIdProperties.hashCode()==origReqProperties.hashCode()){
						logger.debug("ALERT! Double POST occured. Nothing has actually changed");
						for (int i = 0; i < origReqProperties.size(); i++) {
							((JSONObject)origReqProperties.get(i)).remove(EDSAttributes.ATTR_VALUE);
							((JSONObject)origReqProperties.get(i)).put(EDSAttributes.ATTR_VALUE,"null");
						}
					}
				}
				//Workaround End 
				
				populatedResultSets = new HashMap<String, HashMap<Integer, HashMap<String, String>>>();
				
				logger.debug("Starting overrides with requestMode::"+requestMode);
				logger.debug("Starting overrides with propertyData::"+propertyData.toString());
						
				for (int i = 0; i < propertyData.size(); i++) {
					JSONObject overrideProperty = (JSONObject)propertyData.get(i);
					String overridePropertyName = overrideProperty.get(EDSAttributes.ATTR_SYMBOLICNAME).toString();	
					boolean hasDepProps =false;
					String overRideType = "";

					if (overrideProperty.containsKey(EDSAttributes.ATTR_OVERRIDES)) {
						// perform dependent overrides.
						JSONArray arrOverrides = (JSONArray)overrideProperty.get(EDSAttributes.ATTR_OVERRIDES);
						
						for (int cntOvride = 0; cntOvride < arrOverrides.size(); cntOvride++) {
							JSONObject oneOverride = (JSONObject)arrOverrides.get(cntOvride);
							boolean finalOnlyLookup =false;
							if(oneOverride.containsKey(EDSAttributes.ATTR_OVERIDETYPE))overRideType = (String)oneOverride.get(EDSAttributes.ATTR_OVERIDETYPE);
							if(oneOverride.containsKey(EDSAttributes.ATTR_FINALONLY)) finalOnlyLookup=true;
							
							
							logger.debug("----------Dependent override for "+overridePropertyName+" ----------");
							logger.debug("overRideType::"+ overRideType);
							logger.debug("cntOvride::"+ cntOvride );
							
							switch (EDSOverrideTypes.valueOf(overRideType)) {
								// For both initial and in-progress calls, process the property data to add in choice lists 
								case CHOICELIST:
									if (requestMode.equals(EDSAttributes.REQMODE_INITIALNEWOBJECT) || requestMode.equals(EDSAttributes.REQMODE_INPROGRESSCHANGES) || requestMode.equals(EDSAttributes.REQMODE_INITIALEXISTINGOBJECT)) {
										// perform dependent overrides for inProgressChanges calls only
										// otherwise it will affect searches
										
										//If there was a lookup executed, check the response properties first
										if(!overrideProperty.containsKey("choicelistmatched") && !populatedResultSets.isEmpty()){
											logger.debug("Evaluating choicelist from response properties ");
											overrideProperty = EDSEvaluator.evalChoicelist(responseProperties,overrideProperty,oneOverride);
										}
										
										//If a match was not found in the response properties, then evaluate the requestProps
										if(!overrideProperty.containsKey("choicelistmatched")){
											logger.debug("Evaluating choicelist from request properties ");
											overrideProperty = EDSEvaluator.evalChoicelist(requestProperties,overrideProperty,oneOverride);
										}
									}
									break;
								case LOOKUP:
									if (requestMode.equals(EDSAttributes.REQMODE_INPROGRESSCHANGES)) {
										//Check if the value has changed from the orig
										if(origReqProperties!=null){
											hasDepProps = overrideProperty.containsKey(EDSAttributes.ATTR_HASDEPENDENTPROPERTIES) && 
																oneOverride.containsKey(EDSAttributes.ATTR_DEPENDENTCHILDREN);
											if(hasDepProps){
												// perform main lookup.							
												logger.debug("HasDependents Lookup override for "+overridePropertyName);
												//Cache the looked up data (The HasDependentNodes MUST come before the dependents)
												HashMap<Integer, HashMap<String, String>> lookupRS= EDSEvaluator.evalLookupResultset(reqUserId,origReqProperties, requestProperties,overrideProperty,oneOverride);
												if(lookupRS!=null){
													logger.debug("Adding to cache  " +oneOverride.get(EDSAttributes.ATTR_PROVIDERCLASS).toString());
													populatedResultSets.put(oneOverride.get(EDSAttributes.ATTR_PROVIDERCLASS).toString(), lookupRS);
												}
											}
											else{
										
												if(!overrideProperty.containsKey(EDSAttributes.ATTR_VALUE) || ((String)overrideProperty.get(EDSAttributes.ATTR_VALUE)).isEmpty()){
													overrideProperty = EDSEvaluator.evalLookupVal(populatedResultSets,origReqProperties, requestProperties,overrideProperty,oneOverride);
												}
											}
										}
									}else if((finalOnlyLookup && (requestMode.equals(EDSAttributes.REQMODE_FINALEXISTINGOBJECT) || requestMode.equals(EDSAttributes.REQMODE_FINALNEWOBJECT)))){
										overrideProperty = EDSEvaluator.evalFinalLookupVal(reqUserId, requestMode, origReqProperties, requestProperties,overrideProperty,oneOverride);
									}
									break;
								case DEFAULTVALUE:
									//If initialValue is present, this applies to only new objects. Due to inProgressChanges being set for new objects, we have to check that too 
									if ((requestMode.equals(EDSAttributes.REQMODE_INITIALNEWOBJECT)|| requestMode.equals(EDSAttributes.REQMODE_INPROGRESSCHANGES)) && oneOverride.containsKey("initialValue"))
										overrideProperty = EDSEvaluator.evalDefaultInitialVal(overrideProperty,oneOverride,requestProperties);
									else if (!oneOverride.containsKey("initialValue"))
										overrideProperty = EDSEvaluator.evalDefaultVal(reqUserId, requestMode,origReqProperties, requestProperties,overrideProperty,oneOverride);
									break;
								case REQUIRED:
								case NOTREQUIRED:
									if(requestMode.equals(EDSAttributes.REQMODE_INITIALEXISTINGOBJECT) || requestMode.equals(EDSAttributes.REQMODE_INPROGRESSCHANGES) ||
											requestMode.equals(EDSAttributes.REQMODE_FINALNEWOBJECT) || requestMode.equals(EDSAttributes.REQMODE_FINALEXISTINGOBJECT)) 
											overrideProperty = EDSEvaluator.evalRequiredField(requestMode,origReqProperties, requestProperties,overrideProperty,oneOverride,EDSOverrideTypes.valueOf(overRideType));
									break;
								case READONLY:
									if(!requestMode.equals(EDSAttributes.REQMODE_FINALNEWOBJECT) && !requestMode.equals(EDSAttributes.REQMODE_FINALEXISTINGOBJECT))
										if(!(overrideProperty.containsKey(EDSAttributes.ATTR_DISPLAYMODE)))
											overrideProperty = EDSEvaluator.evalReadOnlyField(requestMode,origReqProperties, requestProperties,overrideProperty,oneOverride);
									break;
								case HIDDEN:
									if(requestMode.equals(EDSAttributes.REQMODE_INITIALNEWOBJECT) || requestMode.equals(EDSAttributes.REQMODE_INITIALEXISTINGOBJECT) || requestMode.equals(EDSAttributes.REQMODE_INPROGRESSCHANGES))
										overrideProperty = EDSEvaluator.evalHiddenField(requestMode,origReqProperties, requestProperties,overrideProperty,oneOverride);
									break;
								case FORMATTER:
									if (requestMode.equals(EDSAttributes.REQMODE_FINALNEWOBJECT) || requestMode.equals(EDSAttributes.REQMODE_FINALEXISTINGOBJECT) || requestMode.equals(EDSAttributes.REQMODE_INPROGRESSCHANGES)){
										overrideProperty = EDSEvaluator.evalFormattedVal(requestMode, origReqProperties, requestProperties, overrideProperty, oneOverride);
									}
									break;
								case VALIDATOR:
									if (requestMode.equals(EDSAttributes.REQMODE_FINALNEWOBJECT) || requestMode.equals(EDSAttributes.REQMODE_FINALEXISTINGOBJECT) || requestMode.equals(EDSAttributes.REQMODE_INPROGRESSCHANGES)){
										overrideProperty = EDSEvaluator.evalValidation(requestMode, origReqProperties, requestProperties, overrideProperty, oneOverride);
									}
								default:
									break;
							}
						}
					} else {
						// perform non-dependent overrides.
						logger.debug("Non dependent override for "+overridePropertyName);
						overRideType = (String)overrideProperty.get(EDSAttributes.ATTR_OVERIDETYPE);
						if(overrideProperty.containsKey(EDSAttributes.ATTR_OVERIDETYPE)){
							switch (EDSOverrideTypes.valueOf(overRideType)) {
								case CHOICELIST:
									if (requestMode.equals(EDSAttributes.REQMODE_INITIALNEWOBJECT) 
											|| requestMode.equals(EDSAttributes.REQMODE_INITIALEXISTINGOBJECT)
											|| requestMode.equals(EDSAttributes.REQMODE_INPROGRESSCHANGES)){
										
										overrideProperty = EDSEvaluator.evalChoicelist(requestProperties,overrideProperty,null);
									}
									break;
								case DEFAULTVALUE:
									break;
								default:
									//Do nothing
							}		
						}
					}
					
					//Add the override property
					responseProperties.add( castToICNProperty(overrideProperty));
					
				}	
				
				//Rebuild the external data identifier as some properties may have changed the hasDependent flag
				extDataIdProperties = getEDSIdentifierProps(requestMode,propertyData,requestProperties);
				
				if(origReqProperties==null){
					//The first iteration
					origReqProperties = requestProperties;
				}
		}catch (EDSException edsExep){
		
			//String[] errMessages = new String[1];
			//errMessages[0]=edsExep.getMessage();
			JSONObject errTextObj = new JSONObject();
			JSONObject errDetailsObj = new JSONObject();
			JSONArray errCauses = new JSONArray();
			
			errTextObj.put("text", "EDS Service returned the following error");
			errCauses.add(edsExep.getMessage());
			errDetailsObj.put("causes", errCauses);
			
		  //Throwing the error does not work, wonder why?	
			edsErrObject = new JSONObject();
			edsErrObject.put("userMessage", errTextObj);
			edsErrObject.put("underlyingDetails", errDetailsObj);
			logger.debug(edsErrObject.toString());
		}catch (Exception e){
			logger.error("Error Occured",e);
			throw new ServletException(e);
		}

		//Workaround Start: Another Workaround due to RO fields not being propagated
		//if(responseProperties!=null && jsonRespROFields!=null)
		//	mashInRoPropertyVals(incomingRequestMode,responseProperties,jsonRespROFields,false);
		//jsonRespROFields = getReadOnlyProperties(responseProperties);
		//Workaround End :
		
		JSONObject jsonResponse = new JSONObject();
		if(edsErrObject == null){
			JSONObject edsIdentifier = new JSONObject();
			
			edsIdentifier.put(EDSAttributes.ATTR_ORIGPROPS, extDataIdProperties);
			edsIdentifier.put(EDSAttributes.ATTR_ORIGREQMODE, incomingRequestMode);
			//edsIdentifier.put("responseROFields", jsonRespROFields);
			//Form the response
			//Store away the original request properties for knowing when something changed
			jsonResponse.put(EDSAttributes.ATTR_EXTERNALDATAIDENTIFIER,edsIdentifier);
			jsonResponse.put(EDSAttributes.ATTR_PROPERTIES, responseProperties);
		}else{
			//Send the error to the client
			response.setStatus(400);
			jsonResponse =edsErrObject;
		}
			
		logger.debug("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
		logger.debug("OUTGOING RESPONSE PROPERTIES");
		logger.debug(jsonResponse.toString());
		logger.debug("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");

		// Send the response json
		PrintWriter writer = response.getWriter();
		jsonResponse.serialize(writer);
		
		logger.debug("Exiting doPost()");
		 
	}
	
	/**
	 * 
	 * getPropertyData : Gets all the overide property data
	 * @param objectType
	 * @param locale
	 * @return
	 * @throws IOException
	 */
	private JSONArray  getPropertyData(String objectType, Locale locale) throws IOException {

		String strConfigFile = "WEB-INF" + File.separator + "config" + File.separator + objectType.replace(' ', '_')+"_PropertyData.json";
		logger.debug(strConfigFile);
		//String strConfigFile = objectType.replace(' ', '_')+"_PropertyData.json";
		InputStream propertyDataStream = this.getClass().getClassLoader().getResourceAsStream(strConfigFile);
		JSONArray jsonPropertyData = new JSONArray();
		if(propertyDataStream!=null && propertyDataStream.available()!=0){
			jsonPropertyData = JSONArray.parse(propertyDataStream);
			logger.debug("Property Data was returned:: " + jsonPropertyData.toString());
		}else{
			logger.debug("Property Data was not returned for :: " + strConfigFile);
		}
		return jsonPropertyData;
	}

	/**
	 * 
	 * getRequestProperty : Gets matching property from the current Request JSON
	 * @param overridePropertyName
	 * @param requestProperties
	 * @return
	 */
	private JSONObject getRequestProperty(String overridePropertyName,JSONArray requestProperties){
		JSONObject matchedRequestProperty=null;
		
		for (int j = 0; j < requestProperties.size(); j++) {
			JSONObject requestProperty = (JSONObject)requestProperties.get(j);
			String requestPropertyName = requestProperty.get(EDSAttributes.ATTR_SYMBOLICNAME).toString();
			
			if(requestPropertyName.equalsIgnoreCase(overridePropertyName)){
				matchedRequestProperty=requestProperty;
				break;
			}
		}
		
		return matchedRequestProperty;
	}
	
	/**
	 * 	 checkForStoredSearch: Helper function to check for a stored search
	 *  
	 *   This function will have to change to correctly evaluate the searchtemplate class
	 *   As of ICN V2.0.0.1 there does not appear to be a field that indicates a search template
	 */
	boolean checkForStoredSearch(String objectType,String requestMode,JSONArray requestProps){
		boolean retVal=false;
		logger.debug("Entering checkForStoredSearch :"+objectType);
		
		logger.debug("requestMode::"+requestMode);
		logger.debug("objectType::"+objectType);
		
		if (requestMode.equals(EDSAttributes.REQMODE_INITIALEXISTINGOBJECT)){
			for (int i = 0; i < requestProps.size(); i++) {
				JSONObject oneProp = (JSONObject)requestProps.get(i);
				//Search templates have multi-valued value fields
				if(oneProp.containsKey(EDSAttributes.ATTR_VALUE) ){
					if(oneProp.get(EDSAttributes.ATTR_VALUE) instanceof JSONArray){
						retVal=true;
					}else{
					// If at least one value attribute is not JSONArray, this is not a ST	
						retVal=false;
						break;	
					}
				}
			}
		} 
		
		return retVal;
	}

	/**
	 * 
	 * castToICNProperty : Strips out the custom attributes to ensure we are sending a clean response
	 * @param propertyToFormat
	 * @return
	 */
	private JSONObject castToICNProperty(JSONObject propertyToFormat){
		JSONObject formattedProp = new JSONObject();
		
		String[] attributes = {EDSAttributes.ATTR_SYMBOLICNAME,EDSAttributes.ATTR_VALUE,EDSAttributes.ATTR_CUSTOMVALIDATIONERROR,
				EDSAttributes.ATTR_CUSTOMINVALIDITEMS,EDSAttributes.ATTR_DISPLAYMODE, EDSAttributes.ATTR_REQUIRED,
				EDSAttributes.ATTR_HIDDEN, EDSAttributes.ATTR_MAXVALUE, EDSAttributes.ATTR_MINVALUE, EDSAttributes.ATTR_MAXLENGTH,
				EDSAttributes.ATTR_CHOICELIST, EDSAttributes.ATTR_HASDEPENDENTPROPERTIES,EDSAttributes.ATTR_VALIDATEAS,
				EDSAttributes.ATTR_FORMAT, EDSAttributes.ATTR_FORMAT_DESCRIPTION};
	
		for (int i = 0; i < attributes.length; i++) {
			if(propertyToFormat.containsKey(attributes[i]))
				formattedProp.put(attributes[i], propertyToFormat.get(attributes[i]));
		}
		
	  /*"symbolicName": "symbolic_name",   
	    "value": potential_new_value,
	    "customValidationError": "Description of an invalid reason",
	    "customInvalidItems": [0,3,4,8], // Invalid multi-value items
	    "displayMode": "readonly_or_readwrite",
	    "required": true_or_false,
	    "hidden": true_or_false,
	    "maxValue": overridden_maximum_value,
	    "minValue": overridden_minimum_value,
	    "maxLength": underlying_maximum_length,
	    "choiceList": 
	    {	      }
	    "hasDependentProperties": true_or_false,*/
	
		
		return formattedProp ;
	}

	/**
	 * 
	 * getEDSIdentifierProps : Constructs the properties section of the external data identifier
	 * @param requestMode
	 * @param propertyData
	 * @param requestProperties
	 * @return
	 */
	private JSONArray getEDSIdentifierProps(String requestMode,JSONArray propertyData,JSONArray requestProperties){
		logger.debug("getEDSIdentifierProps:: Entering");
		JSONArray edsIdArr=new JSONArray();
		
		//Add a dummy for requestmode
		JSONObject reqMode = new JSONObject();
		reqMode.put(EDSAttributes.ATTR_SYMBOLICNAME, "requestMode");
		reqMode.put(EDSAttributes.ATTR_VALUE, requestMode);
		edsIdArr.add(reqMode);
		
		//Now add all the others
		for (int i = 0; i < propertyData.size(); i++) {
			JSONObject overrideProperty = (JSONObject)propertyData.get(i);
			String overridePropertyName = overrideProperty.get(EDSAttributes.ATTR_SYMBOLICNAME).toString();	
			//Add the hasdependent request properties to the EDIdentifier
			if(overrideProperty.containsKey(EDSAttributes.ATTR_HASDEPENDENTPROPERTIES))
				edsIdArr.add(getRequestProperty(overridePropertyName,requestProperties));
		}
		return edsIdArr;
	}
	
	/**
	 * 
	 * getReadOnlyProperties : Helper function to get the RO properties. May use in EDS Id
	 * @param propsToInspect
	 * @return
	 */
	private JSONArray getReadOnlyProperties(JSONArray propsToInspect){
		logger.debug("getReadOnlyProperties:: Entering");
		JSONArray roProps = new JSONArray();
		for (int i = 0; i < propsToInspect.size(); i++) {
			JSONObject oneProp =(JSONObject)propsToInspect.get(i);
			if(oneProp.containsKey(EDSAttributes.ATTR_DISPLAYMODE) && ((String)oneProp.get(EDSAttributes.ATTR_DISPLAYMODE)).equalsIgnoreCase("readonly")){
				roProps.add(oneProp);
			}
		}
		return roProps;
	}
	
	/**
	 * 
	 * mashInRoPropertyVals : Helper function to mashin the RO properties. Mostly for working around RO PMR
	 * @param requestMode
	 * @param propsToInspect
	 * @param newPropValues
	 * @param treatSpaceAsNull
	 */
	private void mashInRoPropertyVals(String requestMode, JSONArray propsToInspect,JSONArray newPropValues,boolean treatSpaceAsNull){
		logger.debug("mashInRoPropertyVals:: Entering");
		for (int i = 0; i < newPropValues.size(); i++) {
			JSONObject newProp =(JSONObject)newPropValues.get(i);
			JSONObject mainProp =null;
			String newPropName = (String)newProp.get(EDSAttributes.ATTR_SYMBOLICNAME);
			for (int j = 0; j < propsToInspect.size(); j++) {
				mainProp =(JSONObject)propsToInspect.get(j);
				String mainPropName = (String)mainProp.get(EDSAttributes.ATTR_SYMBOLICNAME);
				//logger.debug("Comparing mainPropName::" + mainPropName+" with newPropName::" + newPropName);
				boolean mainPropIsEmpty = !mainProp.containsKey(EDSAttributes.ATTR_VALUE) ;
				//If space is treated as empty and override its value
				if(!mainPropIsEmpty && treatSpaceAsNull && ((String)mainProp.get(EDSAttributes.ATTR_VALUE)).isEmpty())
					mainPropIsEmpty=true;
				
				if(newPropName.equalsIgnoreCase(mainPropName) && mainPropIsEmpty && newProp.containsKey(EDSAttributes.ATTR_VALUE)){
					logger.debug(mainPropName+" does not contain a value");
					logger.debug(mainPropName+" is being set to"+(String)newProp.get(EDSAttributes.ATTR_VALUE));
					mainProp.remove(EDSAttributes.ATTR_VALUE);
					mainProp.put(EDSAttributes.ATTR_VALUE, (String)newProp.get(EDSAttributes.ATTR_VALUE));
					if(!mainProp.containsKey(EDSAttributes.ATTR_DISPLAYMODE))
						mainProp.put(EDSAttributes.ATTR_DISPLAYMODE, "readonly");

					//RO In the payload is ignored by ICN. So remove this 
					if(requestMode.equalsIgnoreCase(EDSAttributes.REQMODE_FINALEXISTINGOBJECT)){
						mainProp.remove(EDSAttributes.ATTR_DISPLAYMODE);
						mainProp.put(EDSAttributes.ATTR_DISPLAYMODE, "readwrite");
					}
					break;
				}
				
				if(mainProp==null){
					logger.debug(newPropName + " Was not found. Adding it");
					propsToInspect.add(newProp);
				}
			}
		}
		logger.debug("mashInRoPropertyVals:: Exiting");
	}
	
}

