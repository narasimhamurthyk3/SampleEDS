package com.ibm.icn.custom.eds.common;

import java.util.HashMap;

import com.ibm.json.java.JSONObject;

public abstract class EDSChoiceList {

	public abstract JSONObject getChoicelist(String choicelistName,HashMap<String, String> matchedListKeyValPairs) throws Exception ;
	public abstract boolean clearCaches() throws Exception ;
	
}
