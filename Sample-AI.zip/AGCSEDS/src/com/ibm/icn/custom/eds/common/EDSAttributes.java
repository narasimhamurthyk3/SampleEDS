/**
 * @author Philip
 *
 */
package com.ibm.icn.custom.eds.common;

/**
 * @author Philip
 *
 */
public class EDSAttributes {
	//Request Modes
	public static final String REQMODE_INITIALNEWOBJECT = "initialNewObject";
	public static final String REQMODE_INITIALEXISTINGOBJECT ="initialExistingObject";
	public static final String REQMODE_INPROGRESSCHANGES ="inProgressChanges";
	public static final String REQMODE_FINALNEWOBJECT = "finalNewObject";
	public static final String REQMODE_FINALEXISTINGOBJECT = "finalExistingObject";
	
	//EDS API Request nodes
	public static final String ATTR_REQUESTMODE = "requestMode";
	public static final String ATTR_PROPERTIES = "properties";
	public static final String ATTR_CLIENTCONTEXT = "clientContext";
	public static final String ATTR_USERID = "userid";
	public static final String ATTR_EXTERNALDATAIDENTIFIER = "externalDataIdentifier";
	// EDS API Property Attributes
	public static final String ATTR_SYMBOLICNAME = "symbolicName";
	public static final String ATTR_VALUE = "value";
	public static final String ATTR_CUSTOMVALIDATIONERROR = "customValidationError";
	public static final String ATTR_CUSTOMINVALIDITEMS = "customInvalidItems";
	public static final String ATTR_DISPLAYMODE = "displayMode";
	public static final String ATTR_REQUIRED = "required";
	public static final String ATTR_HIDDEN = "hidden";
	public static final String ATTR_MAXVALUE = "maxValue";
	public static final String ATTR_MINVALUE = "minValue";
	public static final String ATTR_MAXLENGTH = "maxLength";
	public static final String ATTR_CHOICELIST = "choiceList";
	public static final String ATTR_HASDEPENDENTPROPERTIES = "hasDependentProperties";
	public static final String ATTR_VALIDATEAS = "validateAs";
	public static final String ATTR_CHOICELIST_DISPLAYNAME = "displayName";
	public static final String ATTR_CHOICELIST_CHOICES="choices";
	public static final String ATTR_DISPLAYMODE_READONLY = "readonly";
	public static final String ATTR_DISPLAYMODE_READWRITE = "readwrite";
	public static final String ATTR_FORMAT = "format";
	public static final String ATTR_FORMAT_DESCRIPTION = "formatDescription";
	
	// Custom EDS Property Attributes
	public static final String ATTR_OVERRIDES = "overrides";
	public static final String ATTR_OVERIDETYPE = "overrideType";
	public static final String ATTR_ORIGPROPS ="originalProperties";
	public static final String ATTR_ORIGREQMODE ="originalRequestMode";
	public static final String ATTR_DEPENDENTS = "dependents";
	public static final String ATTR_DEPENDENTON ="dependentOn";
	public static final String ATTR_DEPENDENTCHILDREN ="dependentChildren";
	public static final String ATTR_DEPENDENTVALUES ="dependentValues";
	public static final String ATTR_PROVIDERCLASS ="providerClass";
	public static final String ATTR_PROVIDERATTR ="providerAttribute";
	public static final String ATTR_READONLYONLOOKUP ="readOnlyOnLookup";
	public static final String ATTR_INITIALVALUE ="initialValue";
	public static final String ATTR_DEFAULTVALUE ="defaultValue";
	public static final String ATTR_FINALONLY ="finalOnly";
}
