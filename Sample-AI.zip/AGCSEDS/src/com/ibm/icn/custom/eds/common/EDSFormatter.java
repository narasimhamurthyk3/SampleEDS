/**
 * @author Philip
 *
 */
package com.ibm.icn.custom.eds.common;

import java.util.HashMap;

/**
 * @author Philip
 *
 */
public abstract class EDSFormatter {
	public abstract String getFormattedValue(String requestMode, String propertyName, Object propertyValue) throws Exception ;
}
