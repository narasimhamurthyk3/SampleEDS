package com.ibm.icn.custom.eds.providers;

import java.util.Iterator;

import org.apache.log4j.Logger;
import com.filenet.api.core.Connection;
import com.filenet.api.core.Domain;
import com.filenet.api.core.Factory;
import com.filenet.api.core.ObjectStore;
import com.filenet.api.admin.ChoiceList;
import com.filenet.api.util.UserContext;
import com.ibm.icn.custom.eds.common.EDSProperties;

public class CEDataProvider {
	private Logger logger = null;	
	private Connection ceConnection = null;
	private Domain domain = null;
	private ObjectStore objectStore = null;
	
	public CEDataProvider() {
		setLogger();
	}
	
	public CEDataProvider(Connection ceConnection, Domain ceDomain, ObjectStore ceObjectStore)
	{	
		setLogger();		
		setCEConnection(ceConnection);		
		setDomain(ceDomain);
		setObjectStore(ceObjectStore);
		//setLogger();		
	}	
	
	private void setLogger()
	{
		logger = Logger.getLogger(CEDataProvider.class);
	}
		
	public Connection getCEConnection() {
		return ceConnection;
	}

	public void setCEConnection(Connection ceConnection) {
		this.ceConnection = ceConnection;
	}
		
	/**
	 * @param domain the domain to set
	 */
	public void setDomain(Domain domain) {
		logger.debug("Setting Domain ");
		this.domain = domain;
	}

	/**
	 * @return the domain
	 */
	public Domain getDomain() {
		return domain;
	}

	/**
	 * Method: ConnectToCE
	 * Purpose: Get CEConnection This method is used to get the CE connection.
	 * Remarks: It reads ENABLE_CEWS_CONNECTION from the configuration properties file. In DEV environment it would be set to true. For all other environments, it would be false.
	 * @throws Exception
	 */
	
	public void ConnectToCE() throws Exception {
		try {
			logger.info("CEDataProvider::getCEConnection::Entering.");
			String strURI = null;
			String strUsername = null;
			String strPassword = null;
			String strObjectStoreName = EDSProperties.edsProperties.getProperty("OBJECT_STORE_NAME");
			String isCEWSEnabled = EDSProperties.edsProperties.getProperty("ENABLE_CEWS_CONNECTION");
			
			logger.debug("CEDataProvider::getCEConnection::CEWebservice enabled status is : " + isCEWSEnabled);
			if (isCEWSEnabled != null && isCEWSEnabled.equals("true")) {
				logger.debug("CEDataProvider::getCEConnection::Reading values from EDSProperties file.");
				
				strURI = EDSProperties.edsProperties.getProperty("CEWS_URL");
				strUsername = EDSProperties.edsProperties.getProperty("CEWS_USERNAME");
				strPassword = EDSProperties.edsProperties.getProperty("CEWS_PASSWORD");
				
				logger.debug("CEDataProvider::getCEConnection::URI value is  : " + strURI);
				logger.debug("CEDataProvider::getCEConnection::Username is : " + strUsername);
				logger.debug("CEDataProvider::getCEConnection::Password is : " + strPassword);				
			} else {
				logger.debug("CEDataProvider::getCEConnection::Reading values from EDSProperties file.");
				strURI = EDSProperties.edsProperties.getProperty("RemoteServerUrl");
				strURI = strURI.substring(strURI.indexOf(":") + 1, strURI.length());
				logger.debug("CEDataProvider::getCEConnection::URI value is : " + strURI);
			}
			
			// Get the connection
			logger.debug("CEDataProvider::getCEConnection::Get the connection.");
			ceConnection = Factory.Connection.getConnection(strURI);
			logger.debug("CEDataProvider::getCEConnection::Got the connection.");
			
			// Build the subject using the FileNetP8WSI stanza
			// Use the FileNetP8WSI stanza for CEWS
			if (isCEWSEnabled.equals("true")) {
				logger.debug("CEDataProvider::getCEConnection::Create Subject using UserContext");
				UserContext uc = UserContext.get();
				uc.pushSubject(UserContext.createSubject(ceConnection, strUsername, strPassword, "FileNetP8WSI"));
			}

			try {
				logger.debug("CEDataProvider::getCEConnection::Get the default domain");
				
				setDomain(Factory.Domain.getInstance(ceConnection, null));
				logger.debug("CEDataProvider::getCEConnection::Get an object store");
				
				setObjectStore(Factory.ObjectStore.fetchInstance(getDomain(), strObjectStoreName, null));
				
				logger.debug("CEDataProvider::getCEConnection::ObjectStore display name is :: " + getObjectStore().get_DisplayName());
			} catch (Exception ex) {
				logger.debug("CEDataProvider::getCEConnection::Exception occured while connecting to CE.", ex);
				logger.error("CEDataProvider::getCEConnection::Exception occured while connecting to CE.", ex);				
				throw ex;
			} finally {
				if (isCEWSEnabled.equals("true")) {
					// logger.info("Pop Subject from UserContext");
					// UserContext.get().popSubject();
				}
				logger.info("CEDataProvider::getCEConnection::Exiting.");
			}
		} catch (Exception e) {			
			logger.debug("CEDataProvider::getCEConnection::ERROR in getCEConnection() method : ", e);
			logger.error("CEDataProvider::getCEConnection::ERROR in getCEConnection() method : ", e);
			throw e;
		}
	}
	
		
	/**
	 * @param objectStore the objectStore to set
	 */
	public void setObjectStore(ObjectStore objectStore) {
		this.objectStore = objectStore;
	}

	/**
	 * @return the objectStore
	 */
	public ObjectStore getObjectStore() {
		return objectStore;
	}

	/**
	 * @return a CE Choicelist
	 */
	public ChoiceList getChoiceList(String choiceListSymbolicName) {
				
		Iterator iter2 = objectStore.get_ChoiceLists().iterator();
	    ChoiceList objChoiceList = null;

	    // Loop until choice list found
	    while (iter2.hasNext())
	    {
	    	objChoiceList = (com.filenet.api.admin.ChoiceList) iter2.next();
	    	String prpName = objChoiceList.get_Name();

	    	if (prpName.equalsIgnoreCase(choiceListSymbolicName))
	    	{
	    		// ChoiceList object found
	            System.out.println("Choice list found : " + prpName);
	            System.out.println(objChoiceList);
	            break;
	         }
	    }		
	      
	    return objChoiceList;
	}

}
