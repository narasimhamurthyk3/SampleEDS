package com.ibm.icn.custom.eds.providers;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.Map;

import javax.naming.Context;
import javax.naming.NamingEnumeration;
import javax.naming.NamingException;
import javax.naming.directory.Attribute;
import javax.naming.directory.Attributes;
import javax.naming.directory.SearchControls;
import javax.naming.directory.SearchResult;
import javax.naming.ldap.InitialLdapContext;
import javax.naming.ldap.LdapContext;

import org.apache.log4j.Logger;

import javax.resource.spi.security.PasswordCredential;
import javax.security.auth.callback.CallbackHandler;
import java.util.Set;

import com.ibm.wsspi.security.auth.callback.WSMappingCallbackHandlerFactory;


import javax.security.auth.Subject;
import javax.security.auth.login.LoginContext;

import com.ibm.icn.custom.eds.common.EDSProperties;

/**
 * 
 * @author Philip
 *
 */
public class LDAPSearch {
	private Logger logger;
	private static HashMap<String, ArrayList<String[]>>  cachedUsersList;
	private static Date cachedTime;
	private static String ldapUserName=null;
	private static String ldapUserPwd=null;
	
	private String searchBase;
	
	public LDAPSearch() {
		logger = Logger.getLogger(LDAPSearch.class.getName());
		clearCaches();
	}
	
	/**
	 * 
	 * getCachedUsersList
	 * @return
	 */
	public static HashMap<String, ArrayList<String[]>> getCachedUsersList(){
		clearCaches();	
		return cachedUsersList;
	}

	/**
	 * 
	 * addToCachedUsersList
	 * @param userListName
	 * @param userList
	 * @return
	 */
	public static boolean addToCachedUsersList(String userListName,ArrayList<String[]> userList) {
		if(cachedUsersList==null)
			cachedUsersList = new HashMap<String, ArrayList<String[]>>();
		cachedUsersList.put(userListName, userList);
		
		return true;
	}
	
	/**
	 * 
	 * clearCaches
	 */
	public static void clearCaches(){
		//logger.debug("Entering clear caches");
		if(cachedUsersList!=null && cachedTime!=null){
			Calendar cal = Calendar.getInstance();
			cal.setTime(cachedTime);
			int lastCacheDay = cal.get(Calendar.DAY_OF_YEAR);
			cal.setTime(new Date());
			int today = cal.get(Calendar.DAY_OF_YEAR);

			System.out.println("lastCacheDay="+lastCacheDay+ " today="+today);
			//If the day has changed
			if(lastCacheDay!=today){
				System.out.println("Clearing caches");
				cachedUsersList.clear();
			}
		}else{
			cachedUsersList = new HashMap<String, ArrayList<String[]>>();
		}
	}
	
	/**
	 * 
	 * createContext : Creates and return and LDAP Context
	 * @return LdapContext
	 */
	private LdapContext createContext()  {
		try {
			if(ldapUserName==null)
				getWASCredentials(EDSProperties.edsProperties.getProperty("WAS_LDAP_J2C_ALIAS"));
		} catch (Exception e) {
			logger.error(e);
		}
		
		String ldapURL = EDSProperties.edsProperties.getProperty("LDAP_URL");
		
		//Move to J2C
		/*String ldapUserName= EDSProperties.edsProperties.getProperty("LDAP_USER");
		String ldapUserPwd = EDSProperties.edsProperties.getProperty("LDAP_USERPWD");*/
		
		String ldapCxtFactory =EDSProperties.edsProperties.getProperty("LDAP_CONTEXTFACTORY");
		String ldapAuthMethod = EDSProperties.edsProperties.getProperty("LDAP_AUTHMETHOD");
		searchBase= EDSProperties.edsProperties.getProperty("LDAP_SEARCHBASE");
		Hashtable<String, String> env = new Hashtable<String, String>();
		
		logger.debug("ldapURL::"+ldapURL);
		logger.debug("ldapUserName::"+ldapUserName);
		logger.debug("ldapUserPwd::"+ldapUserPwd);
		logger.debug("ldapCxtFactory::"+ldapCxtFactory);
		logger.debug("ldapAuthMethod::"+ldapAuthMethod);
		logger.debug("searchBase::"+searchBase);
		
		/*String adminName = "CN=p8admin,CN=Users,DC=ecm,DC=ibm,DC=local";
		String adminPassword = "filenet";
		String ldapURL = "ldap://ecmdemo1:389";
		env.put(Context.INITIAL_CONTEXT_FACTORY,"com.sun.jndi.ldap.LdapCtxFactory");*/
		//set security credentials, note using simple cleartext authentication
		
		env.put(Context.SECURITY_AUTHENTICATION,ldapAuthMethod);
		env.put(Context.SECURITY_PRINCIPAL,ldapUserName);
		env.put(Context.SECURITY_CREDENTIALS,ldapUserPwd);
				
		//connect to the domain controller
		env.put(Context.PROVIDER_URL,ldapURL);
		env.put(Context.INITIAL_CONTEXT_FACTORY,ldapCxtFactory);
		LdapContext ctx=null;
		try {
			logger.debug("Creating LDAP context");
			
			//Create the initial directory context
			ctx = new InitialLdapContext(env,null);
		}catch(Exception e){
			logger.error(e);
		}
		
		return ctx;
	}
	
	/**
	 * 
	 * getGroupMembers : Gets members of an LDAP Groups. Only attributes requested are returned for each member
	 * @param strGroupCN
	 * @param strAttributes
	 * @return ArrayList of users. Each user attribute is placed in a string array
	 */
	public ArrayList<String[]> getGroupMembers( String strGroupCN,String[] strAttributes)
	{
		cachedTime = new Date();
		
		ArrayList<String[]> retVal = new ArrayList<String[]>();
		
		try {
			logger.debug("Creating LDAP context");
			
			//Create the initial directory context
			LdapContext ctx = createContext();
		
			logger.debug("Creating Search Controls");
			//Create the search controls 		
			SearchControls searchCtls = new SearchControls();
		
			//Specify the search scope
			searchCtls.setSearchScope(SearchControls.SUBTREE_SCOPE);
 
			//specify the LDAP search filter
			String searchFilter = "(&(objectClass=group)"+strGroupCN+")";
			logger.debug("Set Search filter to::"+searchFilter );
			
			//Specify the Base for the search
			//String searchBase = "DC=ecm,DC=ibm,DC=local";
			logger.debug("Set searchBase to::"+searchBase);
			
			//initialize counter to total the group members
			int totalResults = 0;
 
			//Specify the attributes to return
			String returnedAtts[]={"member"};
			logger.debug("Set Returned attributes to::"+Arrays.toString(returnedAtts));
			searchCtls.setReturningAttributes(returnedAtts);
		
			//Search for objects using the filter
			NamingEnumeration<SearchResult> answer = ctx.search(searchBase, searchFilter, searchCtls);
 
			//Loop through the search results
			while (answer.hasMoreElements()) {
				SearchResult sr = (SearchResult)answer.next();
 
				logger.debug(">>>" + sr.getName());
 
				//Print out the members
 
				Attributes attrs = sr.getAttributes();
				if (attrs != null) {
 
					try {
						for (NamingEnumeration<?> ae = attrs.getAll();ae.hasMore();) {
							Attribute attr = (Attribute)ae.next();
							logger.debug("Attribute: " + attr.getID());

							for (NamingEnumeration<?> e = attr.getAll();e.hasMore();totalResults++) {
								String memberCN=(String)e.next();
								String[] retAttrVals =new String[strAttributes.length];;
								logger.debug(" " +  totalResults + ". " +  memberCN);

								searchFilter="(&(" + memberCN.split(",")[0] + "))";
								logger.debug("Using search filter with " + searchFilter);
								searchCtls.setReturningAttributes(strAttributes);
								
								try{
									LdapContext lookedupUser = (LdapContext)ctx.lookup(memberCN);
									logger.debug("lookedupUser::"+ lookedupUser);
									Attributes memAttrs = lookedupUser.getAttributes("");
									for (int i = 0; i < strAttributes.length; i++) {
										logger.debug("Getting attribute::"+strAttributes[i]);
										Attribute memAttr = memAttrs.get(strAttributes[i]);
										if(memAttr!=null){
											String memAttrName = memAttr.getID();
											logger.debug("Attribute: " + memAttrName);
											String memAttrVal = (String)memAttr.get(0);
											logger.debug("AttributeVal: " + memAttrVal);
											retAttrVals[i]=(memAttrVal==null?"NULL":memAttrVal);
										}else{
											retAttrVals[i]="NULL";
										}
									}
									logger.debug(Arrays.toString(retAttrVals));
									retVal.add(retAttrVals);
								}catch(NamingException memException){
									logger.error("Error getting member attributes",memException);
								}
							}
 						}
					}	 
					catch (NamingException e)	{
						e.printStackTrace();
						System.err.println("Problem listing members: " + e);
					}
				
				}
			}
 
			logger.debug("Total members: " + totalResults);
			ctx.close();
 
		}catch (NamingException e) {
			e.printStackTrace();
			logger.error("Problem searching directory: " + e);
        }
	
		return retVal;
	}

	/**
	 * 
	 * findUserByAccountName : Finds User Attributes by account name
	 * @param SAMAccountName
	 * @param strAttributes
	 * @return
	 * @throws Exception
	 */
	public String[] findUserByAccountName(String SAMAccountName,String[] strAttributes) throws Exception {

        String searchFilter = "(&(objectClass=user)(sAMAccountName=" + SAMAccountName + "))";
        String [] retVals = new String[strAttributes.length];
        
        SearchControls searchControls = new SearchControls();
        searchControls.setSearchScope(SearchControls.SUBTREE_SCOPE);
        LdapContext ctx = createContext();
        
        NamingEnumeration<SearchResult> results = ctx.search(searchBase, searchFilter, searchControls);

        SearchResult searchResult = null;
        if(results.hasMoreElements()) {
             searchResult = (SearchResult) results.nextElement();

            //make sure there is not another item available, there should be only 1 match
            if(results.hasMoreElements()) {
                logger.error("Matched multiple users for the accountName: " + SAMAccountName);
                throw new Exception("Matched multiple users for the accountName: " + SAMAccountName);
            }
            
            Attributes attrs = searchResult.getAttributes();
			if (attrs != null) {
				for (int i = 0; i < strAttributes.length; i++) {
					logger.debug("Getting attribute::"+strAttributes[i]);
					Attribute memAttr = attrs.get(strAttributes[i]);
					if(memAttr!=null){
						String memAttrName = memAttr.getID();
						logger.debug("Attribute: " + memAttrName);
						String memAttrVal = (String)memAttr.get(0);
						logger.debug("AttributeVal: " + memAttrVal);
						retVals[i]=(memAttrVal==null?"NULL":memAttrVal);
					}else{
						retVals[i]="NULL";
					}
				}
				logger.debug(Arrays.toString(retVals));
			}	 
        }
        
        return retVals;
    }

	/**
	 * 
	 * findUserGroupsByAccountName : Finds User Groups by account name
	 * @param SAMAccountName
	 * @param applicationGroups
	 * @return Comma delimited list of Application Groups
	 * @throws Exception
	 */
	public String findUserGroupsByAccountName(String SAMAccountName,String applicationGroups) throws Exception {
		logger.debug("findUserGroupsByAccountName");
		logger.debug("SAMAccountName="+SAMAccountName);
		logger.debug("applicationGroups"+applicationGroups);
		
        String userSearchFilter = "(&(objectClass=user)(sAMAccountName=" + SAMAccountName + "))";
        String  retVals = "";
        String [] appLdapGroups = applicationGroups.split(";");
        
        SearchControls searchControls = new SearchControls();
        searchControls.setSearchScope(SearchControls.SUBTREE_SCOPE);
        LdapContext ctx = createContext();
        
        NamingEnumeration<SearchResult> results = ctx.search(searchBase, userSearchFilter, searchControls);

        SearchResult searchResult = null;
        if(results.hasMoreElements()) {
             searchResult = (SearchResult) results.nextElement();
             
            //make sure there is not another item available, there should be only 1 match
            if(results.hasMoreElements()) {
                logger.error("Matched multiple users for the accountName: " + SAMAccountName);
                throw new Exception("Matched multiple users for the accountName: " + SAMAccountName);
            }
            
            Attributes attrs = searchResult.getAttributes();
			if (attrs != null) {
				//for (int i = 0; i < strAttributes.length; i++) {
					logger.debug("Getting memberOf attribute");
					Attribute memAttr = attrs.get("memberOf");
					logger.debug("memberOf Contains " + memAttr.size()+" elements");

					if(memAttr!=null){
						String memAttrName = memAttr.getID();
						logger.debug("Attribute: " + memAttrName);

						for (int i = 0; i < memAttr.size(); i++) {
							String memAttrVal = (String)memAttr.get(i);
							logger.debug("One AttributeVal: " + memAttrVal);
							if(memAttrVal!=null){
								//Dont want to return the CN group name so compare with application groups
								for (int j = 0; j < appLdapGroups.length; j++) {
									logger.debug("Comparing with " + appLdapGroups[j]);
									if(memAttrVal.contains(appLdapGroups[j])){
										logger.debug("Match found");
										if(retVals.isEmpty())
											retVals = appLdapGroups[j];
										else
											retVals += (","+ appLdapGroups[j]);
										
										break;
									}
								} 
							}
						}
					}
				//}
				logger.debug("findUserGroupsByAccountName="+retVals);
			}	 
        }
        
        return retVals;
    }

	
	/**
	 * 
	 * getWASCredentials : Get Credentials from a J2C alias configured in WAS
	 * @param alias
	 * @return
	 * @throws Exception
	 */
	private String getWASCredentials(String alias) throws Exception {
		logger.debug("Entering getWASCredentials for alias" + alias);
		String password="";
		
		Map<String,String> map = new HashMap<String,String>();
		
		map.put("com.ibm.mapping.authDataAlias", alias);
		//create a callback handler with the specified property (to find the alias)
		//and null for the managed connection factory (MCF) since we don't need it
		CallbackHandler handler = WSMappingCallbackHandlerFactory.getInstance().getCallbackHandler(map, null);
		Subject subject = new Subject();
		LoginContext lc = new LoginContext("DefaultPrincipalMapping", subject, handler);
		lc.login();
		subject = lc.getSubject();
		Set<PasswordCredential> pwdCredentialSet = subject.getPrivateCredentials(PasswordCredential.class);
		PasswordCredential obj = (PasswordCredential)pwdCredentialSet.iterator().next();
		if (obj != null) {
				ldapUserName =obj.getUserName();
				byte[] passphrase = new String(obj.getPassword()).getBytes();
				password= new String(passphrase);
				this.ldapUserPwd = password;
				logger.debug("ldap username is " + ldapUserName);
				logger.debug("password is " + this.ldapUserPwd);
		} else {
			logger.error("Custom LDAP Connection credentials not configured!!");
			throw new Exception("Custom LDAP Connection credentials not configured");
		}
		return password;
	}
}
