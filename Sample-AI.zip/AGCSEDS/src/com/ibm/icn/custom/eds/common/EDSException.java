package com.ibm.icn.custom.eds.common;

public class EDSException extends Exception {
	private static final long serialVersionUID = 9120921211673458923L;
	
	public EDSException(String errorMessage) {
		super(errorMessage);
	}
}
