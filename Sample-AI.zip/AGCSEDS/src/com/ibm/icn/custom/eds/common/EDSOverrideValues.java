package com.ibm.icn.custom.eds.common;

public enum EDSOverrideValues {
	TODAY,
	CURRENTUSERNAME,
	CURRENTUSERID,
	CURRENTUSEREMAIL,
	CURRENTUSERGROUPS,
	CURRENTUSERGROUPSARRAY,
}
