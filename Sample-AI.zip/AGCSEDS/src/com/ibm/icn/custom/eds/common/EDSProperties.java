package com.ibm.icn.custom.eds.common;

import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.util.Properties;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

public class EDSProperties {
	Logger logger =null;
	public static final String edsPropertyEnvVariable ="com.ibm.icn.custom.eds.propertyFileLocation";
	public static final String edsLog4jPropertyEnvVariable ="com.ibm.icn.custom.eds.log4jPropertyFileLocation";
	
	public static Properties edsProperties = null;

	public EDSProperties() {
	}
	
	public static void init(Class servletClass) throws Exception{
		if(edsProperties==null){
			
			String edsPropFile = System.getProperty(edsPropertyEnvVariable);
			String log4jConfigFile = System.getProperty(edsLog4jPropertyEnvVariable);
			
			System.out.println("Reading eds properties from " + edsPropFile );
			
			//String log4jConfigFile= "WEB-INF" + File.separator + "config" + File.separator + "log4j.properties";
			//InputStream log4jStream = servletClass.getClassLoader().getResourceAsStream(log4jConfigFile);
			PropertyConfigurator.configure(log4jConfigFile);
		
			//String edsPropFile= "WEB-INF" + File.separator + "config" + File.separator + "icncustomeds.properties";
			
			FileInputStream edsPropStream = new FileInputStream(edsPropFile); //servletClass.getClassLoader().getResourceAsStream(edsPropFile);
			
			Properties edsProps = new Properties();
			try {
				edsProps.load(edsPropStream);
				EDSProperties.edsProperties=edsProps;
			} catch (Exception e) {
				throw e;
			}
		}
	}
	
}
