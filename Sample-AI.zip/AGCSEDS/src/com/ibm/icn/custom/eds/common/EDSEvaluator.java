package com.ibm.icn.custom.eds.common;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.List;

import org.apache.log4j.Logger;

import com.ibm.icn.custom.eds.providers.LDAPSearch;
import com.ibm.json.java.JSONArray;
import com.ibm.json.java.JSONObject;


/**
 * 
 * @author Philip Jacob
 *
 */

public abstract class EDSEvaluator {
	public static Logger logger=Logger.getLogger(EDSEvaluator.class.getName());

	/**
	 * 
	 * evalChoicelist : Evaluates choicelist values based on dependent properties
	 * @param requestProperties
	 * @param mainProperty
	 * @param override
	 * @return
	 * @throws Exception
	 */
	public static JSONObject evalChoicelist(JSONArray requestProperties, JSONObject mainProperty,JSONObject override) throws Exception {
		String overridePropertyName = mainProperty.get(EDSAttributes.ATTR_SYMBOLICNAME).toString();
		String matchedValue="";
		HashMap<String, String> matchedListKeyValPairs = new HashMap<String, String>();
		
		if(override.containsKey(EDSAttributes.ATTR_DEPENDENTS)){
			logger.debug("Dependent choicelist");
			//Dependent choicelist evaluation
			JSONArray dependentData = (JSONArray)override.get(EDSAttributes.ATTR_DEPENDENTS);
			for (int cntDependents = 0; cntDependents < dependentData.size(); cntDependents++) {
				JSONObject dependentProp = (JSONObject)dependentData.get(cntDependents);
				String dependentOn = dependentProp.get(EDSAttributes.ATTR_DEPENDENTON).toString();
				logger.debug("overridePropertyName::"+overridePropertyName+" dependentOn::"+dependentOn);
	
				//We are storing in an array to reduce json size
				String[] dependentValueArr = dependentProp.get(EDSAttributes.ATTR_DEPENDENTVALUES).toString().split(",");
				for (int j = 0; j < requestProperties.size(); j++) {
					JSONObject requestProperty = (JSONObject)requestProperties.get(j);
					String requestPropertyName = requestProperty.get(EDSAttributes.ATTR_SYMBOLICNAME).toString();
					Object propValue = requestProperty.get(EDSAttributes.ATTR_VALUE);
					for (int k = 0; k < dependentValueArr.length; k++) {
						String dependentValue = dependentValueArr[k];
						if (requestPropertyName.equals(dependentOn)){
							logger.debug("Comparing propValue::"+propValue+" dependentValue::"+dependentValue);
							
							//Workaround for ICN 2.0.1.1 LA002, sometimes the properties come in as Arrays???
							if(propValue instanceof JSONArray){
								logger.debug("Now why is this an array");
								JSONArray values = (JSONArray) propValue;
								logger.debug("currDepPropValue ::" + propValue.toString());
								for (int i = 0; i < values.size(); i++) {
									logger.debug("dependentValue ::" + dependentValue);
									logger.debug("values[i] ::" + values.get(i).toString());
									if(dependentValue.equalsIgnoreCase(values.get(i).toString()) || dependentValue.equals("*")){
										logger.debug("values.get(i).toString()::"+values.get(i).toString()+" dependentValue::"+dependentValue);
										logger.debug("Match found!!");
										matchedValue=values.get(i).toString();
										matchedListKeyValPairs.put(requestPropertyName, matchedValue);
										continue;
									}
								}
								
							}else if (propValue!=null && ( dependentValue.equals(propValue) || dependentValue.equals("*"))){
								logger.debug("Match found!!");
								matchedValue=(String)propValue;
								matchedListKeyValPairs.put(requestPropertyName, matchedValue);
								//break;
								//Leave this loop once a match is found
							}
						}
					}
				}
			}
			//Check if all the dependent props have been matched
			if(matchedListKeyValPairs.size()==dependentData.size()){
				//Remove any existing choicelist
				if(mainProperty.containsKey(EDSAttributes.ATTR_CHOICELIST))
					mainProperty.remove(EDSAttributes.ATTR_CHOICELIST);
				
				logger.debug("All Matches found, property("+overridePropertyName+") is being overriden WITH CHOICELIST");
				String choiceListProvClassName = (String) override.get(EDSAttributes.ATTR_PROVIDERCLASS);
				String choiceListName = (String) override.get(EDSAttributes.ATTR_PROVIDERATTR);
				EDSChoiceList implementedEDSChoicelist = (EDSChoiceList)Class.forName(choiceListProvClassName).newInstance();
				JSONObject choiceList = implementedEDSChoicelist.getChoicelist(choiceListName,matchedListKeyValPairs);
				
				if(choiceList!=null){
					mainProperty.put(EDSAttributes.ATTR_CHOICELIST, choiceList);
					//Set the def value if there is exactly one item
					JSONArray choices=(JSONArray)choiceList.get("choices");
					if(choices.size()==1){
						mainProperty.put(EDSAttributes.ATTR_VALUE, ((JSONObject)choices.get(0)).get(EDSAttributes.ATTR_VALUE));
					}else{
						
					}
					//If there is a choicelist, do NOT validate format
					if(mainProperty.containsKey(EDSAttributes.ATTR_FORMAT))
						mainProperty.remove(EDSAttributes.ATTR_FORMAT);
					if(mainProperty.containsKey(EDSAttributes.ATTR_FORMAT_DESCRIPTION))
						mainProperty.remove(EDSAttributes.ATTR_FORMAT_DESCRIPTION);
				}else{
					logger.debug("NULL choicelist. Removing dependencies and clearing value");
					//mainProperty.put(EDSAttributes.ATTR_VALUE, "");
					//Set choicelist to NULL - Change for 2.0.1.1 LA002
					mainProperty.put(EDSAttributes.ATTR_CHOICELIST, null);
					if(mainProperty.containsKey(EDSAttributes.ATTR_HASDEPENDENTPROPERTIES))
						mainProperty.remove(EDSAttributes.ATTR_HASDEPENDENTPROPERTIES);
					
				}
				mainProperty.put("choicelistmatched", true);
			}else{
				logger.debug("Incomplete match, generating empty choicelist");
				//Add an empty choicelist if nothing matched and the overrideproperty contains a choicelist
				/*JSONObject emptyChoiceList = new JSONObject();
				emptyChoiceList.put("displayName", "EmptyChoiceList");
				emptyChoiceList.put("choices", new JSONArray());
				mainProperty.put(EDSAttributes.ATTR_CHOICELIST, emptyChoiceList);*/
			}
		}else{
			logger.debug("No dependents..calling provider");
			//Regular choicelist evaluation
			String choiceListProvClassName = (String) override.get(EDSAttributes.ATTR_PROVIDERCLASS);
			String choiceListName = (String) override.get(EDSAttributes.ATTR_PROVIDERATTR);
			EDSChoiceList implementedEDSChoicelist = (EDSChoiceList)Class.forName(choiceListProvClassName).newInstance();
			JSONObject choiceList = implementedEDSChoicelist.getChoicelist(choiceListName,matchedListKeyValPairs);
			
			mainProperty.put(EDSAttributes.ATTR_CHOICELIST, choiceList);
		}
		
		return mainProperty;
	}
	
	/**
	 * 
	 * evalFinalLookupVal : Evaluates values to be passed on save of a new or existing object
	 * @param requestUser
	 * @param requestMode
	 * @param origReqProperties
	 * @param requestProperties
	 * @param mainProperty
	 * @param override
	 * @return
	 * @throws Exception
	 */
	public static  JSONObject evalFinalLookupVal(String requestUser, String requestMode, JSONArray origReqProperties,JSONArray  requestProperties,
			JSONObject mainProperty, JSONObject override) throws Exception{
		String overridePropertyName = mainProperty.get(EDSAttributes.ATTR_SYMBOLICNAME).toString();
		logger.debug("evalFinalLookupVal::OverridePropertyName::"+overridePropertyName);
		
		String lookupProvClassName = (String) override.get(EDSAttributes.ATTR_PROVIDERCLASS);
		String lookupAttrName = (String) override.get(EDSAttributes.ATTR_PROVIDERATTR);
		String[] criteriaProps = lookupAttrName.split(",");
		
		logger.debug("lookupProvClassName::"+lookupProvClassName);
		logger.debug("lookupAttrName::"+lookupAttrName);

		EDSLookUp implementedEDSLookup =null;
		HashMap<Integer, HashMap<String, String>> hm =null;
		
		//JSONArray dependentData = (JSONArray)override.get(EDSAttributes.ATTR_DEPENDENTCHILDREN);
		boolean depMatched= evalDependentMatch(origReqProperties, requestProperties, mainProperty,override,true);
		if(!depMatched) return mainProperty;
		
		String[] filterProps = new String[criteriaProps.length];
		String[] filterVals = new String[criteriaProps.length];
		String[] selectAttrs = {overridePropertyName};

		//Extract the current request property val
		for (int j = 0; j < requestProperties.size(); j++) {
			JSONObject requestProperty = (JSONObject)requestProperties.get(j);
			String requestPropertyName = requestProperty.get(EDSAttributes.ATTR_SYMBOLICNAME).toString();
			for (int i = 0; i < criteriaProps.length; i++) {
				if(requestPropertyName.equalsIgnoreCase(criteriaProps[i])){
					filterVals[i] = requestProperty.get(EDSAttributes.ATTR_VALUE).toString();
				}
			}
		}
		implementedEDSLookup = (EDSLookUp)Class.forName(lookupProvClassName).newInstance();
		try{
			hm= implementedEDSLookup.lookupData(requestUser, filterProps/*Filter Property Name*/, 
										filterVals /*Filter Property Values*/,null, 
										requestProperties,selectAttrs);
		}catch(Exception e){
			logger.error("Error in lookupData::",e);
			throw e;
		}
		if(hm.isEmpty()){
			logger.debug("No data was returned");
			//mainProperty.put(EDSAttributes.ATTR_CUSTOMVALIDATIONERROR, "Invalid " + Arrays.toString(filterProps));
			//mainProperty.put(EDSAttributes.ATTR_VALUE, overRideCurrentPropValue);
			//EDSException invalidLookup = new EDSException("Invalid " + filterProps[0]);
			//throw invalidLookup;
		}else{
			logger.debug("Valid lookup.Data was returned");
			//Operate on only the first row
			HashMap<String, String> lookedupValue = (HashMap<String, String>)hm.get(0);
			String lookedUpFinalVal = lookedupValue.get(selectAttrs[0]);
			logger.debug("Value returned was "+lookedUpFinalVal);
			mainProperty.put(EDSAttributes.ATTR_VALUE, lookedUpFinalVal);
		}
		
		return mainProperty;
	}
	
	/**
	 * 
	 * evalLookupVal: Retrieves an property value from a populated resultset
	 * @param populatedResultSets
	 * @param origReqProperties
	 * @param requestProperties
	 * @param mainProperty
	 * @param override
	 * @return
	 * @throws Exception
	 */
	public static  JSONObject evalLookupVal(HashMap<String, HashMap<Integer, HashMap<String, String>>> populatedResultSets,
			JSONArray origReqProperties, JSONArray requestProperties,JSONObject mainProperty,JSONObject override)throws Exception {
		String overridePropertyName = mainProperty.get(EDSAttributes.ATTR_SYMBOLICNAME).toString();
		
		logger.debug("evalLookupVal::OverridePropertyName::"+overridePropertyName);
	
		String lookupProvClassName = (String) override.get(EDSAttributes.ATTR_PROVIDERCLASS);
		String lookupAttrName = (String) override.get(EDSAttributes.ATTR_PROVIDERATTR);

		logger.debug("lookupProvClassName::"+lookupProvClassName);
		logger.debug("lookupAttrName::"+lookupAttrName);
		
		if(populatedResultSets!=null && populatedResultSets.containsKey(lookupProvClassName)){
			HashMap<Integer, HashMap<String, String>> lookupResultset = (HashMap<Integer, HashMap<String, String>>)populatedResultSets.get(lookupProvClassName) ;

			logger.debug("lookupResultset.size::"+lookupResultset.size());
			
			//Operate on only the first row
			HashMap<String, String> lookedupValues = (HashMap<String, String>)lookupResultset.get(0);
			//The Row could be null if the lookup returned 0 rows
			if(lookedupValues!=null && lookedupValues.containsKey(lookupAttrName)){
				logger.debug("evalLookupVal::Setting looked up value to ::"+(String)lookedupValues.get(lookupAttrName));
				mainProperty.put(EDSAttributes.ATTR_VALUE, (String)lookedupValues.get(lookupAttrName));
				//If the lookup worked may have to make the field RO
				if(override.containsKey(EDSAttributes.ATTR_READONLYONLOOKUP) && ((Boolean)override.get(EDSAttributes.ATTR_READONLYONLOOKUP))==true){
					mainProperty.put(EDSAttributes.ATTR_DISPLAYMODE, EDSAttributes.ATTR_DISPLAYMODE_READONLY);
					//If the dependent attribute is present, remove it
					if(mainProperty.containsKey(EDSAttributes.ATTR_HASDEPENDENTPROPERTIES))
						mainProperty.remove(EDSAttributes.ATTR_HASDEPENDENTPROPERTIES);
				}
			}else{
				logger.debug("evalLookupVal::!!! Attribute "+lookupAttrName+" missing in resultset``");
				mainProperty.put(EDSAttributes.ATTR_VALUE, "");
				//If it the readonlyonlookup attr is present, set it to RW
				if(override.containsKey(EDSAttributes.ATTR_READONLYONLOOKUP) && ((Boolean)override.get(EDSAttributes.ATTR_READONLYONLOOKUP))==true)
					mainProperty.put(EDSAttributes.ATTR_DISPLAYMODE, EDSAttributes.ATTR_DISPLAYMODE_READWRITE);
			}
			mainProperty.put("lookedup", true);
		}else{
			logger.debug("evalLookupVal::!!! Resultset not found in cache ::"+lookupProvClassName );
			//overRideProperty.put(EDSAttributes.ATTR_VALUE, overRidecurrentPropValue); 
		}
		
		return mainProperty;
	}

	/**
	 * 
	 * evalLookupResultset : Populates a resultset for use down the line
	 * @param origReqProperties
	 * @param requestProperties
	 * @param mainProperty
	 * @param overRide
	 * @return
	 * @throws Exception
	 */
	public static  HashMap<Integer, HashMap<String, String>>  evalLookupResultset(String requestUser,JSONArray origReqProperties, JSONArray requestProperties,JSONObject mainProperty,JSONObject overRide)throws Exception {
		String overridePropertyName = mainProperty.get(EDSAttributes.ATTR_SYMBOLICNAME).toString();
		String overRideCurrentPropValue ="";
		String providerAttribute = overRide.get(EDSAttributes.ATTR_PROVIDERATTR).toString();
		String[] criteriaProps = providerAttribute.split(",");
		ArrayList<String> ignoreProps = new ArrayList<String>();
		
		EDSLookUp implementedEDSLookup =null;
		String[] criteriaOrigPropValue = new String[criteriaProps.length];
		String[] criteriaCurrentPropValue =new String[criteriaProps.length];
		Boolean lookupNeeded =false;
		HashMap<Integer, HashMap<String, String>> hm =null;
		
		JSONArray dependentData = (JSONArray)overRide.get(EDSAttributes.ATTR_DEPENDENTCHILDREN);
		String[] filterProps = new String[criteriaProps.length];
		String[] filterVals = new String[criteriaProps.length];
		String[] selectAttrs = new String[dependentData.size()];
		
		logger.debug("OverridePropertyName::"+overridePropertyName);
	
		if(overRide.containsKey(EDSAttributes.ATTR_DEPENDENTS)){
			boolean dependentsMatched = evalDependentMatch(origReqProperties, requestProperties, mainProperty, overRide, true);
			if(!dependentsMatched){
				logger.debug("dependents did not match. returning null resultset");
				return null;
			}
		}
		
		//Do the lookup only if the value has changed from the original

		//Extract the current request property val
		for (int j = 0; j < requestProperties.size(); j++) {
			JSONObject requestProperty = (JSONObject)requestProperties.get(j);
			String requestPropertyName = requestProperty.get(EDSAttributes.ATTR_SYMBOLICNAME).toString();
			for (int i = 0; i < criteriaProps.length; i++) {
				if(requestPropertyName.equalsIgnoreCase(criteriaProps[i])){
					criteriaCurrentPropValue[i] = requestProperty.get(EDSAttributes.ATTR_VALUE).toString();
				}
				if(requestPropertyName.equalsIgnoreCase(overridePropertyName)){
					overRideCurrentPropValue= requestProperty.get(EDSAttributes.ATTR_VALUE).toString();	
				}
			}
		}
		
		//Extract the original request property value
		for (int j = 0; j < origReqProperties.size(); j++) {
			JSONObject origRequestProperty = (JSONObject)origReqProperties.get(j);
			logger.debug("Iterating property at index "+ j);
			if(origRequestProperty==null){
				logger.warn("Property at index "+j+" is null)");
				continue;
			}
			String origRequestPropertyName = origRequestProperty.get(EDSAttributes.ATTR_SYMBOLICNAME).toString();
			logger.debug("JSON for original request prop::"+origRequestProperty.toString());
			logger.debug("Searching for "+origRequestPropertyName);
			boolean foundOrigProp =false;
			for (int i = 0; i < criteriaProps.length; i++) {
				//Check if the property value has changed and the property has dependant props
				if(origRequestPropertyName.equalsIgnoreCase(criteriaProps[i])){
					foundOrigProp=true;
					logger.debug("Found "+origRequestPropertyName);
					if(origRequestProperty.get(EDSAttributes.ATTR_VALUE)!=null){
						logger.debug("Value is "+origRequestProperty.get(EDSAttributes.ATTR_VALUE).toString());
						criteriaOrigPropValue[i] = origRequestProperty.get(EDSAttributes.ATTR_VALUE).toString();
					}else{
						logger.debug("Value is NULL");
						criteriaOrigPropValue[i] = "";
					}
				}					
			}
			//If the property was not part of the original request, add to ignore List
			if(!foundOrigProp){
				logger.debug("Adding to ignore list::"+origRequestPropertyName);
				ignoreProps.add(origRequestPropertyName);
			}
		}
		logger.debug("Property Criteria Names ::" + Arrays.toString(criteriaProps));
		logger.debug("Original Property Criteria Values ::" + Arrays.toString(criteriaOrigPropValue));
		logger.debug("Current  Property Criteria Values ::" + Arrays.toString(criteriaCurrentPropValue));
		
		for (int i = 0; i < criteriaProps.length; i++) {
			//NOTE::May have to add config for non-case sensitive comparision
			
			//If the property was not present in the in the original request, its dependency may have been removed 
			if(criteriaOrigPropValue[i]!=null){
				if(!criteriaOrigPropValue[i].equalsIgnoreCase(criteriaCurrentPropValue[i])){
					logger.debug("Property "+criteriaProps[i] + " has changed");
					logger.debug("Original Value "+criteriaOrigPropValue[i] );
					logger.debug("Current Value "+criteriaCurrentPropValue[i]);
					lookupNeeded=true;
				}
			}else{
				//If it is null, set it to emtpy to avoid errors down the line
				criteriaOrigPropValue[i]="";
			}
			filterProps[i]=criteriaProps[i];
			filterVals[i]=criteriaCurrentPropValue[i];
		}
		
		if(lookupNeeded){
			for (int cntDependents = 0; cntDependents < dependentData.size(); cntDependents++) {
				JSONObject dependentProp = (JSONObject)dependentData.get(cntDependents);
				String dependentPropName = dependentProp.get("dependentChild").toString();
				selectAttrs[cntDependents]= dependentPropName;			
				
			}
			logger.debug("Lookup is being executed");
			String lookupProvClassName = (String) overRide.get(EDSAttributes.ATTR_PROVIDERCLASS);
			logger.debug("Lookup class is " + lookupProvClassName );
			logger.debug("filterProps ::" + Arrays.toString(filterProps));
			logger.debug("filterVals ::" + Arrays.toString(filterVals));
			logger.debug("selectAttrs ::" + Arrays.toString(selectAttrs));
			//String lookupAttrName = (String) overRideProperty.get(EDSAttributes.ATTR_PROVIDERATTR);
			implementedEDSLookup = (EDSLookUp)Class.forName(lookupProvClassName).newInstance();
			try{
				hm= implementedEDSLookup.lookupData(requestUser,filterProps/*Filter Property Name*/, 
											filterVals /*Filter Property Values*/, criteriaOrigPropValue /*Filter Original Property Values*/,
										requestProperties,	
										selectAttrs);
			}catch(Exception e){
				logger.error("Error in lookupData::",e);
				throw e;
			}
			if(hm.isEmpty()){
				logger.debug("No data was returned");
				//mainProperty.put(EDSAttributes.ATTR_CUSTOMVALIDATIONERROR, "No Matches Found for " + Arrays.toString(filterProps));
				//mainProperty.put(EDSAttributes.ATTR_VALUE, overRideCurrentPropValue);
				//EDSException invalidLookup = new EDSException("Invalid " + filterProps[0]);
				//throw invalidLookup;
			}else{
				logger.debug("Valid lookup.Data was returned");
			
				if(hm.get(0).containsKey(EDSAttributes.ATTR_CUSTOMVALIDATIONERROR)){
					logger.debug("Validation Error returned in lookup");
					mainProperty.put(EDSAttributes.ATTR_CUSTOMVALIDATIONERROR, hm.get(0).get(EDSAttributes.ATTR_CUSTOMVALIDATIONERROR));
					logger.debug("Validation Error returned in lookup " + hm.get(0).get(EDSAttributes.ATTR_CUSTOMVALIDATIONERROR));
				}
				//mainProperty.put(EDSAttributes.ATTR_VALUE, overRideCurrentPropValue);
			}
		}else{
			logger.debug("Lookup is NOT required");
			mainProperty.put(EDSAttributes.ATTR_VALUE, overRideCurrentPropValue); 
		}
		
		return hm;
	}
	
	/**
	 * 
	 * evalRequiredField : Evaluates if a field is required based on other property values
	 * @param requestMode
	 * @param origReqProperties
	 * @param requestProperties
	 * @param mainProperty
	 * @param override
	 * @return
	 * @throws Exception
	 */
	public static JSONObject evalRequiredField(String requestMode,JSONArray origReqProperties, JSONArray requestProperties,JSONObject mainProperty,JSONObject override,EDSOverrideTypes requiredOrNot)throws Exception {
		String overridePropertyName = mainProperty.get(EDSAttributes.ATTR_SYMBOLICNAME).toString();
		Object currPropValue = null;
		Boolean dependentsMatched =false;
		
		logger.debug("evalRequiredField for OverridePropertyName::"+overridePropertyName);
		logger.debug("requestMode::"+requestMode);

		//If the required flag was already set, return right away
		if(mainProperty.containsKey(EDSAttributes.ATTR_REQUIRED) && ((Boolean)mainProperty.get(EDSAttributes.ATTR_REQUIRED))==true)
			return mainProperty;
		
		//Extract the current request property val
		for (int j = 0; j < requestProperties.size(); j++) {
			JSONObject requestProperty = (JSONObject)requestProperties.get(j);
			String requestPropertyName = requestProperty.get(EDSAttributes.ATTR_SYMBOLICNAME).toString();
			if(requestPropertyName.equalsIgnoreCase(overridePropertyName)){
				currPropValue= requestProperty.get(EDSAttributes.ATTR_VALUE);
				break;
			}
		}
		
		//Evaluate only if the value has changed from the original
		dependentsMatched = evalDependentMatch(origReqProperties, requestProperties, mainProperty,override,true);
		logger.debug("dependentsMatched::"+dependentsMatched);
		
		if(dependentsMatched){
			if(requiredOrNot==EDSOverrideTypes.REQUIRED)
				mainProperty.put(EDSAttributes.ATTR_REQUIRED, true);
			else
				mainProperty.put(EDSAttributes.ATTR_REQUIRED, false);
			//For Final Objects, force a validation error if required fields slipped through
			if((requestMode.equals(EDSAttributes.REQMODE_FINALNEWOBJECT) || requestMode.equals(EDSAttributes.REQMODE_FINALEXISTINGOBJECT))
					&& (currPropValue==null || currPropValue.toString().isEmpty()))
				mainProperty.put(EDSAttributes.ATTR_CUSTOMVALIDATIONERROR,"Value is Required for "+overridePropertyName);
				//mainProperty.put(EDSAttributes.ATTR_HASDEPENDENTPROPERTIES,true);
		}else{
			if(requiredOrNot==EDSOverrideTypes.REQUIRED)
				mainProperty.put(EDSAttributes.ATTR_REQUIRED, false);
			else
				mainProperty.put(EDSAttributes.ATTR_REQUIRED, true);
		}
		
		return mainProperty;
	}

	/**
	 * 
	 * evalReadOnlyField : Evaluates the DisplayMode based on other property values 
	 * @param requestMode
	 * @param origReqProperties
	 * @param requestProperties
	 * @param mainProperty
	 * @param override
	 * @return
	 * @throws Exception
	 */
	public static JSONObject evalReadOnlyField(String requestMode,JSONArray origReqProperties, JSONArray requestProperties,JSONObject mainProperty,JSONObject override)throws Exception {
		String overridePropertyName = mainProperty.get(EDSAttributes.ATTR_SYMBOLICNAME).toString();
		Boolean valueIsReadOnly =false;

		logger.debug("evalReadOnlyField for OverridePropertyName::"+overridePropertyName);
		logger.debug("requestMode::"+requestMode);
		
		//Evaluate only if the value has changed from the original
		valueIsReadOnly = evalDependentMatch(origReqProperties, requestProperties, mainProperty,override,true);
		logger.debug("valueIsReadOnly::"+valueIsReadOnly);
		if(valueIsReadOnly){
			mainProperty.put(EDSAttributes.ATTR_DISPLAYMODE, EDSAttributes.ATTR_DISPLAYMODE_READONLY);
		}else{
			mainProperty.put(EDSAttributes.ATTR_DISPLAYMODE, EDSAttributes.ATTR_DISPLAYMODE_READWRITE);
		}
		
		return mainProperty;
	}

	/**
	 * 
	 * evalHiddenField : Evaluates the Hidden status of a property
	 * @param requestMode
	 * @param origReqProperties
	 * @param requestProperties
	 * @param mainProperty
	 * @param override
	 * @return
	 * @throws Exception
	 */
	public static JSONObject evalHiddenField(String requestMode,JSONArray origReqProperties, JSONArray requestProperties,JSONObject mainProperty,JSONObject override)throws Exception {
		String overridePropertyName = mainProperty.get(EDSAttributes.ATTR_SYMBOLICNAME).toString();
		Boolean fieldIsHidden =false;
		Boolean matchFound =true;
		
		logger.debug("evalReadOnlyField for OverridePropertyName::"+overridePropertyName);
		logger.debug("requestMode::"+requestMode);
		
		//Evaluate only if the value has changed from the original
		matchFound = evalDependentMatch(origReqProperties, requestProperties, mainProperty,override,true);
		if(matchFound){
			if(override.containsKey(EDSAttributes.ATTR_PROVIDERCLASS)){
				String edsHiddenProviderClass = (String)override.get(EDSAttributes.ATTR_PROVIDERCLASS);
				HashMap<String, String> dependents= getDependentKeyVals(requestProperties, override);
				EDSHiddenField edsHiddenProvider = (EDSHiddenField)Class.forName(edsHiddenProviderClass).newInstance();
				fieldIsHidden=edsHiddenProvider.getHiddenStatus(overridePropertyName, dependents);
			}else{
				fieldIsHidden=true;
			}
		}
		
		logger.debug("fieldIsHidden::"+fieldIsHidden);
		if(mainProperty.containsKey(EDSAttributes.ATTR_HIDDEN) && ((Boolean)mainProperty.get(EDSAttributes.ATTR_HIDDEN))==true){
			logger.debug("field Is Already Hidden so returning ");
			return mainProperty;
		}
		
		if(fieldIsHidden){
			mainProperty.put(EDSAttributes.ATTR_HIDDEN, true);
		}else{
			mainProperty.put(EDSAttributes.ATTR_HIDDEN, false);
		}
		
		return mainProperty;
	}

	/**
	 * 
	 * evalValidation : Invokes a custom validation
	 * @param requestMode
	 * @param origReqProperties
	 * @param requestProperties
	 * @param mainProperty
	 * @param override
	 * @return
	 * @throws Exception
	 */
	public static JSONObject evalValidation(String requestMode,JSONArray origReqProperties, JSONArray requestProperties,JSONObject mainProperty,JSONObject override)throws Exception {
		String overridePropertyName = mainProperty.get(EDSAttributes.ATTR_SYMBOLICNAME).toString();
		String validatonMessage =null;
		Boolean matchFound =true;
		
		logger.debug("evalValidation for OverridePropertyName::"+overridePropertyName);
		logger.debug("requestMode::"+requestMode);
		
		//Evaluate only if the value has changed from the original
		matchFound = evalDependentMatch(origReqProperties, requestProperties, mainProperty,override,true);
		if(matchFound){
			if(override.containsKey(EDSAttributes.ATTR_PROVIDERCLASS)){
				String edsValidationProviderClass = (String)override.get(EDSAttributes.ATTR_PROVIDERCLASS);
				String edsValidationMessage = (String)override.get(EDSAttributes.ATTR_PROVIDERATTR);
				HashMap<String, String> dependents= getDependentKeyVals(requestProperties, override);
				EDSValidator edsValidationProvider = (EDSValidator)Class.forName(edsValidationProviderClass).newInstance();
				validatonMessage = edsValidationProvider.getValidationStatus(overridePropertyName, dependents,edsValidationMessage);
			}
		}
		
		
		logger.debug("validatonMessage::"+validatonMessage);
		
		if(validatonMessage!=null && !validatonMessage.isEmpty()){
			mainProperty.put(EDSAttributes.ATTR_CUSTOMVALIDATIONERROR, validatonMessage);
		}
		
		return mainProperty;
	}

	
	/**
	 * 
	 * evalDependentMatch : Helper function to evaluate if any/all dependent properties matched
	 * @param origReqProperties
	 * @param requestProperties
	 * @param mainProperty
	 * @param override
	 * @param matchAllDependents
	 * @return
	 * @throws Exception
	 */
	
	// origReqProperties: is here just for future proof
	public static boolean evalDependentMatch(JSONArray origReqProperties, JSONArray requestProperties,
			JSONObject mainProperty,JSONObject override,boolean matchAllDependents)throws Exception {
		String overridePropertyName = mainProperty.get(EDSAttributes.ATTR_SYMBOLICNAME).toString();
		Object currDepPropValue = null;
		Object currPropValue = null;
		Boolean hasDependentMatch =false;
		int matchCount=0;
		
		Boolean depPropFound =false;
		
		logger.debug("OverridePropertyName::"+overridePropertyName);
		
		//Evaluate only if the value has changed from the original
		JSONArray dependentData = (JSONArray)override.get(EDSAttributes.ATTR_DEPENDENTS);
		
		if(dependentData==null){
			logger.warn("Dependents node does not exist");
			return false;
		}
		
		for (int cntDependents = 0; cntDependents < dependentData.size(); cntDependents++) {
			JSONObject dependentProp = (JSONObject)dependentData.get(cntDependents);
			String dependentOn = dependentProp.get(EDSAttributes.ATTR_DEPENDENTON).toString();
			//We are storing in an array to reduce json size
			String[] dependentValueArr = dependentProp.get(EDSAttributes.ATTR_DEPENDENTVALUES).toString().split(",");
			
			//Extract the current request property val
			for (int j = 0; j < requestProperties.size(); j++) {
				JSONObject requestProperty = (JSONObject)requestProperties.get(j);
				String requestPropertyName = requestProperty.get(EDSAttributes.ATTR_SYMBOLICNAME).toString();
				if(requestPropertyName.equalsIgnoreCase(dependentOn)){
					currDepPropValue = requestProperty.get(EDSAttributes.ATTR_VALUE);
					depPropFound = true;
				}
				
				if(requestPropertyName.equalsIgnoreCase(overridePropertyName)){
					currPropValue= requestProperty.get(EDSAttributes.ATTR_VALUE);
				}
			}

			logger.debug("Dependent Property Name ::" + dependentOn);
			logger.debug("Current Dependent Property Value ::" + currDepPropValue);

			//Old Workflow versions may not have new properties
			if (!depPropFound){
				logger.debug("Property ::" + dependentOn + " was not found and evaluation is being terminated");
				break;
			}
			
			for (int k = 0; k < dependentValueArr.length; k++) {
				String dependentValue = dependentValueArr[k];
				logger.debug("Compare with configured Value ::" + dependentValue);
				if(currDepPropValue!=null)
					logger.debug("Current Dependent Property Value Class ::" + currDepPropValue.getClass());
				//Workflow Responses are String Arrays
				if(currDepPropValue instanceof JSONArray){
					JSONArray values = (JSONArray) currDepPropValue;
					logger.debug("currDepPropValue ::" + currDepPropValue.toString());
					for (int i = 0; i < values.size(); i++) {
						logger.debug("dependentValue ::" + dependentValue);
						logger.debug("values[i] ::" + values.get(i).toString());
						if(dependentValue.equals(values.get(i).toString())){
							logger.debug("values.get(i).toString()::"+values.get(i).toString()+" dependentValue::"+dependentValue);
							logger.debug("Match found!!");
							hasDependentMatch=true;
							matchCount++;
							break;
						}
					}
				}else if (dependentValue.equals(currDepPropValue) ||  dependentValue.equals("*")) {
					logger.debug("propValue::"+currDepPropValue+" dependentValue::"+dependentValue);
					logger.debug("Match found!!");
					hasDependentMatch=true;
					matchCount++;
					break;
					//Leave this loop once a match is found
				}
			}
		}

		//If all matches were needed and not found
		if(matchAllDependents && matchCount!=dependentData.size())
			 hasDependentMatch=false;
		
		return hasDependentMatch;
	}

	/**
	 * 
	 * getDependentKeyVals : Helper function to get the key-value pairs of dependent properties
	 * @param requestProperties
	 * @param override
	 * @return
	 * @throws Exception
	 */
	
	public static HashMap<String, String> getDependentKeyVals(JSONArray requestProperties,JSONObject override)throws Exception {
		logger.debug("Entering::getDependentKeyVals");

		String currDepPropValue = null;
		HashMap<String, String> dependents = new HashMap<String, String>();
		
		//Evaluate only if the value has changed from the original
		JSONArray dependentData = (JSONArray)override.get(EDSAttributes.ATTR_DEPENDENTS);
		
		for (int cntDependents = 0; cntDependents < dependentData.size(); cntDependents++) {
			JSONObject dependentProp = (JSONObject)dependentData.get(cntDependents);
			String dependentOn = dependentProp.get(EDSAttributes.ATTR_DEPENDENTON).toString();
			
			//Extract the current request property val
			for (int j = 0; j < requestProperties.size(); j++) {
				JSONObject requestProperty = (JSONObject)requestProperties.get(j);
				String requestPropertyName = requestProperty.get(EDSAttributes.ATTR_SYMBOLICNAME).toString();
				if(requestPropertyName.equalsIgnoreCase(dependentOn)){
					if(requestProperty.get(EDSAttributes.ATTR_VALUE) instanceof JSONArray){
						JSONArray arr = (JSONArray)requestProperty.get(EDSAttributes.ATTR_VALUE);
						currDepPropValue = arr.toString();
					}else{
						currDepPropValue = (String)requestProperty.get(EDSAttributes.ATTR_VALUE);
					}
					dependents.put(requestPropertyName, currDepPropValue);
				}
			}

		}

		return dependents;
	}

	/**
	 * 
	 * evalDefaultVal : Evaluates the default value of a property based on dependents
	 * @param requestMode
	 * @param origReqProperties
	 * @param requestProperties
	 * @param mainProperty
	 * @param override
	 * @return
	 * @throws Exception
	 */
	public static JSONObject evalDefaultVal(String requestUserid, String requestMode,JSONArray origReqProperties, JSONArray requestProperties,JSONObject mainProperty,JSONObject override)throws Exception {
		logger.debug("Entering evalDefaultVal");
		String overridePropertyName = mainProperty.get(EDSAttributes.ATTR_SYMBOLICNAME).toString();
		String overideDefaultFormula = override.get(EDSAttributes.ATTR_DEFAULTVALUE).toString();
		
		logger.debug("setDefaultValue for OverridePropertyName::"+overridePropertyName);
		logger.debug("setDefaultValue with OverideDefaultFormula::"+overideDefaultFormula); 
		logger.debug("requestMode::"+requestMode);
		logger.debug("requestUserid::"+requestUserid);
		
		boolean depMatched= true;
		
		//Eval Dependents if present
		if((JSONArray)override.get(EDSAttributes.ATTR_DEPENDENTS)!=null)
			depMatched = evalDependentMatch(origReqProperties, requestProperties, mainProperty,override,true);

		//If dependents matched or dependents not present
		if(depMatched){
			//Populate always
			switch (EDSOverrideValues.valueOf(overideDefaultFormula)){
				case CURRENTUSERNAME:
					logger.debug("CURRENTUSERNAME override formula matched");
					logger.debug("requestUserid="+requestUserid);
					if(requestUserid.isEmpty()) return mainProperty;
					
					String fullNameAttrs = EDSProperties.edsProperties.getProperty("LDAP_USERFULLNAME_ATTR");
					String [] fullName = fullNameAttrs.split(",");
					LDAPSearch userSearch = new LDAPSearch();
					String[] userAttrs = userSearch.findUserByAccountName(requestUserid, fullName);
					if(mainProperty.containsKey(EDSAttributes.ATTR_VALUE))
						mainProperty.remove(EDSAttributes.ATTR_VALUE);
					mainProperty.put(EDSAttributes.ATTR_VALUE, userAttrs[1]+", "+userAttrs[0]);
					logger.debug("overrideProperty::"+mainProperty.toString());
					break;
				case CURRENTUSERID:
					if(mainProperty.containsKey(EDSAttributes.ATTR_VALUE))
						mainProperty.remove(EDSAttributes.ATTR_VALUE);
					mainProperty.put(EDSAttributes.ATTR_VALUE, requestUserid);
					break;
				case CURRENTUSEREMAIL:
					String eMailAttr = EDSProperties.edsProperties.getProperty("LDAP_USEREMAIL_ATTR");
					String [] emailAttrs = eMailAttr.split(",");
					LDAPSearch userEmailSearch = new LDAPSearch();
					String[] userEmailAttrs = userEmailSearch.findUserByAccountName(requestUserid, emailAttrs);
					if(mainProperty.containsKey(EDSAttributes.ATTR_VALUE))
						mainProperty.remove(EDSAttributes.ATTR_VALUE);
					mainProperty.put(EDSAttributes.ATTR_VALUE, (userEmailAttrs[0].equalsIgnoreCase("NULL")?"None":userEmailAttrs[0]));
					logger.debug("overrideProperty::"+mainProperty.toString());
					break;
				case CURRENTUSERGROUPS:
				case CURRENTUSERGROUPSARRAY:
					logger.debug("CURRENTUSERGROUPS override formula matched");
					logger.debug("requestUserid="+requestUserid);
					if(requestUserid.isEmpty()) return mainProperty;
					
					String ldapGroups = EDSProperties.edsProperties.getProperty("ALL_LDAP_GROUPS");
					String[] strs;
					
					LDAPSearch userSearch1 = new LDAPSearch();
					String userCommaDelimGroups = userSearch1.findUserGroupsByAccountName(requestUserid,ldapGroups);
					if(mainProperty.containsKey(EDSAttributes.ATTR_VALUE))
						mainProperty.remove(EDSAttributes.ATTR_VALUE);
					if(EDSOverrideValues.valueOf(overideDefaultFormula)==EDSOverrideValues.CURRENTUSERGROUPS)
						mainProperty.put(EDSAttributes.ATTR_VALUE, userCommaDelimGroups);
					else{
						JSONArray grps = new JSONArray();
						grps.addAll(Arrays.asList(userCommaDelimGroups.split(",")));
						mainProperty.put(EDSAttributes.ATTR_VALUE, grps);
					}
					logger.debug("overrideProperty::"+mainProperty.toString());
					break;			
				default:
					logger.debug("No default value override formula matched");
					mainProperty.put(EDSAttributes.ATTR_VALUE, overideDefaultFormula);
					break;
			}
		}
		return mainProperty;
	}
	
	/**
	 * 
	 * evalDefaultInitialVal : Evaluate the initial value of a property
	 * @param mainProperty
	 * @param override
	 * @param requestProperties
	 * @return
	 * @throws Exception
	 */
	public static JSONObject evalDefaultInitialVal(JSONObject mainProperty,JSONObject override, JSONArray requestProperties)throws Exception {
		logger.debug("Initial value is being set");
		//Evaluate Macros
		if(override.containsKey(EDSAttributes.ATTR_INITIALVALUE)){
			String overRideValueFormula = override.get("initialValue").toString();
			String overRideType = (String)override.get("overrideType");
			String currPropValue="";
			String overridePropertyName = mainProperty.get(EDSAttributes.ATTR_SYMBOLICNAME).toString();
			logger.debug("overRideValueFormula::"+overRideValueFormula);
			logger.debug("overRideType::"+overRideType);
			logger.debug("EDSOverrideTypes.DEFAULTVALUE.toString()::"+EDSOverrideTypes.DEFAULTVALUE.toString());

			//Extract the current request property val
			for (int j = 0; j < requestProperties.size(); j++) {
				JSONObject requestProperty = (JSONObject)requestProperties.get(j);
				String requestPropertyName = requestProperty.get(EDSAttributes.ATTR_SYMBOLICNAME).toString();
				if(requestPropertyName.equalsIgnoreCase(overridePropertyName)){
					currPropValue = (String)requestProperty.get(EDSAttributes.ATTR_VALUE);
					//dependents.put(requestPropertyName, currDepPropValue);
				}
			}

			//Populate a new value only if the original was empty
			if(currPropValue==null || currPropValue.isEmpty()){
				switch (EDSOverrideValues.valueOf(overRideValueFormula)){
					case TODAY:
						logger.debug("TODAY override formula matched");
						SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
						String todayStr = dateFormat.format(new Date());
						if(mainProperty.containsKey(EDSAttributes.ATTR_VALUE))
							mainProperty.remove(EDSAttributes.ATTR_VALUE);
						mainProperty.put(EDSAttributes.ATTR_VALUE, todayStr);
						logger.debug("overrideProperty::"+mainProperty.toString());
						break;
					default:
						logger.debug("No default value override formula matched");
						mainProperty.put(EDSAttributes.ATTR_VALUE, overRideValueFormula);
						break;
				}
			}else{
				logger.debug("Current value is present::"+currPropValue);
			}
		}
		return mainProperty;
	}

	/**
	 * 
	 * evalFormattedVal : Returns the current value formatted by a custom format class
	 * @param requestMode
	 * @param origReqProperties
	 * @param requestProperties
	 * @param mainProperty
	 * @param override
	 * @return
	 * @throws Exception
	 */
	public static JSONObject evalFormattedVal(String requestMode,JSONArray origReqProperties, JSONArray requestProperties,JSONObject mainProperty,JSONObject override)throws Exception {
		logger.debug("Formatter value is being set ");
		String overridePropertyName = mainProperty.get(EDSAttributes.ATTR_SYMBOLICNAME).toString();
		logger.debug("evalFormattedVal for OverridePropertyName::"+overridePropertyName);
		logger.debug("requestMode::"+requestMode);
		
		String lookupProvClassName = (String) override.get(EDSAttributes.ATTR_PROVIDERCLASS);
		logger.debug("Formatter class is " + lookupProvClassName );
		EDSFormatter implementedEDSFormatter = (EDSFormatter)Class.forName(lookupProvClassName).newInstance();
		Object currPropValue=null;
		
		if(mainProperty.containsKey(EDSAttributes.ATTR_VALUE)){
			//The value was already set by an Override
			currPropValue = (String)mainProperty.get(EDSAttributes.ATTR_VALUE);
		}else{
			//Extract the current request property val
			for (int j = 0; j < requestProperties.size(); j++) {
				JSONObject requestProperty = (JSONObject)requestProperties.get(j);
				String requestPropertyName = requestProperty.get(EDSAttributes.ATTR_SYMBOLICNAME).toString();
				if(requestPropertyName.equalsIgnoreCase(overridePropertyName) && (requestProperty.get(EDSAttributes.ATTR_VALUE) instanceof String)){
					currPropValue = (String)requestProperty.get(EDSAttributes.ATTR_VALUE);
					break;
				}
			}
		}
		
		try{
			String formattedVal = implementedEDSFormatter.getFormattedValue(requestMode,overridePropertyName, currPropValue);
			mainProperty.put(EDSAttributes.ATTR_VALUE, formattedVal);
		}catch(Exception e){
			logger.error("Error in lookupData::",e);
			throw e;
		}

		return mainProperty;
	}
}
