package com.ibm.icn.custom.agcs.eds;

import java.util.ArrayList;

import java.util.Date;
import java.util.HashMap;
import org.apache.log4j.Logger;


import com.ibm.icn.custom.eds.common.EDSChoiceList;
import com.ibm.icn.custom.eds.common.EDSProperties;
import com.ibm.icn.custom.eds.providers.LDAPSearch;
import com.ibm.json.java.JSONArray;
import com.ibm.json.java.JSONObject;

public class AGCSUserListProvider extends EDSChoiceList{
	public static Date lastRetrieved;
	//public static HashMap<String, ArrayList<String[]>>  cachedUsersList;
	private String[] memberAttrs = {"sAMAccountName","givenName","sn"};
	private Logger logger;
	
	public AGCSUserListProvider() {
		logger = Logger.getLogger(AGCSUserListProvider.class.getName());
	}
	
	@Override
	public JSONObject getChoicelist(String configGroupName,HashMap<String, String> matchedListKeyValPairs) throws Exception {

		String groupName=null;
		ArrayList<String[]> arrUsers=null;
		JSONObject jsonChoicelist= new JSONObject();
		JSONArray jsonChoices = new JSONArray();
		jsonChoicelist.put("displayName", "GroupMembers_"+configGroupName);
		
/*		if(cachedUsersList==null)
			cachedUsersList = new HashMap<String, ArrayList<String[]>>();
*/		
		//Lookup the actual CN Name
		groupName = EDSProperties.edsProperties.getProperty(configGroupName);
		if(groupName==null || groupName.isEmpty())
			throw new Exception("LDAP Group CN not configured for " + configGroupName);
		
		if(!LDAPSearch.getCachedUsersList().containsKey(groupName)){
			logger.debug("Group not in cache. Calling getGroupMembers");
			LDAPSearch ldapSearch = new LDAPSearch();
			arrUsers = ldapSearch.getGroupMembers(groupName,memberAttrs);
		}else{
			logger.debug("Group found in cache. ");
			arrUsers = LDAPSearch.getCachedUsersList().get(groupName);
		}
		if(arrUsers!=null){
			for (int i = 0; i < arrUsers.size(); i++) {
				JSONObject oneChoice = new JSONObject();
				String[] attrVals = arrUsers.get(i);
				oneChoice.put("value", attrVals[0]);
				oneChoice.put("displayName", attrVals[2]+", "+attrVals[1]);
				jsonChoices.add(oneChoice);
			}
		}else{
			logger.error("Users arraylist is null for Group::" + groupName);
		}
		jsonChoicelist.put("choices", jsonChoices);	
		LDAPSearch.addToCachedUsersList(groupName, arrUsers);
			
		return jsonChoicelist;
	}


	@Override
	public boolean clearCaches() throws Exception {
		logger.debug("Entering clearCache");
		LDAPSearch.clearCaches();
		return true;
	}
}
