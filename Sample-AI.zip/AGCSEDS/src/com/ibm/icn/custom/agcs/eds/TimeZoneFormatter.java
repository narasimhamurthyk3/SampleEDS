/**
 * @author Philip
 *
 */
package com.ibm.icn.custom.agcs.eds;

import org.apache.log4j.Logger;

import com.ibm.icn.custom.eds.common.EDSAttributes;
import com.ibm.icn.custom.eds.common.EDSFormatter;
import com.ibm.icn.custom.eds.common.EDSProperties;
import com.ibm.icn.custom.eds.servlets.UpdateObjectTypeServlet;

/**
 * @author Philip
 *
 */
public class TimeZoneFormatter extends EDSFormatter {

Logger logger ;
	
	public TimeZoneFormatter() {
		logger = Logger.getLogger(UpdateObjectTypeServlet.class.getName());
	}
	
	
	/* (non-Javadoc)
	 * @see com.ibm.icn.custom.eds.common.EDSFormatter#getFormattedValue(java.lang.String, java.lang.Object)
	 */
	@Override
	public String getFormattedValue(String requestMode,String propertyName, Object propertyValue)
			throws Exception {
		
		if(!requestMode.equalsIgnoreCase(EDSAttributes.REQMODE_FINALNEWOBJECT) && !requestMode.equalsIgnoreCase(EDSAttributes.REQMODE_FINALEXISTINGOBJECT))
			return (String)propertyValue;
		
		if(propertyValue==null || ((String)propertyValue).isEmpty())
			return "";
		else{
			String newTime="";
			String oldTime=(String)propertyValue;
			logger.debug("OldTime::"+oldTime);
			
			newTime = oldTime.substring(0, oldTime.indexOf("T", 0)+1);
			//"2013-03-12T05:00:00Z
			//2013-03-26T00:00:00-05:00
			//Set the time to 11 PM hour at GMT
			String newTimeStr = EDSProperties.edsProperties.getProperty("AGCS_STD_TIMEANDZONE");
			newTime += newTimeStr; //"23:00:00-00:00";
			
			logger.debug("NewTime::"+newTime);
			
			return newTime;	
		}
		
	}

}
