package com.ibm.icn.custom.agcs.eds;

import java.io.File;
import java.io.InputStream;
import java.util.HashMap;

import org.apache.log4j.Logger;

import com.ibm.icn.custom.eds.common.EDSChoiceList;
import com.ibm.json.java.JSONObject;

public class ChoicelistProvider extends EDSChoiceList{
	Logger logger;

	public ChoicelistProvider() {
		logger = Logger.getLogger(ChoicelistProvider.class.getName()); 
	}
	@Override
	public JSONObject getChoicelist(String choicelistName,HashMap<String, String> matchedListKeyValPairs) throws Exception{
		//This provider tries to read the choicelist from a JSON file
		JSONObject choicelist=null;
		String choiceListFile="WEB-INF"+File.separator+"choicelists"+File.separator+choicelistName+".json";
		logger.debug("Attempting to get choicelist file "+ choiceListFile);
		InputStream objectTypesStream = getClass().getClassLoader().getResourceAsStream(choiceListFile);
		try{
			choicelist=JSONObject.parse(objectTypesStream);
		}catch(Exception e){
			e.printStackTrace();
			throw e;
		}
		return choicelist;
	}
	@Override
	public boolean clearCaches() throws Exception {
		//Not caching anything
		return true;
	}
}
