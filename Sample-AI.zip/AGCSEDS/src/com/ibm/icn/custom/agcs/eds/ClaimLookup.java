package com.ibm.icn.custom.agcs.eds;

import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;

import org.apache.log4j.Logger;

import com.filenet.api.collection.IndependentObjectSet;
import com.filenet.api.constants.FilteredPropertyType;
import com.filenet.api.core.Connection;
import com.filenet.api.core.Document;
import com.filenet.api.core.Domain;
import com.filenet.api.core.Factory;
import com.filenet.api.core.ObjectStore;
import com.filenet.api.property.FilterElement;
import com.filenet.api.property.Property;
import com.filenet.api.property.PropertyDateTime;
import com.filenet.api.property.PropertyFilter;
import com.filenet.api.property.PropertyString;
import com.filenet.api.query.SearchSQL;
import com.filenet.api.query.SearchScope;
import com.filenet.api.util.UserContext;

import com.ibm.icn.custom.eds.common.EDSLookUp;
import com.ibm.icn.custom.eds.common.EDSProperties;
import com.ibm.icn.custom.eds.servlets.UpdateObjectTypeServlet;
import com.ibm.json.java.JSONArray;

public class ClaimLookup extends EDSLookUp {
	HashMap<Integer, HashMap<String, String>>  retHashMap = new HashMap<Integer, HashMap<String, String>>();
	Logger logger ;
	
	public ClaimLookup() {
		logger = Logger.getLogger(UpdateObjectTypeServlet.class.getName());
	}
	
	@Override
	public HashMap<Integer, HashMap<String, String>> lookupData(String requestUser, String[] propNames,
			String[] propValues, String[] propOrigValues,JSONArray reqProps, String[] lookupAttrNames) throws Exception{

		logger.debug("Executing Claim Lookup");
		HashMap<String, String> oneDocHashMap = new HashMap<String, String>();
		//if the criteria is empty, then send empty values 
		/*		if(propValues[0].isEmpty()){
			for (int i = 0; i < lookupAttrName.length; i++) {
				oneDocHashMap.put(lookupAttrName[i], new String(""));
			}
		}else{
			SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ssZ");
			String todayStr = dateFormat.format(new Date());

			for (int i = 0; i < lookupAttrName.length; i++) {
				if(lookupAttrName[i].equalsIgnoreCase("DateOfLoss"))
					oneDocHashMap.put(lookupAttrName[i], todayStr);
				else
					oneDocHashMap.put(lookupAttrName[i], new String("Ret"+lookupAttrName[i]));
			}
		}*/
		
		
		oneDocHashMap= searchForFirstClaimDoc(propNames, propValues, lookupAttrNames);
		
		retHashMap.put(0,oneDocHashMap); 
		
		logger.debug("retHashMap.size()::"+retHashMap.size());
		
		return retHashMap ;
	}

	public HashMap<String, String> searchForFirstClaimDoc(String[] criteriaPropNames,String[] criteriaPropValues,String[] searchPropNames) throws Exception {
		logger.info("searchForFirstClaimDoc::Entering.");
		HashMap<String, String> retPropValues = new HashMap<String, String>();
		String strURI = null;
		String strUsername = null;
		String strPassword = null;
		String selectClause=""; 
		String whereClause="";
		try {

			//Form Select SQL
			for (int i = 0; i < searchPropNames.length; i++) {
				selectClause = selectClause + ",["+searchPropNames[i] +"]";
			}
			
			//Form Where SQL
			for (int i = 0; i < criteriaPropNames.length; i++) {
				whereClause = whereClause 
							+ (whereClause.isEmpty()?" ":" AND ")
							+" ["+criteriaPropNames[i] +"]='"+criteriaPropValues[i]+"'";
			}
			
			String strObjectStoreName = EDSProperties.edsProperties.getProperty("OBJECT_STORE_NAME");
			String isCEWSEnabled = EDSProperties.edsProperties.getProperty("ENABLE_CEWS_CONNECTION");
			Connection ceConnection = null;
			Domain domain = null;
			ObjectStore objectStore = null;
			
			strURI = EDSProperties.edsProperties.getProperty("CE_URL");
			
			logger.debug("CEWebservice enabled status is : " + isCEWSEnabled);
			//CEWS logon is here for development purposes.
			//For PROD the connection will be EJB based 
			if (isCEWSEnabled != null && isCEWSEnabled.equals("true")) {
				logger.debug("Reading values from Properties file.");
				strUsername = EDSProperties.edsProperties.getProperty("CEWS_USERNAME");
				strPassword = EDSProperties.edsProperties.getProperty("CEWS_PASSWORD");
				
				logger.debug("URI value is  : " + strURI);
				logger.debug("Username is : " + strUsername);
				logger.debug("Password is : " + strPassword);				
			} 
			
			// Get the connection
			logger.debug("Get the connection.");
			ceConnection = Factory.Connection.getConnection(strURI);
			logger.debug("Got the connection.");
			
			// Build the subject using the FileNetP8WSI stanza
			// Use the FileNetP8WSI stanza for CEWS
			if (isCEWSEnabled.equals("true")) {
				logger.debug("Create Subject using UserContext");
				UserContext uc = UserContext.get();
				uc.pushSubject(UserContext.createSubject(ceConnection, strUsername, strPassword, "FileNetP8WSI"));
				logger.debug("Success::Created Subject using UserContext");
			}

			try {
				logger.debug("Get the default domain");
				
				domain = Factory.Domain.getInstance(ceConnection, null);
				logger.debug("Get an object store object for "+strObjectStoreName);
				
				objectStore= Factory.ObjectStore.fetchInstance(domain, strObjectStoreName, null);
				
				logger.debug("ObjectStore display name is :: " + objectStore.get_DisplayName());
			} catch (Exception ex) {
				logger.debug("Exception occured while connecting to CE.", ex);
				logger.error("Exception occured while connecting to CE.", ex);				
				throw ex;
			}
			
			SearchScope searchScope = new SearchScope(objectStore);
		    Integer myPageSize = new Integer(20);
		    PropertyFilter myFilter = new PropertyFilter();
		    SearchSQL sqlObject = new SearchSQL();
		    int myFilterLevel = 1;
		    StringBuilder strSQL = new StringBuilder();
		    myFilter.setMaxRecursion(myFilterLevel);
		    myFilter.addIncludeType(new FilterElement(null, null, null, FilteredPropertyType.ANY, null)); 
		    //Get the most recent released version
		    strSQL
		    	.append("SELECT [This]")
		    	.append(selectClause)
		    	.append(" FROM [ClaimsDocument] WHERE (")
		    	.append(whereClause)
		    	.append(") OPTIONS(TIMELIMIT 180)");
		    
		    logger.debug("SearchSQL::"+strSQL.toString());
		    
		    Boolean continuable = new Boolean(true);
		    sqlObject.setQueryString(strSQL.toString());
		    IndependentObjectSet docObjects = searchScope.fetchObjects(sqlObject, myPageSize, myFilter, continuable);
		    
		   
		    Iterator<Document> iter = docObjects.iterator();
		    while (iter.hasNext())
		    {
		    	Document doc = (Document) iter.next();
		    	com.filenet.api.property.Properties props = doc.getProperties();
		    	for (int i = 0; i < searchPropNames.length; i++) {
		    		Property prop = props.find(searchPropNames[i]);
		    		String propertyVal ="";
		    		//Date Property
		    		if(prop instanceof PropertyDateTime && prop.getDateTimeValue()!=null) {
		    			//"yyyy-MM-dd'T'HH:mm:ssZ": Removed the time component to show 12 always
		    			SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
		    			propertyVal = dateFormat.format(prop.getDateTimeValue());
					}
					//String Property
		    		if(prop instanceof PropertyString && prop.getStringValue()!=null)
							propertyVal=prop.getStringValue();
					
		    		logger.debug("PropertyName::"+searchPropNames[i]);
		    		logger.debug("PropertyValue::"+propertyVal);
		    		retPropValues.put(searchPropNames[i],propertyVal);
				}
		    	//Return after the first record
		    	break;
		    }
			
		} catch (Exception e) {			
			logger.debug("ERROR in searchForFirstClaimDoc() method : ", e);
			logger.error("ERROR in searchForFirstClaimDoc() method : ", e);
			throw e;
		}
		
		return retPropValues;
	}

	
}
