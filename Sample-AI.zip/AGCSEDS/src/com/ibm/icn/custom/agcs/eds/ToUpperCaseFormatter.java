/**
 * @author Philip
 *
 */
package com.ibm.icn.custom.agcs.eds;

import com.ibm.icn.custom.eds.common.EDSFormatter;

/**
 * @author Philip
 *
 */
public class ToUpperCaseFormatter extends EDSFormatter {
	/* (non-Javadoc)
	 * @see com.ibm.icn.custom.eds.common.EDSFormatter#getFormattedValue(java.lang.String, java.lang.Object)
	 */
	@Override
	public String getFormattedValue(String requestMode, String propertyName, Object propertyValue)
			throws Exception {
		if(propertyValue==null)
			return "";
		else
			return ((String)propertyValue).toUpperCase();
	}
}
