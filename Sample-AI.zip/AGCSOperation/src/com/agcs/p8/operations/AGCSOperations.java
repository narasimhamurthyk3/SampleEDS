package com.agcs.p8.operations;


import java.io.FileInputStream;
import java.io.FileNotFoundException;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Properties;

import javax.security.auth.Subject;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.filenet.api.collection.UserSet;
import com.filenet.api.constants.PrincipalSearchAttribute;
import com.filenet.api.constants.PrincipalSearchSortType;
import com.filenet.api.constants.PrincipalSearchType;
import com.filenet.api.constants.RefreshMode;
import com.filenet.api.core.Connection;
import com.filenet.api.core.Document;
import com.filenet.api.core.Factory;
import com.filenet.api.core.UpdatingBatch;
import com.filenet.api.security.Realm;
import com.filenet.api.security.User;
import com.filenet.api.util.UserContext;

import filenet.vw.api.VWAttachment;
import filenet.vw.api.VWSession;

public class AGCSOperations {
	
	public Logger logger;
	
	public static Properties agcsProperties;
	
	public AGCSOperations() throws Exception  {
		setLogger();
		try {
			logger.info("AGCSOperations: Constructor():"
					+ "Loading AGCSAppConfig.configuration="
					+ System.getProperty("AGCSAppConfig.configuration"));
			AGCSOperations.agcsProperties = loadAppConfiguration(System.getProperty("AGCSAppConfig.configuration"));
			logger.info("AGCSOperations: Constructor():"
					+ "Loaded AGCSAppConfig.configuration");
		} catch (Exception exp) {
			logger.fatal("AGCSOperations: Constructor()", exp);
			throw (exp);
		}

	}
	
	public void setLogger() {
		logger = Logger.getLogger(AGCSOperations.class); // Logger.getRootLogger();//
	}

	public String copyDocuments(String sourceSQL,String[] propNames,String propVals[]) throws Exception{
		
		logger.debug("AGCSOperations::copyDocuments::Entering.");
		String result="";
		try{
			CEDataProvider ceDp = new CEDataProvider();
			ArrayList<Document> retDocs = ceDp.searchForDocuments(sourceSQL);
			
			HashMap<String, String> targetPropVals = new HashMap<String, String>();
			
			for (int i = 0; i < propNames.length; i++) {
				targetPropVals.put(propNames[i], propVals[i]);
			}

			UpdatingBatch ub = UpdatingBatch.createUpdatingBatchInstance(ceDp.domain, RefreshMode.REFRESH);
			for (Document source : retDocs) {
				try {
					Document newDoc = ceDp.createDocumentCopy(source, targetPropVals);
					ub.add(newDoc, null);
				} catch (Exception e) {
					logger.error(e);
					return "Exception";
				}
			}
			ub.updateBatch();
			
		}catch(Exception e){
			logger.error(e);
			return "Exception";
		}
			
		logger.debug("AGCSOperations::copyDocuments::Exiting.");
		return result;
	}

	public String copyDocuments(VWAttachment[] sourceDocs,String[] propNames,String propVals[]) throws Exception{
		logger.debug("AGCSOperations::copyDocuments::Entering.");
		String result="";
		try{
			CEDataProvider ceDp = new CEDataProvider();
			ceDp.getCEConnection();
			
			HashMap<String, String> targetPropVals = new HashMap<String, String>();
			
			for (int i = 0; i < propNames.length; i++) {
				targetPropVals.put(propNames[i], propVals[i]);
			}

			//UpdatingBatch ub = UpdatingBatch.createUpdatingBatchInstance(ceDp.domain, RefreshMode.REFRESH);
			for (VWAttachment source : sourceDocs) {
				try {
					logger.debug("SourceName::"+source.getAttachmentName());
					logger.debug("SourceId::"+source.getId());
					logger.debug("SourceLibrary::"+source.getLibraryName());
					
					Document sourceDoc = ceDp.getDocumentObject(source);
					Document newDoc = ceDp.createDocumentCopy(sourceDoc, targetPropVals);
					newDoc.save(RefreshMode.REFRESH);
					logger.debug("Copied doc ID:" + newDoc.get_Id().toString());
				//	ub.add(newDoc, null);
				} catch (Exception e) {
					logger.error(e);
					return "Exception";
				}
			}
		}catch(Exception e){
			logger.error(e);
			return "Exception";
		}
		//ub.updateBatch();		
		logger.debug("AGCSOperations::copyDocuments::Exiting.");
		return result;
	}

	public String copyDocuments(VWAttachment sourceTemplate, String sourceDocIds,String[] propNames,String propVals[]) throws Exception{
		logger.debug("AGCSOperations::copyDocumentsByIds::Entering.::"+sourceDocIds);
		String result="";
		try{
			CEDataProvider ceDp = new CEDataProvider();
			ceDp.getCEConnection();
			String[] sourceIds = sourceDocIds.split(",");
			String newLineChar= System.getProperty("line.separator");
			
			HashMap<String, String> targetPropVals = new HashMap<String, String>();
			
			for (int i = 0; i < propNames.length; i++) {
				targetPropVals.put(propNames[i], propVals[i]);
			}

			//UpdatingBatch ub = UpdatingBatch.createUpdatingBatchInstance(ceDp.domain, RefreshMode.REFRESH);
			for (int i = 0; i < sourceIds.length; i++) {
				try {
					logger.debug("SourceId::"+sourceIds[i]);
					Document sourceDoc = ceDp.getDocumentObjectById(sourceIds[i]);
					Document newDoc = ceDp.createDocumentCopy(sourceDoc, targetPropVals);
					newDoc.save(RefreshMode.REFRESH);
					logger.debug("Copied doc ID:" + newDoc.get_Id().toString());
					result+="Success:: Source Document::"+sourceIds[i]+" copied to Target::"+newDoc.get_Id().toString()+newLineChar;
				//	ub.add(newDoc, null);
				} catch (Exception e) {
					result+="Failure:: Source Document::"+sourceIds[i]+" Error:: " + e.getMessage()+newLineChar;
					logger.error(e);
					//throw e;
				}
			}
			//ub.updateBatch();	
		}catch(Exception e){
			logger.error(e);
			return "Exception";
		}
			
		logger.debug("AGCSOperations::copyDocumentsByIds::Exiting.");
		return result;
	}

	
	public String getEmailID(int f_operation){
		logger.debug("AGCSOperations::getEmailID::Entering.:: F_Operation ->>"+f_operation);
		String emailID = null;
		// User Information
				try {
				/*String uri = "http://10.9.92.15:9080/wsi/FNCEWS40MTOM/"; 
				Connection connection = Factory.Connection.getConnection(uri); 
				// Establish a LoginContext 
				UserContext uc = UserContext.get(); 

				Subject subject = UserContext.createSubject(connection, "", "", "FileNetP8WSI"); 
				uc.pushSubject(subject); */

				
				CEDataProvider ceDp = new CEDataProvider();
				ceDp.getCEConnection();
				logger.debug("Successfully connected to Content Engine");
				// Connection Point
				String connectionPoint = AGCSOperations.agcsProperties.getProperty("CONNECTION_POINT");
				logger.debug("Connection Point :"+connectionPoint);
				// Create a Process Engine Session Object
				VWSession myPESession = new VWSession(connectionPoint);
				// Set Bootstrap Content Engine URI
				logger.debug("Successfully connected to Process Engine");
			
				// Log onto the Process Engine Server
				
					
					int userid = f_operation;
					String str=myPESession.convertIdToUserName(userid);
					logger.debug("convertIdToUserName :"+str);
					String url = System.getProperty("filenet.pe.bootstrap.ceuri");
					Connection ceConnection = null;
					logger.debug("getEmailID :::filenet.pe.bootstrap.ceuri::"+ url);
				
					String isCEWSEnabled = AGCSOperations.agcsProperties.getProperty("ENABLE_CEWS_CONNECTION");
					
					logger.debug("CEWebservice enabled status is : " + isCEWSEnabled);		
					if (isCEWSEnabled != null && isCEWSEnabled.equals("true")) {
						logger.debug("Reading values from Properties file.");
						String strUsername = AGCSOperations.agcsProperties.getProperty("CEWS_USERNAME");
						String strPassword = AGCSOperations.agcsProperties.getProperty("CEWS_PASSWORD");
						url = AGCSOperations.agcsProperties.getProperty("CE_URL");
						logger.debug("URI value is  : " + url);
						logger.debug("Username is : " + strUsername);
						logger.debug("Password is : " + strPassword);				
						logger.debug("Create Subject using UserContext");
						ceConnection = Factory.Connection.getConnection(url);
						UserContext uc = UserContext.get();
						uc.pushSubject(UserContext.createSubject(ceConnection, strUsername, strPassword, "FileNetP8WSI"));
						logger.debug("Success::Created Subject using UserContext");
					} else{
						ceConnection = Factory.Connection.getConnection(url);
					}
						

					
					logger.debug("getEmailID ::Connected to CE.");
					 
					Realm rm =  Factory.Realm.fetchCurrent(ceConnection,  null);
					logger.debug("Realm name :"+rm.get_Name());
					
					UserSet usr = rm.findUsers(str, PrincipalSearchType.PREFIX_MATCH, PrincipalSearchAttribute.SHORT_NAME, PrincipalSearchSortType.ASCENDING, null, null);
					@SuppressWarnings("unchecked")
					Iterator<UserSet> itr = usr.iterator();
					logger.debug("Check Iterator object :"+itr.hasNext());
					while(itr.hasNext()){
						User username = (User) itr.next();
						
						emailID = username.get_Email();
						logger.debug("User Email ID :"+emailID);
					}
					
					
					
					
				} catch (Exception e) {
					// TODO Auto-generated catch block
					logger.error("Error in getEmailID method : "+e);
				
					e.printStackTrace();
				}
		return emailID;
	}
	
	public String updateDocuments(String sourceSQL,String[] propNames,String propVals[]) throws Exception{
		
		logger.debug("AGCSOperations::updateDocuments::Entering.");
		String result="";
		
		try{
			CEDataProvider ceDp = new CEDataProvider();
			ArrayList<Document> retDocs = ceDp.searchForDocuments(sourceSQL);
			UpdatingBatch ub = UpdatingBatch.createUpdatingBatchInstance(ceDp.domain, RefreshMode.REFRESH);
			for (Document source : retDocs) {
				try {
					Document newDoc = ceDp.updateDocument(source,propNames,propVals );
					logger.debug("updated doc ..adding to batch");
					ub.add(newDoc, null);
				} catch (Exception e) {
					logger.error("Error occured in updating a document ",e);
					return "Exception";
				}
			}
			try {
				logger.debug("updating batch of Documents");
				ub.updateBatch();		
			} catch (Exception e) {
				logger.error("Error occured in updating batch of documents",e);
				return "Exception";
				//throw e;
			}
		}catch(Exception e){
			logger.error(e);
			return "Exception";
		}
				
		logger.debug("AGCSOperations::updateDocuments::Exiting.");
		return result;
	}
	
	public Properties loadAppConfiguration(String configurationFile) throws IOException {
		logger.debug("AGCSOperations::loadAppConfiguration::Entering.");
		FileInputStream fisAGCSAppConfig;
		Properties objAGCSAppProps = new Properties();
		try {
			System.out.println(configurationFile);
			fisAGCSAppConfig = new FileInputStream(configurationFile);
			objAGCSAppProps.clear();
		
			try {
				objAGCSAppProps.load(fisAGCSAppConfig);
			} catch (IOException e1) {
				logger.debug(
						"AGCSOperations::loadAppConfiguration::configurationFile::"
								+ configurationFile
								+ "::Error while loading config file.", e1);
				logger.error(
						"AGCSOperations::loadAppConfiguration::configurationFile::"
								+ configurationFile
								+ "::Error while loading config file.", e1);
				throw e1;
			}
			try {
				fisAGCSAppConfig.close();
			} catch (IOException e2) {
				logger.debug(
						"AGCSOperations::loadAppConfiguration::configurationFile::"
								+ configurationFile
								+ "::Error while closing config file.", e2);
				logger.error(
						"AGCSOperations::loadAppConfiguration::configurationFile::"
								+ configurationFile
								+ "::Error while closing config file.", e2);
				throw e2;
			}
		} catch (FileNotFoundException e) {
			logger.debug(
					"AGCSOperations::loadAppConfiguration::configurationFile::"
							+ configurationFile + " could not be found.", e);
			logger.error(
					"AGCSOperations::loadAppConfiguration::configurationFile::"
							+ configurationFile + " could not be found.", e);
			throw e;
		}
		logger.debug("AGCSOperations::loadAppConfiguration::Exiting.");
		return objAGCSAppProps;
	}
	
	public static void main (String[] argsv){
		try {
			String log4jConfigFile= "D:/Customers/AGCS/AGCS Workspace/AGCS_Operations/config/log4j.properties";
			//InputStream log4jStream = AGCSOperations.class.getResourceAsStream(log4jConfigFile);
			PropertyConfigurator.configure(log4jConfigFile);
			
			AGCSOperations aTest = new AGCSOperations();
			
			VWAttachment oneDoc = new VWAttachment();
			oneDoc.setId("{D8810541-A289-4984-8CCE-BAC4A330DAA9}");
			oneDoc.setLibraryName("CMDEV");
			
			VWAttachment[] sourceDocs = {oneDoc};
			aTest.copyDocuments(sourceDocs, new String[]{"ClaimNumber","DateOfLoss"},new String[]{"100","03/12/2013 12:00:00 am"});
			
			//aTest.copyDocuments("Select * from ClaimsDocument Where ClaimNumber='100'",new String[]{"ClaimNumber"},new String[]{"100"});
			//aTest.updateDocuments("Select * from ClaimsDocument Where ClaimNumber='1001' and FileOnly='Yes'",new String[]{"ClaimNumber"},new String[]{"10011"});
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		
	}
}
