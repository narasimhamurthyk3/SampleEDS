/**
 * @author Philip
 *
 */
package com.agcs.p8.operations;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.Map;

import org.apache.log4j.Logger;

import com.filenet.api.collection.AccessPermissionList;
import com.filenet.api.collection.ContentElementList;
import com.filenet.api.collection.IndependentObjectSet;
import com.filenet.api.collection.PageIterator;
import com.filenet.api.collection.PropertyDescriptionList;
import com.filenet.api.constants.AutoClassify;
import com.filenet.api.constants.Cardinality;
import com.filenet.api.constants.CheckinType;
import com.filenet.api.constants.TypeID;
import com.filenet.api.core.Connection;
import com.filenet.api.core.Containable;
import com.filenet.api.core.ContentTransfer;
import com.filenet.api.core.Document;
import com.filenet.api.core.Domain;
import com.filenet.api.core.EntireNetwork;
import com.filenet.api.core.Factory;
import com.filenet.api.core.ObjectStore;
import com.filenet.api.core.VersionSeries;

import com.filenet.api.meta.PropertyDescription;
import com.filenet.api.property.Properties;
import com.filenet.api.property.Property;
import com.filenet.api.query.SearchSQL;
import com.filenet.api.query.SearchScope;
import com.filenet.api.security.AccessPermission;
import com.filenet.api.util.Id;
import com.filenet.api.util.UserContext;


import filenet.vw.api.VWAttachment;
import filenet.vw.api.VWException;


/**
 * @author Philip
 *
 */
public class CEDataProvider {
	
	
	Domain domain =null;
	Logger logger =null;
	String objectStoreName ="";
	
	public CEDataProvider() {
		logger = Logger.getLogger(CEDataProvider.class.getName());
	}
	
	protected void getCEConnection(){
		String url = System.getProperty("filenet.pe.bootstrap.ceuri");
		Connection ceConnection = null;
		logger.debug("CEDataProvider:::filenet.pe.bootstrap.ceuri::"+ url);

		objectStoreName = AGCSOperations.agcsProperties.getProperty("OBJECT_STORE_NAME");
		String isCEWSEnabled = AGCSOperations.agcsProperties.getProperty("ENABLE_CEWS_CONNECTION");
		
		logger.debug("CEWebservice enabled status is : " + isCEWSEnabled);		
		if (isCEWSEnabled != null && isCEWSEnabled.equals("true")) {
			logger.debug("Reading values from Properties file.");
			String strUsername = AGCSOperations.agcsProperties.getProperty("CEWS_USERNAME");
			String strPassword = AGCSOperations.agcsProperties.getProperty("CEWS_PASSWORD");
			url = AGCSOperations.agcsProperties.getProperty("CE_URL");
			logger.debug("URI value is  : " + url);
			logger.debug("Username is : " + strUsername);
			logger.debug("Password is : " + strPassword);				
			logger.debug("Create Subject using UserContext");
			ceConnection = Factory.Connection.getConnection(url);
			UserContext uc = UserContext.get();
			uc.pushSubject(UserContext.createSubject(ceConnection, strUsername, strPassword, "FileNetP8WSI"));
			logger.debug("Success::Created Subject using UserContext");
		} else{
			ceConnection = Factory.Connection.getConnection(url);
		}
			

		
		logger.debug("CEDataProvider::Connected to CE.");
		EntireNetwork entireNetwork = Factory.EntireNetwork.fetchInstance(ceConnection, null);
		domain = entireNetwork.get_LocalDomain();
	}

	public ArrayList<Document> searchForDocuments(String SQL) throws VWException{
	logger.debug("CEDataProvider::searchForDocuments::SQL="+SQL);
		ArrayList<Document> arrListDocs = new ArrayList<Document>();
		
		getCEConnection();
		
		// Build and execute the CE search
		SearchScope scope = new SearchScope(Factory.ObjectStore.getInstance(domain, objectStoreName));
		SearchSQL searchSql = new SearchSQL(SQL);
		
		IndependentObjectSet set = scope.fetchObjects(searchSql, 500, null, true);
		PageIterator pi = set.pageIterator();
		
		while(pi.nextPage())
		{
			logger.debug("CEDataProvider::searchForDocuments::Iterating Page");
			Object[] docs = pi.getCurrentPage();
			for(int i = 0; i < docs.length; i++)
			{
				logger.debug("CEDataProvider::searchForDocuments::Iterating Docs "+i);
				Document d = (Document)docs[i];
				arrListDocs.add(d);
			}
		}
		
		logger.debug("CEDataProvider::searchForDocuments::returning docs");
		
		return arrListDocs;
	} 
	
	protected Document updateDocument(Document targetDoc, String[] propNames, String[] propValues) throws Exception{
		logger.debug("CEDataProvider::updateDocument::");

		PropertyDescriptionList pdl= targetDoc.get_ClassDescription().get_PropertyDescriptions();
		
		for (int i = 0; i < propNames.length; i++) {
			logger.debug("CEDataProvider::updateDocument properties "+propNames[i]+"="+propValues[i]);
			PropertyDescription onePropDesc = null;

			logger.debug("Searching for prop desc of ::"+propNames[i]);
			for (int j = 0; j < pdl.size(); j++) {
				if(((PropertyDescription)pdl.get(j)).get_SymbolicName().equalsIgnoreCase(propNames[i])){
					onePropDesc = (PropertyDescription)pdl.get(j);
					break;
				}
			}

			switch (onePropDesc.get_DataType().getValue()){
				case TypeID.STRING_AS_INT:
					logger.debug("Setting value of string property::");
					targetDoc.getProperties().putValue(propNames[i], propValues[i]);
	
					break;
				case TypeID.DATE_AS_INT:
					logger.debug("Setting value of date property::");
		    		SimpleDateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy HH:mm:ss a");
		    		Date aDate = dateFormat.parse(propValues[i]);
		    		logger.debug("Converted string to date type::"+aDate.toString());
					targetDoc.getProperties().putValue(propNames[i], aDate);
					break;
				case TypeID.DOUBLE_AS_INT:
					logger.debug("Setting value of double property::");
					targetDoc.getProperties().putValue(propNames[i], Double.parseDouble(propValues[i]));
					break;
				case TypeID.LONG_AS_INT:
					targetDoc.getProperties().putValue(propNames[i], Long.parseLong(propValues[i]));
					break;
			}
		}
		//targetDoc.save(RefreshMode.NO_REFRESH);
		logger.debug("Exiting Update.");
		return targetDoc;
	}
	
	protected Document createDocumentCopy(Document source, Map<String,String> targetProperties) throws Exception
	{
		logger.debug("CEDataProvider::createDocumentCopy::");
		
		// Get the class type
		String className = source.get_ClassDescription().get_SymbolicName();
		logger.debug("Creating doc of class::"+className);
		
		// Create the new document
		Document target = Factory.Document.createInstance(source.getObjectStore(), className);
		
		logger.debug("Copying properties over from source to target doc ");
		// Copy existing custom property values
		copyProperties(source,target,targetProperties);
		
		// Copy the content
		copyContent(source,target);
		
		// Copy the security
		//copySecurity(source,target);
		logger.debug("checking in new doc ");
		
		target.checkin(AutoClassify.DO_NOT_AUTO_CLASSIFY, CheckinType.MAJOR_VERSION);
		logger.debug("Checked in new doc ");

		return target;
	}
	
	@SuppressWarnings("unchecked")
	private void copyContent(Document source, Document target)
	{
		logger.debug("CEDataProvider::copyContent::");
		ContentElementList sl = source.get_ContentElements();
		ContentElementList tl = Factory.ContentElement.createList();
		
		for(int i = 0; i < sl.size(); i++)
		{
			ContentTransfer se = (ContentTransfer)sl.get(i);
			ContentTransfer te = Factory.ContentTransfer.createInstance();
			
			te.set_ContentType(se.get_ContentType());
			te.set_RetrievalName(se.get_RetrievalName());
			
			te.setCaptureSource(se.accessContentStream());
			
			tl.add(te);
		}
		
		target.set_ContentElements(tl);
		logger.debug("CEDataProvider::completed copyContent::");
	}

	//Only String and Dates are handled as of now
	@SuppressWarnings("rawtypes")
	private void copyProperties(Document source, Document target, Map<String,String> targetProperties) throws Exception
	{
		logger.debug("CEDataProvider::copyProperties::");
		Properties targetProps = source.getProperties();
		PropertyDescriptionList pdl= source.get_ClassDescription().get_PropertyDescriptions();
		for (Iterator i= targetProps.iterator();i.hasNext();) {
			Property oneProp = (Property)i.next();
			PropertyDescription onePropDesc = null;
			String propName = oneProp.getPropertyName();
			logger.debug("Searching for prop desc of ::"+propName);
			for (int j = 0; j < pdl.size(); j++) {
				if(((PropertyDescription)pdl.get(j)).get_SymbolicName().equalsIgnoreCase(oneProp.getPropertyName())){
					onePropDesc = (PropertyDescription)pdl.get(j);
					break;
				}
			}
			
			if(!onePropDesc.get_IsSystemOwned() && !onePropDesc.get_IsReadOnly()){
				switch (onePropDesc.get_DataType().getValue()){
					case TypeID.STRING_AS_INT:
						logger.debug("Setting value of string property::"+propName);
						if(targetProperties.containsKey(propName))
							target.getProperties().putValue(propName, (String)targetProperties.get(propName));
						else
							if(onePropDesc.get_Cardinality()==Cardinality.LIST)
								target.getProperties().putValue(propName, oneProp.getStringListValue());
							else
								target.getProperties().putValue(propName, oneProp.getStringValue());
	
						break;
					case TypeID.DATE_AS_INT:
						logger.debug("Setting value of date property::"+propName);
						if(targetProperties.containsKey(propName)){
				    		SimpleDateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy HH:mm:ss a");
				    		String dateVal = (String)targetProperties.get(propName);
				    		logger.debug("Date String::"+dateVal);

				    		try {
				    			Date aDate = dateFormat.parse(dateVal);
					    		logger.debug("Converted string to date type::"+aDate.toString());
								target.getProperties().putValue(propName, aDate);
							} catch (java.text.ParseException e) {
								logger.error(e);
								throw e;
							}
						}else
							if(onePropDesc.get_Cardinality()==Cardinality.LIST)
								target.getProperties().putValue(propName, oneProp.getDateTimeListValue());
							else
								target.getProperties().putValue(propName, oneProp.getDateTimeValue());
						break;
					case TypeID.DOUBLE_AS_INT:
						logger.debug("Setting value of double property::"+propName);
						if(onePropDesc.get_Cardinality()==Cardinality.LIST)
							target.getProperties().putValue(propName, oneProp.getFloat64ListValue());
						else
							target.getProperties().putValue(propName, oneProp.getFloat64Value());
						break;
					case TypeID.LONG_AS_INT:
						if(onePropDesc.get_Cardinality()==Cardinality.LIST)
							target.getProperties().putValue(propName, oneProp.getInteger32ListValue());
						else
							target.getProperties().putValue(propName, oneProp.getInteger32Value());
						logger.debug("Setting value of long property::"+propName);
						break;
				}
			}
		}
	}
	
	@SuppressWarnings("unchecked")
	protected void copySecurity(Containable source, Containable target) throws Exception
	{
		logger.debug("CEDataProvider::copySecurity::");

		try {
			logger.debug("CEDataProvider::copySecurity::getting source acl");
			AccessPermissionList sacl = source.get_Permissions();
			
			AccessPermissionList tacl = Factory.AccessPermission.createList();

			logger.debug("CEDataProvider::copySecurity::iterating source acls");
			for(int i = 0; i < sacl.size(); i++)
			{
				logger.debug("CEDataProvider::copySecurity::iterating source acls"+i);
				AccessPermission sace = (AccessPermission)sacl.get(i);
				AccessPermission tace = Factory.AccessPermission.createInstance();
				
				tace.set_AccessMask(sace.get_AccessMask());
				tace.set_AccessType(sace.get_AccessType());
				tace.set_GranteeName(sace.get_GranteeName());
				tace.set_InheritableDepth(sace.get_InheritableDepth());
				
				tacl.add(tace);
			}
			
			target.set_Permissions(tacl);
			target.set_Owner(source.get_Owner());
			
		} catch (Exception e) {
			logger.error("Error occured",e);
			throw e;
		}
		logger.debug("CEDataProvider::copySecurity completed::");
	}

	protected Document getDocumentObjectById(String sourceDocId) throws Exception
	{
		logger.debug("CEDataProvider::getDocumentById::"+sourceDocId);
		Document target=null;
		try {
			ObjectStore os = Factory.ObjectStore.fetchInstance(domain, objectStoreName, null);
			// Fetch the document
			target = Factory.Document.fetchInstance(os, new Id(sourceDocId),null);
		} catch (Exception e) {
			logger.error("Error occured",e);
			throw e;
		}
		return target;
	}	

	protected Document getDocumentObject(VWAttachment sourceDoc) throws Exception
	{
		logger.debug("CEDataProvider::getDocumentById::"+sourceDoc.getId());
		Document target=null;
		try {
			// Fetch the vs
			ObjectStore os = Factory.ObjectStore.fetchInstance(domain, objectStoreName, null);
			VersionSeries vs = Factory.VersionSeries.fetchInstance(os, new Id(sourceDoc.getId()), null);
			// Fetch the document
			target = (Document)vs.get_CurrentVersion();
			//target = Factory.Document.fetchInstance(os,vs., null);
					
		} catch (Exception e) {
			logger.error("Error occured",e);
			throw e;
		}
		return target;
	}	
}
