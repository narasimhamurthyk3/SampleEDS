package com.ibm.ddm.plugin.service.workers;

import com.filenet.api.core.Document;
import com.filenet.api.exception.EngineRuntimeException;
import com.filenet.api.property.Properties;
import com.filenet.api.util.Id;
import com.ibm.ddm.plugin.service.utilities.Configuration;
import com.ibm.json.java.JSONObject;

public abstract class BaseUnit {
	protected String id;
	private String objectIdStr, className, objectStoreIdStr, nameProperty;
	protected Id objectId, objectStoreId;
	private boolean valid = false, retrieved = false;
	private Exception exception = null;
	private Document document;

	public void assignId(String id) {
		this.id = id;

		String[] elements = id.split(",");

		this.className = elements[0];
		this.objectStoreIdStr = elements[1];
		this.objectIdStr = elements[2];

		try {
			this.objectId = new Id(objectIdStr);
			this.objectStoreId = new Id(objectStoreIdStr);
		} catch (EngineRuntimeException ex) {
			exception = ex;
		}

		assignNamePropertyByClass(className);
	}

	public void assignNamePropertyByClass(String className) {
		nameProperty = Configuration.prop_documentTitle;
	}

	public final JSONObject serialize() {
		JSONObject object = new JSONObject();

		Properties props = document.getProperties();

		try {
			object.put("title", props.getStringValue(nameProperty));
		} catch (EngineRuntimeException ex) {
			object.put("title", objectIdStr);
		}

		object.put("DocumentCategory", getStringProperty(props, Configuration.prop_documentCategory));
		object.put("DocumentSubCategory", getStringProperty(props, Configuration.prop_documentSubCategory));

		object.put("PolicyNumber", getStringProperty(props, Configuration.prop_policyNumber));
		object.put("SubmissionNumber", getStringProperty(props, Configuration.prop_submissionNumber));

		object.put("ClaimNumber", getStringProperty(props, Configuration.prop_claimNumber));
		object.put("claimantsuffix", getStringProperty(props, Configuration.prop_claimSuffixNumber));

		object.put("InsuredEntity", getStringProperty(props, Configuration.prop_insuredName));
		object.put("claimantentity", getStringProperty(props, Configuration.prop_claimantName));

		object.put("ClaimDocumentCategory", getStringProperty(props, Configuration.prop_claim_documentCategory));
		object.put("ClaimDocumentSubCategory", getStringProperty(props, Configuration.prop_claim_documentSubCategory));

		object.put("guid", objectId.toString());

		object.put("status", getStatus());

		if (exception != null) {
			object.put("ErrorDescription", exception.getLocalizedMessage());
			if (exception.getLocalizedMessage() != null
					&& exception.getLocalizedMessage().toLowerCase().contains("read-only"))
				object.put("ErrorDescription", "User has only view access on this document and cannot be updated.");
			else
				object.put("ErrorDescription", exception.getLocalizedMessage());
			object.put("ErrorSeverity", "Fatal");
			object.put("ErrorCode", (exception instanceof EngineRuntimeException
					? ((EngineRuntimeException) exception).getExceptionCode().getId() : -1));
		} else {
			object.put("ErrorDescription", "");
			object.put("ErrorSeverity", "");
			object.put("ErrorCode", "");
		}

		return object;
	}

	protected String getStringProperty(Properties props, String name) {
		if (!props.isPropertyPresent(name))
			return "";
		String value = document.getProperties().getStringValue(name);
		return value == null ? "" : value;
	}

	public abstract boolean isSuccessful();

	protected String getStatus() {
		if (retrieved)
			return "Failed"; // "Failed preparing"; PJ-FFIC Wants one status for
								// all errors

		if (valid)
			return "Failed"; // "Failed retrieving source"; PJ-FFIC Wants one
								// status for all errors

		if (exception != null)
			return "Failed";

		return "Invalid document";
	}

	public final Document getDocument() {
		return document;
	}

	public final void setDocument(Document document) {
		this.document = document;
	}

	public final boolean isValid() {
		return valid;
	}

	public final boolean isRetrieved() {
		return retrieved;
	}

	public final void setException(Exception exception) {
		this.exception = exception;
	}

	// PJ : Added to evaluate error count
	public final boolean isException() {
		return (this.exception != null);
	}

	public final void setValid(boolean valid) {
		this.valid = valid;
	}

	public final void setRetrieved(boolean retrieved) {
		this.retrieved = retrieved;
	}

	public final String getId() {
		return id;
	}

	public final String getObjectIdStr() {
		return objectIdStr;
	}

	public final String getClassName() {
		return className;
	}

	public final String getObjectStoreIdStr() {
		return objectStoreIdStr;
	}

	public final Id getObjectId() {
		return objectId;
	}

	public final Id getObjectStoreId() {
		return objectStoreId;
	}
}