package com.ibm.ddm.plugin.service.workers;

import java.util.HashMap;
import com.ibm.ddm.plugin.service.utilities.BulkUpdatePluginLogger;
import com.ibm.json.java.JSONArray;
import com.ibm.json.java.JSONObject;

public abstract class ArrayWorker extends BaseWorker {
	protected String objectStore = null;
	protected HashMap<String, String> targetProperties = new HashMap<String, String>();
	private Class<?> workerClass;

	public ArrayWorker(Class<?> workerClass) {
		this.workerClass = workerClass;
	}

	public JSONObject execute(String userID, JSONObject request) {

		// Get the target property from the payload
		JSONObject target = (JSONObject) request.get("target");
		BulkUpdatePluginLogger.logDebug("Target :" + target, "ArrayWorker", "execute", userID);
		if (target == null)
			return buildExceptionPayload("Invalid request payload, source must be specified { \"target\": {} }");

		// Get the properties to update
		JSONArray tpa = (JSONArray) target.get("properties");
		BulkUpdatePluginLogger.logDebug("Properties :" + tpa, "ArrayWorker", "execute", userID);
		if (tpa == null)
			return buildExceptionPayload(
					"Invalid request payload, source must be specified { \"target\": { properties: [] } }");

		// Look through the properties and build the String:String hash
		targetProperties.clear(); // Clear the properties, PJ
		if (tpa != null && tpa.size() > 0) {
			for (int i = 0; i < tpa.size(); i++) {
				JSONObject prop = (JSONObject) tpa.get(i);

				String name = (String) prop.get("property");
				String value = (String) prop.get("value");

				if (name == null)
					continue;

				targetProperties.put(name, value);
			}
		}

		// This worker processes an array of items that we'll fetch here
		ArrayUnit[] units = null;

		try {
			units = buildArray(request, userID);
		} catch (Exception ex) {
			return buildExceptionPayload(ex, units);
		}

		// Now that we have the documents to process, we have the worker process
		// the items
		try {
			processArray(units, userID);
		} catch (Exception ex) {
			return buildExceptionPayload(ex, units);
		}

		// Build our counts array
		JSONObject counts = new JSONObject();
		counts.put("total", units.length);

		int success = 0;

		for (int i = 0; i < units.length; i++)
			success += (units[i].isSuccessful() ? 1 : 0);

		counts.put("success", success);

		// Start building the response JSON payload
		JSONObject response = new JSONObject();
		response.put("documents", serializeUnits(units));
		response.put("exception", null);
		response.put("counts", counts);
		return response;
	}

	/**
	 * Builds an array of items to process based on a passed in set of ICN ids
	 * 
	 * @param request
	 *            Incoming request payload
	 * @return A set of retrieved work units
	 * @throws Exception
	 */
	protected ArrayUnit[] buildArray(JSONObject request, String userID) throws Exception {
		// Get the IDs array from the payload
		JSONArray guids = (JSONArray) request.get("guids");

		ArrayUnit[] units = new ArrayUnit[guids.size()];

		// Prepare the items for retrieval
		for (int i = 0; i < guids.size(); i++) {
			try {
				units[i] = (ArrayUnit) workerClass.newInstance();
				units[i].assignId((String) guids.get(i));
				units[i].setValid(true);
			} catch (Exception e) {
				throw new RuntimeException(e);
			}
		}

		// Retrieve the documents from Content Engine
		retrieveDocuments(objectStore, units, null);

		return units;
	}

	/**
	 * Processes the provided array of items
	 * 
	 * @param user
	 *            FFIC user object for access validation checks
	 * @param units
	 *            Array of work items to process
	 * @throws Exception
	 *             Thrown for any fatal errors that mean processing cannot
	 *             continue
	 */
	public abstract void processArray(ArrayUnit[] units, String userID) throws Exception;

}