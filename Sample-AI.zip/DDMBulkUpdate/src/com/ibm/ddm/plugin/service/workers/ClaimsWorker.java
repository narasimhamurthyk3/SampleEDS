package com.ibm.ddm.plugin.service.workers;

import com.ibm.ddm.plugin.service.utilities.BulkUpdatePluginLogger;
import com.ibm.json.java.JSONArray;
import com.ibm.json.java.JSONObject;

public class ClaimsWorker extends BaseWorker {

	@Override
	public JSONObject execute(String userID, JSONObject request) throws Exception {

		UpdateWorker worker = new UpdateWorker();
		worker.setDomain(this.getDomain());

		JSONArray sets = (JSONArray) request.get("claims");
		BulkUpdatePluginLogger.logDebug("JSON Request :" + sets, "ClaimsWorker", "execute", userID);
		String os = (String) request.get("objectStore"), className = (String) request.get("documentClass");
		BulkUpdatePluginLogger.logDebug("className :" + className, "ClaimsWorker", "execute", userID);
		int success = 0, total = 0;

		// Build the collections of items
		JSONArray documents = new JSONArray();
		JSONArray exceptions = new JSONArray();

		for (int i = 0; i < sets.size(); i++) {
			// Add the expected OS/Class parameters
			JSONObject subreq = (JSONObject) sets.get(i);
			subreq.put("objectStore", os);
			subreq.put("documentClass", className);

			JSONObject r = worker.execute(userID, subreq);
			JSONArray docs = (JSONArray) r.get("documents");
			for (int j = 0; j < docs.size(); j++) {

				documents.add(docs.get(j));
			}
			if (r.get("exception") != null) {
				exceptions.add(r.get("exception"));
				total += docs.size();
			} else {
				exceptions.add(null);
				success += (Integer) ((JSONObject) r.get("counts")).get("success");
				total += (Integer) ((JSONObject) r.get("counts")).get("total");
			}
		}
		BulkUpdatePluginLogger.logDebug("Total Documents Processed :" + total, "ClaimsWorker", "execute", userID);
		JSONObject counts = new JSONObject();
		counts.put("total", total);
		counts.put("success", success);

		JSONObject response = new JSONObject();
		response.put("documents", documents);
		response.put("exception", null);
		response.put("setExceptions", exceptions);
		response.put("counts", counts);

		return response;
	}

}
