package com.ibm.ddm.plugin.service.workers;

import java.util.ArrayList;

import java.util.HashMap;

import com.filenet.api.collection.IndependentObjectSet;
import com.filenet.api.collection.PageIterator;

import com.filenet.api.constants.RefreshMode;

import com.filenet.api.core.Document;
import com.filenet.api.core.Factory;
import com.filenet.api.events.CustomEvent;
import com.filenet.api.query.SearchSQL;
import com.filenet.api.query.SearchScope;
import com.ibm.ddm.plugin.service.utilities.BulkUpdatePluginLogger;
import com.ibm.ddm.plugin.service.utilities.Configuration;
import com.ibm.json.java.JSONObject;

/**
 * This class performs bulk updates on a given set of search criteria. It will
 * retrieve the documents via a CE search, check the validity and access to the
 * documents then any documents that are available for update, it will apply the
 * new properties and execute the updates.
 * 
 * @author Michael Oland, Philip Jacob
 *
 */
public class UpdateWorker extends ArrayWorker {
	private HashMap<String, String[]> whitelist = new HashMap<String, String[]>();

	public UpdateWorker() {
		super(UpdateUnit.class);

		whitelist.put(Configuration.class_underwriting,
				new String[] { Configuration.prop_policyNumber, Configuration.prop_submissionNumber,
						Configuration.prop_policyInceptionDate, Configuration.prop_businessTransactionType });

		whitelist.put(Configuration.class_claimDocument, new String[] { Configuration.prop_claimNumber,
				Configuration.prop_claimantName, Configuration.prop_claimSuffixNumber });

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.ibm.icn.custom.ffic.plugin.svc.workers.ArrayWorker#processArray(com.
	 * ibm.icn.custom.ffic.plugin.svc.utilities.FFICUser,
	 * com.ibm.icn.custom.ffic.plugin.svc.workers.ArrayUnit[])
	 */
	public void processArray(ArrayUnit[] units, String userID) throws Exception {

		if (units == null || units.length == 0)
			return;

		// We will do the updates in a batch for performance. It is possible
		// that this needs to be handled via
		// a chunked set of batch updates or a set of individual updates if it
		// is determined that too many
		// documents are being updated at a given time
		// UpdatingBatch batch =
		// UpdatingBatch.createUpdatingBatchInstance(getDomain(),
		// RefreshMode.NO_REFRESH);

		// Loop through the documents and process each one
		for (int i = 0; i < units.length; i++) {

			if (units[i].getDocument().get_IsReserved()) {
				BulkUpdatePluginLogger.logDebug(
						"Document is checked out by ::" + units[i].getDocument().get_LastModifier(), "UpdateWorker",
						"processArray", userID);
				// If the document is validated, add an exception indicating
				// they cannot update and skip
				units[i].setException(
						new Exception("Document is checked out by " + units[i].getDocument().get_LastModifier()));
				continue;
			}

			// The user has access to the document, so try preparing the updates
			try {
				BulkUpdatePluginLogger.logInfo("Update the document with the target properties", "UpdateWorker",
						"processArray", userID);
				updateDocument(units[i].getDocument());
				units[i].setPrepared(true);
				BulkUpdatePluginLogger.logInfo("Raise the custome event : BulkUpdate", "UpdateWorker", "processArray",
						userID);
				CustomEvent custEvent = Factory.CustomEvent.createInstance(units[i].getDocument().getObjectStore(),
						"BulkUpdate");
				units[i].getDocument().raiseEvent(custEvent);
				// Moved away from batch update. Batch will be used only for
				// tracking.: PJ 05/03/2013
				units[i].getDocument().save(RefreshMode.NO_REFRESH);
				units[i].getDocument().refresh();
				units[i].getDocument().getProperties().putValue(Configuration.prop_audit_action_flag,
						"Metadata Update");
				units[i].getDocument().setUpdateSequenceNumber(null);
				units[i].getDocument().save(RefreshMode.NO_REFRESH);
				((UpdateUnit) units[i]).setUpdated(true);
			} catch (Exception e) {

				BulkUpdatePluginLogger.logInfo("Exception while updating the document :" + e.getMessage(),
						"UpdateWorker", "processArray", userID);

				((UpdateUnit) units[i]).setUpdated(false);
				units[i].setException(e);
			}
		}
	}

	/**
	 * This is an overridden buildArray to handle building based on search
	 * criteria
	 * 
	 * @throws Exception
	 */
	@Override
	protected ArrayUnit[] buildArray(JSONObject request, String userID) throws Exception {
		JSONObject source = (JSONObject) request.get("source");
		String className = (String) request.get("documentClass");
		String objectStoreName = (String) request.get("objectStore");
		String folderpath = null;
		BulkUpdatePluginLogger.logDebug("ClassName :" + className, "UpdateWorker", "buildArray", userID);
		if (className.equalsIgnoreCase(Configuration.class_claimDocument))
			folderpath = Configuration.folderPath_Claims;
		if (className.equalsIgnoreCase(Configuration.class_underwriting))
			folderpath = Configuration.folderPath_Underwriting;
		BulkUpdatePluginLogger.logDebug("FolderName :" + folderpath, "UpdateWorker", "buildArray", userID);
		ArrayList<ArrayUnit> units = new ArrayList<ArrayUnit>();

		// Check to ensure the class is in the white list
		if (!whitelist.containsKey(className))
			throw new Exception("Invalid class name provided for search in UpdateDocuments " + className);

		String[] props = whitelist.get(className);

		StringBuilder s = new StringBuilder();
		s.append("select * from ");
		s.append(className);
		s.append(" where  " + className + ".This INFOLDER '" + folderpath + "' and IsCurrentVersion=true AND ");
		// + "Deleted<>'T' AND ");

		Object[] keys = source.keySet().toArray();

		for (int i = 0; i < keys.length; i++) {
			String value = (String) source.get(keys[i]);
			String key = (String) keys[i];
			if (key.equalsIgnoreCase("PolicyNumber"))
				key = Configuration.prop_policyNumber;
			if (key.equalsIgnoreCase("SubmissionNumber"))
				key = Configuration.prop_submissionNumber;
			if (key.equalsIgnoreCase("PolicyEffectiveDate"))
				key = Configuration.prop_policyInceptionDate;
			if (key.equalsIgnoreCase("BusinessTransactionType"))
				key = Configuration.prop_businessTransactionType;
			if (key.equalsIgnoreCase("ClaimNumber"))
				key = Configuration.prop_claimNumber;
			if (key.equalsIgnoreCase("ClaimantEntity"))
				key = Configuration.prop_claimantName;
			if (key.equalsIgnoreCase("ClaimSuffixnumber"))
				key = Configuration.prop_claimSuffixNumber;
			boolean valid = false;

			// Validate that the properties requested are in the white list
			for (int j = 0; j < props.length; j++) {
				if (key.equalsIgnoreCase(props[j])) {
					valid = true;
					break;
				}
			}

			if (!valid)
				throw new Exception("Invalid property name provided for search in UpdateDocuments " + key);

			if (i > 0)
				s.append(" AND ");

			s.append(key);
			boolean milliseconds = false;
			// PolicyEffectiveDate is a date, so don't surround the value in ''
			if (key.equalsIgnoreCase(Configuration.prop_policyInceptionDate)) {
				// Validate the characters in the value to ensure it's not
				// invalid
				for (int j = 0; j < value.length(); j++) {
					char c = value.charAt(j);

					if (!Character.isDigit(c) && c != 'T' && c != 'Z' && c != '.')

						throw new Exception("Invalid date value, contains invalid characters " + value);
					if (c == '.') {
						milliseconds = true;
					}
				}
				if (milliseconds) {

					String splitMilliseconds[] = value.split("\\.");
					value = splitMilliseconds[0] + "Z";
				}

				s.append(" = ");
				s.append(value); // YYYYMMDDTHHMMSSTZ (ie: 20130214T191150Z)
			} else {
				if (value == null) {
					s.append(" IS NULL ");
				} else {
					// Escape any 's with ''s to ensure no run away sql issues
					// If any other validations/clean ups needs to happen here.
					value = value.replaceAll("\'", "\'\'");

					s.append(" = \'");
					s.append(value);
					s.append("\'");
				}
			}
		}
		BulkUpdatePluginLogger.logDebug("Query :" + s, "UpdateWorker", "buildArray", userID);
		// Build and execute the CE search
		SearchSQL sql = new SearchSQL(s.toString());

		SearchScope scope = new SearchScope(this.getObjectStore(objectStoreName));

		IndependentObjectSet set = scope.fetchObjects(sql, 500, null, true);
		PageIterator pi = set.pageIterator();
		BulkUpdatePluginLogger.logInfo("Fetch the documents to be updated", "UpdateWorker", "buildArray", userID);
		while (pi.nextPage()) {
			Object[] docs = pi.getCurrentPage();
			for (int i = 0; i < docs.length; i++) {
				Document d = (Document) docs[i];
				BulkUpdatePluginLogger.logDebug("Doc ID :" + d.get_Id(), "UpdateWorker", "buildArray", userID);
				UpdateUnit unit = new UpdateUnit();
				unit.assignId(d.get_Id().toString());
				unit.assignNamePropertyByClass(className);
				unit.setDocument(d);
				unit.setValid(true);
				unit.setRetrieved(true);
				units.add(unit);
			}
		}

		return units.toArray(new ArrayUnit[units.size()]);
	}

	private void updateDocument(Document document) throws Exception {
		this.updateDocumentProperties(document, targetProperties);
	}

}
