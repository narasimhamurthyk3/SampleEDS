package com.ibm.ddm.plugin.service.workers;

import com.filenet.api.util.Id;

public class UpdateUnit extends ArrayUnit {
	private boolean updated = false;

	public final boolean isUpdated() {
		return updated;
	}

	public final void setUpdated(boolean updated) {
		this.updated = updated;
	}

	@Override
	protected String getStatus() {
		if (updated)
			return "Complete";

		if (isPrepared())
			return "Failed updating document";

		return super.getStatus();
	}

	@Override
	public boolean isSuccessful() {
		return updated;
	}

	@Override
	public void assignId(String id) {
		this.id = id;
		this.objectId = new Id(id);
	}
}
