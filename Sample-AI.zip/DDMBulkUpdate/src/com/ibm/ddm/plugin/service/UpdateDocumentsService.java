package com.ibm.ddm.plugin.service;

import com.ibm.ddm.plugin.service.workers.BaseWorker;
import com.ibm.ddm.plugin.service.workers.UpdateWorker;

/**
 * Provides the update document service.
 * 
 * @author Michael Oland
 *
 */
public class UpdateDocumentsService extends PostService
{
	@Override
	public String getId()
	{
		return "UpdateDocumentsService";
	}

	@Override
	public BaseWorker getWorker()
	{
		return new UpdateWorker();
	}
}
