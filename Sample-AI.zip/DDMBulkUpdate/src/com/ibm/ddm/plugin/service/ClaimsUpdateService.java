package com.ibm.ddm.plugin.service;

import com.ibm.ddm.plugin.service.workers.BaseWorker;
import com.ibm.ddm.plugin.service.workers.ClaimsWorker;

/**
 * Provides a unique update service for bulk updating claims documents.
 * 
 * @author Michael Oland
 *
 */
public class ClaimsUpdateService extends PostService {
	@Override
	public String getId() {
		return "ClaimsUpdateService";
	}

	@Override
	public BaseWorker getWorker() {
		return new ClaimsWorker();
	}
}
