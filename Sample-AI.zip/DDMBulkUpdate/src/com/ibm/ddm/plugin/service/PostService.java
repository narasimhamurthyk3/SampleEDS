package com.ibm.ddm.plugin.service;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

import javax.security.auth.Subject;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.filenet.api.core.Domain;
import com.filenet.api.core.ObjectStore;
import com.filenet.api.exception.EngineRuntimeException;
import com.filenet.api.util.UserContext;
import com.ibm.ddm.plugin.service.utilities.BulkUpdatePluginLogger;
import com.ibm.ddm.plugin.service.workers.BaseWorker;
import com.ibm.ecm.extension.PluginService;
import com.ibm.ecm.extension.PluginServiceCallbacks;
import com.ibm.json.java.JSONObject;

/**
 * Handles any POST-based services.
 * 
 * @author Michael Oland
 *
 */
public abstract class PostService extends PluginService {
	/**
	 * Requests the plugin for the worker to execute.
	 * 
	 * @return Initialized and ready worker object
	 */
	public abstract BaseWorker getWorker();

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.ibm.ecm.extension.PluginService#execute(com.ibm.ecm.extension.
	 * PluginServiceCallbacks, javax.servlet.http.HttpServletRequest,
	 * javax.servlet.http.HttpServletResponse)
	 */
	public void execute(PluginServiceCallbacks callbacks, HttpServletRequest request, HttpServletResponse response)
			throws Exception {

		BaseWorker worker = getWorker();

		String repositoryId = callbacks.getRepositoryId();
		String userID = request.getParameter("userID");

		JSONObject rs = null;
		try {
			Subject subject = callbacks.getP8Subject(repositoryId);
			UserContext.get().pushSubject(subject);
			ObjectStore obs = callbacks.getP8ObjectStore(repositoryId);
			BulkUpdatePluginLogger.logDebug("ObjectStore ::" + obs.get_Name(), "PostService", "execute", userID);
			Domain d = callbacks.getP8Domain(repositoryId, null);
			worker.setDomain(d);
			JSONObject rq = parseRequest(request);

			rs = worker.execute(userID, rq);
		} catch (EngineRuntimeException e) {

			BulkUpdatePluginLogger.logException(e, "PostService", "execute", userID);
			throw e;
		} finally {
			UserContext.get().popSubject();
		}

		response.setHeader("Content-Type", "application/json");

		OutputStream os = response.getOutputStream();
		rs.serialize(os);
		os.close();
	}

	/**
	 * Parses the provided JSON payload.
	 * 
	 * @param request
	 *            Servlet request object
	 * @return JSON object representation of the request
	 * @throws IOException
	 */
	protected JSONObject parseRequest(HttpServletRequest request) throws IOException {

		InputStream is = request.getInputStream();
		JSONObject r = JSONObject.parse(is);
		is.close();

		return r;
	}

}