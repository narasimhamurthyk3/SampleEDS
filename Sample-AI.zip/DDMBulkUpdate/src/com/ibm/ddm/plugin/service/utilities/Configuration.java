package com.ibm.ddm.plugin.service.utilities;

/**
 * Provides a simple wrapper around loaded configuration for the plugin
 * 
 * @author Michael Oland, Philip Jacob
 *
 */
public class Configuration {

	public static String prop_policyNumber = null;
	public static String prop_submissionNumber = null;
	public static String prop_insuredName = null;
	public static String prop_policyInceptionDate = null;
	public static String prop_businessTransactionType = null;
	public static String prop_claimNumber = null;
	public static String prop_claimantName = null;
	public static String prop_claimSuffixNumber = null;
	public static String prop_documentCategory = null;
	public static String prop_documentSubCategory = null;
	public static String prop_documentTitle = null;
	public static String prop_audit_action_flag = null;
	public static String prop_action_performed = null;
	public static String class_claimDocument = null;
	public static String class_underwriting = null;
	public static String folderPath_Underwriting = null;
	public static String folderPath_Claims = null;
	public static String prop_claim_documentCategory = null;
	public static String prop_claim_documentSubCategory = null;
}
