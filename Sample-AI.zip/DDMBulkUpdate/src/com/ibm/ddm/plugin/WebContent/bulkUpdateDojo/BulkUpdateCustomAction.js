define(["dojo/_base/declare", 
        "ecm/model/Action",
        "ecm/model/Request"
],
function(declare,
		Action,
		Request) {

	/**
	 * @name bulkUpdateDojo.BulkUpdateCustomAction
	 * @class Describes a user-executable action. Used to override the standard code for enabling/disabling
	 * menu actions.
	 * @augments ecm.model.Action
	 */
	return declare("bulkUpdateDojo.BulkUpdateCustomAction", [ Action ], {
	/** @lends samplePluginDojo.CustomAction.prototype */
	
		/**
		 * Returns true if this action should be enabled for the given repository, list type, and items.
		 */
		isEnabled: function(repository, listType, items, teamspace, resultSet) {
					
			if(items.length>1)
				return false;
		
			if((items[0].getContentClass().id=="Claim_Document" && items[0].getPath()[0].folders[0].name=="/Claim Documents") || 
					(items[0].getContentClass().id=="Underwriting_Document" && items[0].getPath()[0].folders[0].name=="/Underwriting Documents"))
			{
				
				if(items[0].hasPrivilege("privEditProperties"))
					return true;
				else
					return false;
			}
			else
				return false;
			
		},
	
		/**
		 * Returns true if this action should be visible for the given repository and list type.
		 */
		isVisible: function(repository, listType) {
		
			return true;
			
		}
	});
});
