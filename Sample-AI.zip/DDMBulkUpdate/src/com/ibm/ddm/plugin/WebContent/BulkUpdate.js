require(["dojo/_base/declare",
         "dojo/_base/lang",
         "ecm/model/Request",
		 "bulkUpdateDojo/BulkUpdateDialog"
		], 
function(declare, 
		lang,
		Request,
		BulkUpdateDialog
		) {

	lang.setObject("bulkUpdateAction", function (repository, items) {
		var serviceParams = new Object();
		serviceParams.repositoryID = items[0].repository.id;
		serviceParams.osName = items[0].objectStore.symbolicName;
		serviceParams.userID = items[0].repository.userId;
		// this is asynchronous request.  Using asynch is preferred although slightly more complicated to code
		Request.invokePluginService("BulkUpdate", "ReadConfigFileService",
			{
				requestParams: serviceParams,
				requestCompleteCallback: function(response) {	// success
					
					if(response && response.isInvokeService=="true")
					{
						var bulkUpdateDlg = new BulkUpdateDialog();
						bulkUpdateDlg.show(repository, items, response);
					}
					
				}
			}
		);
		
	});
});	
