define(["dojo/_base/declare",
        "dojo/_base/lang",
        "ecm/model/Desktop",
        "ecm/MessagesMixin",
        "ecm/widget/dialog/BaseDialog",
        "ecm/widget/TextBox",
        "ecm/widget/DatePicker",
        "ecm/widget/FilteringSelect",
        "ecm/widget/dialog/StatusDialog",
        "ecm/widget/RadioButton",
        "dijit/form/Form",
        "dijit/form/DropDownButton",
        "dijit/TooltipDialog",
        "dojo/data/ItemFileReadStore",
        "dojox/grid/DataGrid",
        "dijit/layout/ContentPane",
        "ecm/widget/dialog/MessageDialog",
        "ecm/model/Request",
    	"dojo/text!bulkUpdateDojo/templates/BulkUpdateDialog.html",
    	"dojo/date/locale"
],

function(declare, 
lang, //
Desktop,
MessagesMixin,
BaseDialog,
TextBox,
DatePicker, //
FilteringSelect,
StatusDialog,
RadioButton,
Form, //
DropDownButton,
TooltipDialog,
ItemFileReadStore,
DataGrid,
ContentPane,
MessageDialog,
Request,
template,locale) {

	/**
	 * @name bulkUpdateDojo.BulkUpdateDialog.js
	 * @class Provides a dialog box that is used choose a document to be Undeleted.
	 * @augments ecm.widget.dialog.BaseDialog
	 */
	
	
	return declare("bulkUpdateDojo.BulkUpdateDialog", [
		BaseDialog
	], {

		widgetsInTemplate: true,
		contentString: template,
		
		_lookupKey: null,
		_targetPolicySubmissionNumber: null,
		_documentClass: null,
		_grid: null,
		
		_sourcebtt: null,
		_submissionNumber: "",
		_policyNumber: "",
		_docIsValidatedBySource:"", 
		_policyEffectiveDate:"",
		_policyEffectiveDateStr:"",

		_insuredName:"",
		_adjProcId:"",
		_mgrProcId:"",
		_policyNumber:"",
		_matchingClaims: null,
		_sourceDBRow: null,
		
		_claimNumber:"",
		_claimantEntity:"",
		
		_items: null,
		_repository: null,
		_onePolicyOrSubmission: null,
		
		_isPolSubValidatedBySource:false,
		_isClaimValidatedBySource:false,
		_statusDlg: null,
		_workingDlg: null,
		
		policyNumber:null,
		submissionNumber:null,
		policyInceptionDate:null,
		businessTransactionType:null,
		insuredName:null,
		claimDocument:null,
		underwriting:null,
		claimNumber:null,
		claimantName:null,
		auditActionFlag:null,
		actionPerformed:null,
		parent:null,
		postCreate: function() {
			parent=this;
			this.inherited(arguments);
			
			this._statusDlg = new StatusDialog();
			this._statusDlg.contentNode.innerHTML="Updating Documents...";
			this._statusDlg.showActionBar(false);
			
			this._workingDlg = new StatusDialog();
			this._workingDlg.contentNode.innerHTML="Working...";
			this._workingDlg.showActionBar(false);
			
		},
		
		show: function(repository, items, response) {
			var docTitle="";
			
			this._repository = repository;
			this._items = items;
			policyNumber=response.PolicyNumber;
			submissionNumber=response.SubmissionNumber;
			policyInceptionDate=response.PolicyInceptionDate;
			businessTransactionType=response.BusinessTransactionType;
			insuredName=response.InsuredName;
			claimDocument=response.ClaimDocument;
			underwriting=response.Underwriting;
			claimNumber=response.ClaimNumber;
			claimantName=response.ClaimantName;
			auditActionFlag=response.AuditActionFlag;
			actionPerformed=response.ActionPerformed;
			
			this.setTitle("Bulk Update");
			
			this._documentClass = items[0].getContentClass().id;
			
			if(this._documentClass==claimDocument){
				dojo.style(this._targetUpdateTypePolicy,"display","none");
				dojo.style(this._targetPolicyRow,"display","none");
				dojo.style(this._targetUpdateLevelClaims,"display","block");
				dojo.style(this._targetUpdateTypeClaims,"display","block");
				dojo.style(this._targetClaimRow,"display","block");
				dojo.style(this._matchingClaimsRow,"display","block");
				this._lookupKey=claimNumber;
				this._claimNumber=this._items[0].getValue(claimNumber);
				this._claimantEntity=this._items[0].getValue(claimantName); 
				
				docTitle= "&#160;<b>Claim #:&#160;</b>" + this._claimNumber;
				
				this._targetClaimNumberLabel.innerHTML=this._targetClaimNumberLabel.innerHTML+ " <b>"+this._claimNumber+"</b> to:";
				this._targetClaimantEntityLabel.innerHTML=this._targetClaimantEntityLabel.innerHTML+ " <b>"+this._claimantEntity+"</b> to:";
			
				var claimText = " Claim # <b>"+this._claimNumber+"</b> ";
				var claimantText = " Claimant/Entity Name <b>"+this._claimantEntity+"</b> ";
				
				this._radioClaimLevelCellLabel.innerHTML=claimText;
				this._radioClaimClaimantLevelCellLabel.innerHTML= claimText + "and" + claimantText ;
				
				this._updateButton = this.addButton("Update", "_onClickClaimsUpdate", true, true);

				this._createEmptyGrid();

				this._showClaimOptions();
				this._showClaimTypeOptions();
			}
			
			else{
				dojo.style(this._targetUpdateLevelClaims,"display","none");
				dojo.style(this._targetUpdateTypeClaims,"display","none");
				dojo.style(this._targetClaimRow,"display","none");
				dojo.style(this._matchingClaimsRow,"display","none");
				
				if(this._items[0].hasAttribute(businessTransactionType)){
					this._sourcebtt = this._items[0].getValue(businessTransactionType);
					
					this._policyEffectiveDate = this._items[0].getValue(policyInceptionDate);
					
					this._insuredName=this._items[0].getValue(insuredName);
					
					this._policyEffectiveDateStr = this.formatDateFromIso(this._policyEffectiveDate);
					
					this._targetPolicyEffectiveDate.constraints.fullYear=true;
					this._targetEntityRowLabel.innerHTML = this._targetEntityRowLabel.innerHTML + " <b>"+this._insuredName+"</b> to";
					this._targetPolicyEffectiveDateRowLabel.innerHTML = this._targetPolicyEffectiveDateRowLabel.innerHTML + " <b>"+this._policyEffectiveDateStr+"</b> to:";
					
					if(this._sourcebtt=="Policy"){
						this._policyNumber=this._items[0].getValue(policyNumber);
						this._radioNewPolicyLabel.innerHTML="New Policy #";
						this._lookupKey=policyNumber;
						this._targetPolSubRowLabel.innerHTML=this._targetPolSubRowLabel.innerHTML + "<span> Policy # <b>"+this._policyNumber+"</b> to </span>";
						dojo.style(this._radioConvertSubCell,"display","none");
						this._radioNewPolicy.attr("checked",true);
						
						docTitle= "&#160;<b>Policy #:&#160;</b>" + this._policyNumber;
						docTitle=docTitle+"&#160;<b>Policy Inception Date:&#160;</b>" + this._policyEffectiveDateStr;
					}
					else{
						
						this._submissionNumber=this._items[0].getValue(submissionNumber);
						this._radioNewPolicyLabel.innerHTML="New Submission #";
						this._lookupKey=submissionNumber;
						this._targetPolSubRowLabel.innerHTML=this._targetPolSubRowLabel.innerHTML + "<span> Submission # <b>"+this._submissionNumber+"</b> to </span>";
						docTitle= "&#160;<b>Submission #:&#160;</b>" + this._submissionNumber;
						
						this._radioConvertSub.attr("checked",true);
					}
					
				}

				this._updateButton = this.addButton("Update", "_onClickUpdate", true, true);
				this._createEmptyGrid();
			}
			
			
			//Set the heading
			this.introText.innerHTML = docTitle;
			
			//Hide the unvalidated date on load 
			dojo.style(this._targetPolicyEffectiveDate.domNode,"display","none");
			
			this.inherited("show", []);
		},
		
		_onClickUpdate: function(e) {
			
			if(this._updateButton.get("disabled")){
				return false;
			}	
			
			var copyDocsPayload = new Object();
			var docGuids = new Array();
			var updateProps=new Object();
			updateProps.properties=new Array();
			var contentType= "application/json";
			var params = new Object();
			var updateType = this._optionsFormPolicy.attr('value').updatetype;

			params.repositoryId = this._items[0].repository.id;
			params.os = this._items[0].objectStore.symbolicName;
			params.type = this._items[0].repository.type;
			params.server = this._items[0].repository.id;
			params.serverType = this._items[0].repository.type;
			params.userID = this._items[0].repository.userId;
			
			var updatePolSubPayload = new Object();
			updatePolSubPayload.documentClass=this._documentClass;
			updatePolSubPayload.objectStore=this._items[0].objectStore.symbolicName;

			//Setup the where clause of documents to include in this update
			var sourceProps = new Object();
			sourceProps.BusinessTransactionType= this._sourcebtt;
			if(this._sourcebtt=="Policy"){
				sourceProps.PolicyNumber = this._policyNumber;
				var ceDateStr = "";
				if(this._policyEffectiveDate!=null){
					ceDateStr = this._policyEffectiveDate.replace("-","");
					ceDateStr=ceDateStr.replace("-","");
					ceDateStr=ceDateStr.replace(":","");
					ceDateStr=ceDateStr.replace(":","");
				}
				sourceProps.PolicyEffectiveDate = ceDateStr;
				
			}else{
				sourceProps.SubmissionNumber = this._submissionNumber;
				var ceDateStr = "";
				if(this._policyEffectiveDate!=null){
					ceDateStr = this._policyEffectiveDate.replace("-","");
					ceDateStr=ceDateStr.replace("-","");
					ceDateStr=ceDateStr.replace(":","");
					ceDateStr=ceDateStr.replace(":","");
				}
				sourceProps.PolicyEffectiveDate = ceDateStr;
			}
			
			
			
			switch(parseInt(updateType)){
				case 1:
					//Copy to new policy or submission
					updateProps.properties.push(this.getPropertyObject(this._lookupKey,this._targetPolicySubNumber.get('value')));
					break;
				case 2:
					//Convert sub to pol
					updateProps.properties.push(this.getPropertyObject(policyNumber,this._targetPolicySubNumber.get('value')));					
					updateProps.properties.push(this.getPropertyObject(businessTransactionType,"Policy"));
					break;
				case 3:
					// Multiple Data Elements
					if(this._targetEntityName.get('value').trim().length>0)
						updateProps.properties.push(this.getPropertyObject(insuredName,this._targetEntityName.get('value')));
					if(this._targetPolicySubNumber.get('value').trim().length>0)
						updateProps.properties.push(this.getPropertyObject(this._lookupKey,this._targetPolicySubNumber.get('value')));
					if(this._targetPolicyEffectiveDate.get('value')!=null && this._targetPolicyEffectiveDate.isValid())
						updateProps.properties.push(this.getPropertyObject(policyInceptionDate,this.getDateInIso(this._targetPolicyEffectiveDate.get('value'))));
					break;
				case 4:
					//Insured name only
					updateProps.properties.push(this.getPropertyObject(insuredName,this._targetEntityName.get('value')));
					break;	
				case 5:
					//Policy Inception Date
					updateProps.properties.push(this.getPropertyObject(policyInceptionDate,this.getDateInIso(this._targetPolicyEffectiveDate.get('value'))));
					break;	
				
			}
			
			updateProps.properties.push(this.getPropertyObject(auditActionFlag,'BulkUpdate'));
			updatePolSubPayload.source = sourceProps;
			updatePolSubPayload.target = updateProps ;
			
			var displayUpdateStatusFn = dojo.hitch(this,"_displayUpdateStatus");
			var postParams = new Object();
			postParams.requestParams = params;
			postParams.requestBody = dojo.toJson(updatePolSubPayload);
			postParams.requestCompleteCallback = displayUpdateStatusFn;
			postParams.requestFailedCallback = dojo.hitch(this,function(response) {
													console.debug("Error",response);
													this.setMessage("Error Occured:" + response,"error");
													this._statusDlg.hide();
													}
												);
			Request.postPluginService(
					"BulkUpdate",
					"UpdateDocumentsService",
					contentType,
					postParams			
			);
		
			this._statusDlg.show();
			
		},
		
		_createEmptyGrid: function() {
			console.debug("Entering:createGrid >>",this);
			var colHdr="";
			var colField ="";
			var layout;
			this._destroyGrid();

			if(this._documentClass==claimDocument){
				
				layout = [[
					           {'name': 'Claim #', 'field': 'ClaimNumber','width': '60px'},
					           {'name': 'Document Title', 'field': 'title', 'width': '100px'},
					           {'name': 'Claimant/Entity Name', 'field': 'claimantentity', 'width': '80px'},
					           {'name': 'Document Category', 'field': 'ClaimDocumentCategory', 'width': '120px'},
					           {'name': 'Document Sub Category', 'field': 'ClaimDocumentSubCategory', 'width': '120px'},
					           {'name': 'Update Status', 'field': 'status'},
					           {'name': 'Error Description', 'field': 'ErrorDescription', 'width': '200px'}
							 ]];
				
			}else{
				colHdr = (this._sourcebtt=='Submission'?'Submission #':'Policy #');
				colField = (this._sourcebtt=='Submission'?'SubmissionNumber':'PolicyNumber');
				layout = [[
				           {'name': colHdr, 'field': colField, 'width': '110px'},
				           {'name': 'Document Title', 'field': 'title', 'width': '130px'},
				           {'name': 'Document Category', 'field': 'DocumentCategory', 'width': '130px'},
				           {'name': 'Document Sub Category', 'field': 'DocumentSubCategory', 'width': '150px'},
				           {'name': 'Update Status', 'field': 'status', 'width': '90px'},
				           {'name': 'Error Description', 'field': 'ErrorDescription', 'width': '200px'}
						 ]];
			}
			
			
 
		    /*set up data store*/
		    var data = {
		      identifier: "guid",
		      items: []
		    };
		    
		    var store = new ItemFileReadStore({data: data});
		    
			  /*create a new grid:*/
			this._grid = new DataGrid({
		        structure: layout,
		        store: store,
		        selectionMode: "single",
		        
		        });

			  /*append the new grid to the div*/
		    this._updateStatusGrid.appendChild(this._grid.domNode);
			
		     /*Call startup() to render the grid*/
			this._grid.startup();
			
		},
		

		_enableUpdate: function(e){

			this._updateButton.set("disabled",true);
			
			if(this._documentClass==claimDocument){
				var updateLevel = this._optionsFormClaimsLevel.attr('value').claimupdatelevel;
				var updateType = this._optionsFormClaimsType.attr('value').claimupdatetype;
				switch(parseInt(updateType)){
					case 1: 
						
							if (!this._targetClaimNumber.isValid())
								return false;
						

						break;
					case 3:
					
						if(this._targetClaimantEntity.focusNode.value.trim().length==0 && this._targetClaimNumber.focusNode.value.trim().length==0){
							return false;
							
						}
						
						break;
					case 4:
						if(!this._targetClaimantEntity.isValid())
							return false;
						break;
					
				}
				
	    		
	    	}else{
	    		var updateType = this._optionsFormPolicy.attr('value').updatetype;
	    		this._targetPolicyEffectiveDate.constraints.fullYear=true;
				switch(parseInt(updateType)){
					
					case 3:
						
						if(this._targetEntityName.focusNode.value.trim().length==0 && this._targetPolicySubNumber.focusNode.value.trim().length==0 && this._targetPolicyEffectiveDate.focusNode.value.trim().length==0){
							this._targetPolicyEffectiveDate.constraints.fullYear=true;
							return false;
							
						}
						
						if(this._targetPolicyEffectiveDate.focusNode.value.trim().length>0 && !(this._targetPolicyEffectiveDate.isValid())){
							this._targetPolicyEffectiveDate.constraints.fullYear=true;
							return false;
						}
						
						break;
					case 4:
						if(!(this._targetEntityName.isValid()))
			    			return false;
						break;
					case 5:
						if(!(this._targetPolicyEffectiveDate.isValid())){
							this._targetPolicyEffectiveDate.constraints.fullYear=true;
							return false;
						}
			    			
						break;
					default:
						if(updateType==1 || updateType==2){
							if(!(this._targetPolicySubNumber.isValid()))
				    			return false;
						}
						
						break;
				}
			}
	    		
			//If we got till here, enable update
	    	this._updateButton.set("disabled",false);
	    	
			return true;
		},

		_destroyGrid: function() {
			if (this._grid ) {
				this._grid.destroy();
			}
		},
		
		
				
		_displayUpdateStatus: function(retPayload){
			console.debug("Entering:_displayUpdateStatus",retPayload);
			this._statusDlg.hide();
			
			if(retPayload.exception!=null){
				this.setMessage("Error Occured: " + retPayload.exception.message,"error");
			}else{
				var updateStatus = retPayload.counts.success + " of " + retPayload.counts.total + " documents updated" 
															+ (parseInt(retPayload.counts.success)==0? "" :" successfully. ");
				
				var msgType="info";
				if(parseInt(retPayload.counts.success)==0)
					msgType = "error";
				else if(parseInt(retPayload.counts.success)<parseInt(retPayload.counts.total))
					msgType = "warning";
				
				this.setMessage(updateStatus,msgType);
			}
			
		    /*set up data store*/
		    var data = {
		      identifier: "guid",
		      items: retPayload.documents
		    };
		    var store = new ItemFileReadStore({data: data});
		    this._grid.setStore(store);
		  
		    this._updateButton.set("disabled",true);
		    
		    if(this._documentClass==claimDocument){
		    	
		    	this._radioClaimClaimantLevel.attr("disabled",true);
		    	this._radioClaimLevel.attr("disabled",true);
		    	this._radioClaimNumberType.attr("disabled",true);
		    	this._radioClaimClaimantType.attr("disabled",true);
		    	this._radioClaimantType.attr("disabled",true);
				this._targetClaimNumber.attr("disabled",true);
				this._targetClaimantEntity.attr("disabled",true);
		    }
		    else{
		    	this._radioConvertSub.attr("disabled",true);
				this._radioNewPolicy.attr("disabled",true);
				this._radioNewPolicyEffDate.attr("disabled",true);
				this._radioMultipleData.attr("disabled",true);
				this._radioNewEntity.attr("disabled",true);
		    	this._radioConvertSub.attr("disabled",true);
		    	this._targetPolicySubNumber.attr("disabled", true);
		    	this._targetEntityName.attr("disabled", true);
		    	this._targetPolicyEffectiveDate.attr("disabled", true);	
		    }
		   
		   
		    
		    this._radioConvertSub.attr("disabled",true);
		    this._radioConvertSub.attr("disabled",true);
		    
		},
		
		
		_showPolSubElements : function(e){
				
			var updateType = this._optionsFormPolicy.attr('value').updatetype;
			
			dojo.style(this._targetPolSubRowLabel,"display","none");
			dojo.style(this._targetPolicySubNumber.domNode,"display","none");
			dojo.style(this._targetEntityRowLabel,"display","none");
			dojo.style(this._targetEntityName.domNode,"display","none");			
			dojo.style(this._targetPolicyEffectiveDateRowLabel,"display","none");
			dojo.style(this._targetPolicyEffectiveDate.domNode,"display","none");
			
			this._targetPolicySubNumber.set("value","");
			this._targetPolicyEffectiveDate.set("value",null);
			this._targetEntityName.set("value","");
			
			
			if(this._sourcebtt=="Policy"){
				this._lookupKey=policyNumber;
				this._targetPolSubRowLabel.innerHTML="Update Policy # <b>"+this._policyNumber+"</b> to ";
			}else{
				this._lookupKey=submissionNumber;
				this._targetPolSubRowLabel.innerHTML="Update Submission # <b>"+this._submissionNumber+"</b> to ";
			}
				
			switch (parseInt(updateType)){
				case 1:
					//new polsub
					dojo.style(this._targetPolSubRowLabel,"display","block");
					dojo.style(this._targetPolicySubNumber.domNode,"display","block");

					dojo.style(this._targetEntityRowLabel,"display","none");
					dojo.style(this._targetEntityName.domNode,"display","none");					
					dojo.style(this._targetPolicyEffectiveDateRowLabel,"display","none");
					dojo.style(this._targetPolicyEffectiveDate.domNode,"display","none");
					dojo.style(this._newPolicyEffDateCell,"display","none");
					this._targetPolicySubNumber.set("required",true);
					break;
				case 2:
					//Convert to Pol
					dojo.style(this._targetPolSubRowLabel,"display","block");
					dojo.style(this._targetPolicySubNumber.domNode,"display","block");

					dojo.style(this._targetEntityRowLabel,"display","none");
					dojo.style(this._targetEntityName.domNode,"display","none");					
					
					dojo.style(this._targetPolicyEffectiveDateRowLabel,"display","none");
					dojo.style(this._targetPolicyEffectiveDate.domNode,"display","none");
					dojo.style(this._newPolicyEffDateCell,"display","none");
					this._targetPolicySubNumber.set("required",true);
					this._lookupKey=policyNumber;
					this._targetPolSubRowLabel.innerHTML="Convert to Policy #";

					break;
				case 3:
					//Update Multiple Data Elements
					dojo.style(this._targetPolSubRowLabel,"display","block");
					dojo.style(this._targetPolicySubNumber.domNode,"display","block");
					
					dojo.style(this._targetEntityRowLabel,"display","block");
					dojo.style(this._targetEntityName.domNode,"display","block");					
					dojo.style(this._newPolicyEffDateCell,"display","block");
					dojo.style(this._targetPolicyEffectiveDateRowLabel,"display","block");
					dojo.style(this._targetPolicyEffectiveDate.domNode,"display","block");
					this._targetPolicyEffectiveDate.constraints.fullYear=true;
					
					this._targetPolicySubNumber.set("required",false);
					this._targetEntityName.set("required",false);
					this._targetPolicyEffectiveDate.set("required",false);
					
					break;
				case 4:
					//New Insured Entity
					dojo.style(this._targetEntityRowLabel,"display","block");
					dojo.style(this._targetEntityName.domNode,"display","block");	
					dojo.style(this._targetPolSubRowLabel,"display","none");
					dojo.style(this._targetPolicySubNumber.domNode,"display","none");
					dojo.style(this._newPolicyEffDateCell,"display","none");
					dojo.style(this._targetPolicyEffectiveDateRowLabel,"display","none");
					dojo.style(this._targetPolicyEffectiveDate.domNode,"display","none");
					this._targetEntityName.set("required",true);

					break;
				case 5:
					dojo.style(this._targetPolSubRowLabel,"display","none");
					dojo.style(this._targetPolicySubNumber.domNode,"display","none");

					dojo.style(this._targetEntityRowLabel,"display","none");
					dojo.style(this._targetEntityName.domNode,"display","none");					
					dojo.style(this._newPolicyEffDateCell,"display","block");
					dojo.style(this._targetPolicyEffectiveDateRowLabel,"display","block");
					dojo.style(this._targetPolicyEffectiveDate.domNode,"display","block");
					this._targetPolicyEffectiveDate.constraints.fullYear=true;
					this._targetPolicyEffectiveDate.set("required",true);
					break;
			}
			
			
		},
		
		_showClaimOptions : function(e){
			console.debug("Entering:_showClaimOptions ");
			var updateLevel = this._optionsFormClaimsLevel.attr('value').claimupdatelevel;
			
			
			if(parseInt(updateLevel)==1)
			{
				dojo.style(this._radioClaimClaimantTypeCell,"display","none");
				dojo.style(this._radioClaimantTypeCell,"display","none");
				dojo.style(this._radioClaimTypeCell,"display","block");
				this._radioClaimNumberType.attr("checked",true);
				
			}
			if(parseInt(updateLevel)==2)
			{
				dojo.style(this._radioClaimTypeCell,"display","none");
				dojo.style(this._radioClaimClaimantTypeCell,"display","block");
				dojo.style(this._radioClaimantTypeCell,"display","block");
				this._radioClaimClaimantType.attr("checked",true);
			}
			
			this._showClaimTypeOptions(e);
		},
		
		_showClaimTypeOptions : function(e){
			
			
			var updateLevel = this._optionsFormClaimsLevel.attr('value').claimupdatelevel;
			var updateType = this._optionsFormClaimsType.attr('value').claimupdatetype;
			
			
		    //Clear all fields
		    this._clearClaimFields(true);
		    
		    //Default all the cells to hidden
			dojo.style(this._targetClaimNumberLabel,"display","none");
			dojo.style(this._targetClaimNumber.domNode,"display","none");
			
		    
		    dojo.style(this._targetClaimantEntityLabel,"display","none");
		    dojo.style(this._targetClaimantEntity.domNode,"display","none");
		    dojo.style(this._matchingClaimsRow,"display","none");
		    
			switch(parseInt(updateType)){
				case 1:
						dojo.style(this._targetClaimNumberLabel,"display","block");
						dojo.style(this._targetClaimNumber.domNode,"display","block");
						dojo.style(this._targetClaimantEntityLabel,"display","none");
					    dojo.style(this._targetClaimantEntity.domNode,"display","none");
					    this._targetClaimNumber.set("required",true);
					
					break;
				case 2:
					dojo.style(this._targetClaimNumberLabel,"display","none");
					dojo.style(this._targetClaimNumber.domNode,"display","none");
					
				    dojo.style(this._targetClaimantEntityLabel,"display","none");
				    dojo.style(this._targetClaimantEntity.domNode,"display","none");
				    
					break;
				case 3:
					dojo.style(this._targetClaimNumberLabel,"display","block");
					dojo.style(this._targetClaimNumber.domNode,"display","block");
					
				    dojo.style(this._targetClaimantEntityLabel,"display","block");
				    dojo.style(this._targetClaimantEntity.domNode,"display","block");
				    this._targetClaimNumber.set("required",false);
					this._targetClaimantEntity.set("required",false);
				    
				    
					break;
				case 4:
					dojo.style(this._targetClaimNumberLabel,"display","none");
					dojo.style(this._targetClaimNumber.domNode,"display","none");
					
				    dojo.style(this._targetClaimantEntityLabel,"display","block");
				    dojo.style(this._targetClaimantEntity.domNode,"display","block");
				    
					this._targetClaimantEntity.set("required",true);
					break;
			}
		    
			this._enableUpdate();
			
		},
		
		_clearClaimFields: function(clearKeyFields){
			
			if(clearKeyFields){
				this._targetClaimNumber.set("value","");
			}
			
			this._targetClaimantEntity.set("value","");
		},
		
		_formatToShortDate: function(dateIn){
			if(dateIn==undefined || dateIn=="") 
				return null
			else{
				var d = dojo.date.stamp.fromISOString(dateIn);
				return dojo.date.locale.format(d, {selector: "date", formatLength: "short"});
			}
		},	

		_onClickClaimsUpdate: function(e){
			
			if(this._updateButton.get("disabled")){
				return false;
			}
			
			var updateLevel = this._optionsFormClaimsLevel.attr('value').claimupdatelevel;
			var updateType = this._optionsFormClaimsType.attr('value').claimupdatetype;
			var updateLevelInt = parseInt(updateLevel);
			var updateTypeInt = parseInt(updateType);
			
			var updateClaimsPayload = new Object();
			updateClaimsPayload.documentClass=this._documentClass;
			updateClaimsPayload.objectStore=this._items[0].getObjectStore().symbolicName;
			
			var source = new Object();
			var target = new Object();
			target.properties = new Array();
			
			switch(updateLevelInt){
				case 1:
					source.ClaimNumber=this._claimNumber;
					break;
				case 2:
					source.ClaimNumber=this._claimNumber;
					source.ClaimantEntity=this._claimantEntity;
					
					break;
			}
			
			switch(updateTypeInt){
				case 1:
						target.properties.push(this.getPropertyObject(claimNumber, this._targetClaimNumber.get('value')));
					break;
				
					
				case 3:
					if(this._targetClaimNumber.get('value').trim().length>0)
						target.properties.push(this.getPropertyObject(claimNumber, this._targetClaimNumber.get('value')));
					if(this._targetClaimantEntity.get('value').trim().length>0)
						target.properties.push(this.getPropertyObject(claimantName, this._targetClaimantEntity.get('value')));
					break;
					
				case 4:
					target.properties.push(this.getPropertyObject(claimantName, this._targetClaimantEntity.get('value')));
					break;
			}
			
			target.properties.push(this.getPropertyObject(auditActionFlag,'BulkUpdate'));
			updateClaimsPayload.claims = new Array();
			var oneClaimUpdate = new Object();
			oneClaimUpdate.source = source;
			oneClaimUpdate.target = target;
			updateClaimsPayload.claims.push(oneClaimUpdate);
			
			//Prepare the POST call
			var contentType= "application/json";
			var params = new Object();
			params.repositoryId = this._items[0].repository.id;
			params.userID = this._items[0].repository.userId;
			params.os = this._items[0].objectStore.symbolicName;
			params.type = this._items[0].repository.type;
			params.server = this._items[0].repository.id;
			params.serverType = this._items[0].repository.type;
			
			var displayUpdateStatusFn = dojo.hitch(this,"_displayUpdateStatus");
			
			var invokeParams = new Object();
			invokeParams.requestParams = params;
			invokeParams.requestBody = dojo.toJson(updateClaimsPayload);
			invokeParams.requestCompleteCallback = displayUpdateStatusFn;
			invokeParams.requestFailedCallback = dojo.hitch(this,function(response) {
													console.debug("Error",response);
													this.setMessage("Error Occured:" + response,"error");
													this._statusDlg.hide();
													}
												);

			
			//postPluginService = function(pluginName, pluginServiceName, contentType, pluginParams) {
			Request.postPluginService(
					"BulkUpdate",
					"ClaimsUpdateService",
					contentType,
					invokeParams
			);
	
			this._statusDlg.show();
			
		},
		
		getPropertyObject: function(propName,propVal){
			var newPropObject = new Object();
			newPropObject.property = propName;
			newPropObject.value = propVal;
			return newPropObject;
			
		},

		getDateFromIso: function(dateIn){
			
			if(dateIn!=null && dateIn!="")
				return dojo.date.stamp.fromISOString(dateIn);
			else
				return null;
	
		},
		
		getDateInIso: function(dateIn){
			if(dateIn!=null && dateIn!="")
				return dojo.date.stamp.toISOString(dateIn);
			else
				return null;
		},
		
	    formatDate: function(datum){
	        // Format the value in store, so as to be displayed.
	        if(datum!=null && datum!=""){
	        	var d = dojo.date.stamp.fromISOString(datum);
	        	return dojo.date.locale.format(d, {selector:"date", datePattern: "MM/dd/yyyy HH:mm:ss z"});
	        }else{
	        	return "";
	        }
	    },
	    
	    formatDateFromIso: function(datum){
	        // Format the value in store, so as to be displayed.
	        if(datum!=null && datum!=""){
	        	var d = dojo.date.stamp.fromISOString(datum);
	        	return dojo.date.locale.format(d, {selector:"date", formatLength: "short", fullYear: true})
	        }else{
	        	return "";
	        }
	    }	    
	});
});